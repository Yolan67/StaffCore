package de.yolan.staffcore.paper.gui;

import de.yolan.staffcore.common.model.AuditEvent;
import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.common.protocol.FreezeRequestPayload;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.TeleportPayload;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.paper.config.PaperConfig;
import de.yolan.staffcore.paper.service.BridgeClient;
import de.yolan.staffcore.paper.service.ChatPromptService;
import de.yolan.staffcore.paper.service.InventoryInspectService;
import de.yolan.staffcore.paper.service.PaperRankService;
import de.yolan.staffcore.paper.service.PlayerInspectService;
import de.yolan.staffcore.paper.service.ServerStateCache;
import de.yolan.staffcore.paper.service.SpectateService;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class InspectGui {
    private final JavaPlugin plugin;
    private final GuiManager gui;
    private final ChatPromptService prompts;
    private final PlayerInspectService inspect;
    private final Repositories repos;
    private final Executor io;
    private final InventoryInspectService inventory;
    private final NotesGui notes;
    private final LogsGui logs;
    private final TicketGui tickets;
    private final PunishmentGui punishments;
    private final PaperConfig config;
    private final PaperRankService ranks;
    private final ServerStateCache cache;
    private final BridgeClient bridge;
    private final SpectateService spectate;

    public InspectGui(JavaPlugin plugin, GuiManager gui, ChatPromptService prompts, PlayerInspectService inspect,
                      Repositories repos, Executor io, InventoryInspectService inventory, NotesGui notes,
                      LogsGui logs, TicketGui tickets, PunishmentGui punishments, PaperConfig config,
                      PaperRankService ranks, ServerStateCache cache, BridgeClient bridge, SpectateService spectate) {
        this.plugin = plugin;
        this.gui = gui;
        this.prompts = prompts;
        this.inspect = inspect;
        this.repos = repos;
        this.io = io;
        this.inventory = inventory;
        this.notes = notes;
        this.logs = logs;
        this.tickets = tickets;
        this.punishments = punishments;
        this.config = config;
        this.ranks = ranks;
        this.cache = cache;
        this.bridge = bridge;
        this.spectate = spectate;
    }

    public void promptAndOpen(Player viewer) {
        if (!viewer.hasPermission(Permissions.INSPECT)) return;
        prompts.ask(viewer, "Spielername eingeben", name -> resolve(viewer, name, id -> open(viewer, id)));
    }

    public void openOnlineList(Player viewer, int page) {
        if (!viewer.hasPermission(Permissions.INSPECT)) return;
        List<? extends Player> visible = Bukkit.getOnlinePlayers().stream()
                .filter(target -> visibleTo(viewer, target))
                .sorted(Comparator.comparing(Player::getName, String.CASE_INSENSITIVE_ORDER))
                .toList();
        SecureGuiHolder holder = gui.create(viewer, 54, "Online-Spieler");
        int start = page * 45;
        for (int i = start, slot = 0; i < visible.size() && slot < 45; i++, slot++) {
            Player target = visible.get(i);
            gui.button(holder, slot, gui.item(Material.PLAYER_HEAD, target.getName(),
                            "Welt: " + target.getWorld().getName(), "Ping: " + target.getPing()),
                    Permissions.INSPECT, "inspect-" + target.getUniqueId(),
                    event -> open(viewer, target.getUniqueId()));
        }
        if (page > 0) gui.button(holder, 45, gui.item(Material.ARROW, "Zurück"), null,
                "prev", event -> openOnlineList(viewer, page - 1));
        gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null,
                "close", event -> viewer.closeInventory());
        if (start + 45 < visible.size()) gui.button(holder, 53, gui.item(Material.ARROW, "Weiter"), null,
                "next", event -> openOnlineList(viewer, page + 1));
        gui.open(viewer, holder);
    }

    public void open(Player viewer, UUID target) {
        if (!viewer.hasPermission(Permissions.INSPECT)) {
            viewer.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        viewer.sendMessage(Component.text("Spielerdaten werden geladen …"));
        inspect.load(target).whenComplete((view, error) -> sync(() -> {
            if (!viewer.isOnline()) return;
            if (error != null || view.isEmpty()) {
                viewer.sendMessage(Component.text("Spielerdaten konnten nicht geladen werden."));
                return;
            }
            if (!mayInspect(viewer, target, view.get())) {
                viewer.sendMessage(Component.text("Dieser Spieler ist für dich nicht sichtbar."));
                return;
            }
            renderOverview(viewer, target, view.get());
        }));
    }

    private void renderOverview(Player viewer, UUID target, PlayerInspectService.View view) {
        String name = view.player().currentName();
        Player online = Bukkit.getPlayer(target);
        SecureGuiHolder holder = gui.create(viewer, 54, "Inspect: " + name);
        holder.getInventory().setItem(4, gui.item(Material.PLAYER_HEAD, name,
                "UUID: " + target,
                "Online: " + (online != null),
                "Server: " + view.presence().map(x -> x.serverName()).orElse("offline"),
                "First seen: " + view.player().firstSeen(),
                "Last seen: " + view.player().lastSeen()));
        holder.getInventory().setItem(10, gui.item(Material.IRON_BARS, "Moderationsstatus",
                "Punishments: " + view.punishments().size(),
                "Tickets gegen Spieler: " + view.tickets().size(),
                "Freeze: " + view.freeze().isPresent(),
                "StaffMode: " + view.staffMode().isPresent(),
                "Vanish: " + view.staffState().map(StaffPersistentState::vanished).orElse(false)));
        holder.getInventory().setItem(11, gui.item(Material.NAME_TAG, "Bekannte Namen",
                view.player().knownNames().stream().limit(8).toArray(String[]::new)));
        holder.getInventory().setItem(12, gui.item(Material.CLOCK, "Playtime",
                "Gesamt: " + format(view.totalSeconds()),
                "Server: " + view.byServer().size()));

        if (online != null) gui.button(holder, 19, gui.item(Material.COMPASS, "Live-Daten"), Permissions.INSPECT,
                "live", event -> renderLive(viewer, target, view));
        if (online != null && viewer.hasPermission(Permissions.INSPECT_INVENTORY)) {
            gui.button(holder, 20, gui.item(Material.CHEST, "Inventar"), Permissions.INSPECT_INVENTORY,
                    "inventory", event -> openInventoryMenu(viewer, online, target));
        }
        if (viewer.hasPermission(Permissions.TICKET_VIEW)) gui.button(holder, 21,
                gui.item(Material.BOOK, "Reports / Tickets"), Permissions.TICKET_VIEW,
                "tickets", event -> tickets.openForTarget(viewer, target, name, 0));
        if (hasAnyPunishmentPermission(viewer)) gui.button(holder, 22,
                gui.item(Material.BARRIER, "Punishments"), null,
                "punishments", event -> punishments.open(viewer, target, name));
        if (viewer.hasPermission(Permissions.NOTES_VIEW)) gui.button(holder, 23,
                gui.item(Material.WRITABLE_BOOK, "Staff Notes"), Permissions.NOTES_VIEW,
                "notes", event -> notes.open(viewer, target, name, 0, false));
        gui.button(holder, 24, gui.item(Material.CLOCK, "Sessions / Playtime"), Permissions.INSPECT,
                "sessions", event -> renderSessions(viewer, target, view));
        if (online != null) gui.button(holder, 28, gui.item(Material.REPEATER, "Technik"), Permissions.INSPECT,
                "tech", event -> renderTechnical(viewer, target, view));
        if (viewer.hasPermission(Permissions.LOGS_VIEW)) gui.button(holder, 29,
                gui.item(Material.PAPER, "Logs"), Permissions.LOGS_VIEW,
                "logs", event -> logs.openForTarget(viewer, target));
        gui.button(holder, 30, gui.item(Material.LEVER, "Aktionen"), Permissions.INSPECT,
                "actions", event -> renderActions(viewer, target, view));
        if (online != null && viewer.hasPermission(Permissions.INSPECT_IP)) gui.button(holder, 31,
                gui.item(Material.MAP, "IP anzeigen", "Abruf wird auditiert."), Permissions.INSPECT_IP,
                "ip", event -> showIp(viewer, online));

        gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null, "close", event -> viewer.closeInventory());
        gui.open(viewer, holder);
    }

    private void renderLive(Player viewer, UUID target, PlayerInspectService.View view) {
        Player online = Bukkit.getPlayer(target);
        if (online == null || !visibleTo(viewer, online)) {
            viewer.sendMessage(Component.text("Spieler ist nicht mehr online oder nicht sichtbar."));
            open(viewer, target);
            return;
        }
        var location = online.getLocation();
        SecureGuiHolder holder = gui.create(viewer, 45, "Live: " + online.getName());
        holder.getInventory().setItem(10, gui.item(Material.COMPASS, "Position",
                "Welt: " + online.getWorld().getName(),
                "XYZ: " + location.getBlockX() + " " + location.getBlockY() + " " + location.getBlockZ(),
                "Yaw/Pitch: " + String.format(Locale.ROOT, "%.1f / %.1f", location.getYaw(), location.getPitch())));
        holder.getInventory().setItem(12, gui.item(Material.GOLDEN_APPLE, "Status",
                "Gamemode: " + online.getGameMode(),
                "Health: " + String.format(Locale.ROOT, "%.1f", online.getHealth()),
                "Food: " + online.getFoodLevel(),
                "XP Level: " + online.getLevel(),
                "XP Progress: " + String.format(Locale.ROOT, "%.2f", online.getExp())));
        holder.getInventory().setItem(14, gui.item(Material.POTION, "Potion Effects",
                online.getActivePotionEffects().stream()
                        .limit(10)
                        .map(effect -> effect.getType().getKey().getKey() + " " + (effect.getAmplifier() + 1))
                        .toArray(String[]::new)));
        holder.getInventory().setItem(16, gui.item(Material.REPEATER, "Verbindung",
                "Ping: " + online.getPing() + " ms",
                "Protocol: " + online.getProtocolVersion(),
                "Locale: " + online.locale()));
        back(holder, viewer, target);
        gui.open(viewer, holder);
    }

    private void renderSessions(Player viewer, UUID target, PlayerInspectService.View view) {
        SecureGuiHolder holder = gui.create(viewer, 54, "Sessions: " + view.player().currentName());
        holder.getInventory().setItem(4, gui.item(Material.CLOCK, "Gesamtspielzeit", format(view.totalSeconds())));
        int slot = 9;
        for (var time : view.byServer()) {
            if (slot >= 45) break;
            holder.getInventory().setItem(slot++, gui.item(Material.REPEATER, time.server(), format(time.seconds())));
        }
        back(holder, viewer, target);
        gui.open(viewer, holder);
    }

    private void renderTechnical(Player viewer, UUID target, PlayerInspectService.View view) {
        Player online = Bukkit.getPlayer(target);
        if (online == null || !visibleTo(viewer, online)) {
            viewer.sendMessage(Component.text("Technische Live-Daten sind offline nicht verfügbar."));
            open(viewer, target);
            return;
        }
        List<String> channels = new ArrayList<>(online.getListeningPluginChannels());
        channels.sort(String.CASE_INSENSITIVE_ORDER);
        SecureGuiHolder holder = gui.create(viewer, 45, "Technik: " + online.getName());
        holder.getInventory().setItem(11, gui.item(Material.REPEATER, "Client",
                "Protocol-Version: " + online.getProtocolVersion(),
                "Client Brand (gemeldet): " + Objects.toString(online.getClientBrandName(), "nicht gemeldet"),
                "Locale: " + online.locale(),
                "Client View Distance: " + online.getClientViewDistance()));
        holder.getInventory().setItem(15, gui.item(Material.COMPARATOR, "Plugin-Channels",
                channels.isEmpty() ? new String[]{"keine sichtbar"} : channels.stream().limit(12).toArray(String[]::new)));
        holder.getInventory().setItem(22, gui.item(Material.PAPER, "Erkennungsgrenze",
                "StaffCore behauptet nicht, alle Client-Mods zu erkennen.",
                "Brand/Channels sind nur tatsächlich gemeldete Daten."));
        back(holder, viewer, target);
        gui.open(viewer, holder);
    }

    private void renderActions(Player viewer, UUID target, PlayerInspectService.View view) {
        SecureGuiHolder holder = gui.create(viewer, 45, "Aktionen: " + view.player().currentName());
        if (viewer.hasPermission(Permissions.SPECTATE)) gui.button(holder, 10,
                gui.item(Material.SPYGLASS, "Spectate"), Permissions.SPECTATE,
                "spectate", event -> startSpectate(viewer, target, false));
        if (viewer.hasPermission(Permissions.SPECTATE_SUPER)) gui.button(holder, 11,
                gui.item(Material.ENDER_EYE, "Super-Spectate"), Permissions.SPECTATE_SUPER,
                "spectate-super", event -> startSpectate(viewer, target, true));
        if (viewer.hasPermission(Permissions.FREEZE)) {
            if (view.freeze().isPresent()) {
                gui.button(holder, 13, gui.item(Material.WATER_BUCKET, "Unfreeze"), Permissions.FREEZE,
                        "unfreeze", event -> sendFreeze(viewer, target, "UNFREEZE", "Manual unfreeze"));
            } else {
                gui.button(holder, 13, gui.item(Material.ICE, "Freeze"), Permissions.FREEZE,
                        "freeze", event -> prompts.ask(viewer, "Freeze-Grund", reason -> sendFreeze(viewer, target, "FREEZE", reason)));
            }
        }
        if (viewer.hasPermission(Permissions.TELEPORT) && view.presence().isPresent()) gui.button(holder, 14,
                gui.item(Material.ENDER_PEARL, "Zum Spieler teleportieren"), Permissions.TELEPORT,
                "teleport", event -> bridge.send(MessageType.TELEPORT_ROUTE, viewer.getUniqueId(), 0,
                        new TeleportPayload(viewer.getUniqueId(), target, view.presence().get().serverName(), UUID.randomUUID())));
        if (hasAnyPunishmentPermission(viewer)) gui.button(holder, 16,
                gui.item(Material.BARRIER, "Punishment-GUI"), null,
                "punish", event -> punishments.open(viewer, target, view.player().currentName()));
        back(holder, viewer, target);
        gui.open(viewer, holder);
    }

    private void openInventoryMenu(Player viewer, Player target, UUID targetId) {
        if (!target.isOnline() || !visibleTo(viewer, target)) return;
        SecureGuiHolder holder = gui.create(viewer, 27, "Inventar: " + target.getName());
        gui.button(holder, 11, gui.item(Material.CHEST, "Nur ansehen"), Permissions.INSPECT_INVENTORY,
                "view", event -> inventory.open(viewer, target, false));
        if (viewer.hasPermission(Permissions.INSPECT_INVENTORY_EDIT)) gui.button(holder, 15,
                gui.item(Material.ANVIL, "Bearbeiten"), Permissions.INSPECT_INVENTORY_EDIT,
                "edit", event -> inventory.open(viewer, target, true));
        gui.button(holder, 22, gui.item(Material.ARROW, "Zurück"), null,
                "back", event -> open(viewer, targetId));
        gui.open(viewer, holder);
    }

    public void promptSpectate(Player player, SpectateService spectate) {
        prompts.ask(player, "Spielername zum Spectaten", name -> resolve(player, name,
                id -> spectate.start(player, id, false)));
    }

    public void promptFreeze(Player player, BridgeClient ignored) {
        prompts.ask(player, "Spielername zum Freezen", name -> resolve(player, name,
                id -> prompts.ask(player, "Freeze-Grund", reason -> sendFreeze(player, id, "FREEZE", reason))));
    }

    private void startSpectate(Player viewer, UUID target, boolean superMode) {
        spectate.start(viewer, target, superMode);
    }

    private void sendFreeze(Player actor, UUID target, String action, String reason) {
        if (!actor.hasPermission(Permissions.FREEZE)) {
            actor.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        bridge.send(MessageType.FREEZE_REQUEST, actor.getUniqueId(), 0,
                new FreezeRequestPayload(actor.getUniqueId(), target, action, reason, UUID.randomUUID()));
        actor.closeInventory();
    }

    private void showIp(Player viewer, Player target) {
        if (!viewer.hasPermission(Permissions.INSPECT_IP)) return;
        String address = target.getAddress() == null ? "nicht verfügbar" : target.getAddress().getAddress().getHostAddress();
        UUID actorId = viewer.getUniqueId();
        String actorName = viewer.getName();
        UUID targetId = target.getUniqueId();
        viewer.sendMessage(Component.text("IP von " + target.getName() + ": " + address));
        if (config.auditSensitiveIpViews()) {
            io.execute(() -> repos.audit.append(new AuditEvent(UUID.randomUUID(), UUID.randomUUID(), actorId,
                    actorName, targetId, config.serverName(), "INSPECT_IP", null, null, Instant.now())));
        }
    }

    private void resolve(Player viewer, String name, java.util.function.Consumer<UUID> success) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            if (!visibleTo(viewer, online)) {
                viewer.sendMessage(Component.text("Spieler nicht gefunden."));
                return;
            }
            success.accept(online.getUniqueId());
            return;
        }
        io.execute(() -> {
            Optional<UUID> id = repos.players.findUuidByName(name);
            sync(() -> {
                if (id.isEmpty()) viewer.sendMessage(Component.text("Spieler nicht gefunden."));
                else success.accept(id.get());
            });
        });
    }

    private boolean visibleTo(Player viewer, Player target) {
        boolean vanished = cache.staff(target.getUniqueId()).map(StaffPersistentState::vanished).orElse(false);
        return !vanished || ranks.canSeeVanished(viewer, target);
    }

    private boolean mayInspect(Player viewer, UUID target, PlayerInspectService.View view) {
        boolean vanished = view.staffState().map(StaffPersistentState::vanished).orElse(false);
        if (!vanished) return true;
        Player online = Bukkit.getPlayer(target);
        if (online != null) return ranks.canSeeVanished(viewer, online);
        StaffRank viewerRank = ranks.rank(viewer).orElse(null);
        StaffRank targetRank = view.staffRank().flatMap(value -> {
            try { return Optional.of(StaffRank.parse(value)); }
            catch (IllegalArgumentException ignored) { return Optional.empty(); }
        }).orElse(null);
        return viewerRank != null && targetRank != null && viewerRank.level() >= targetRank.level();
    }

    private boolean hasAnyPunishmentPermission(Player viewer) {
        return viewer.hasPermission(Permissions.PUNISH_WARN)
                || viewer.hasPermission(Permissions.PUNISH_KICK)
                || viewer.hasPermission(Permissions.PUNISH_MUTE)
                || viewer.hasPermission(Permissions.PUNISH_SERVERBAN)
                || viewer.hasPermission(Permissions.PUNISH_GLOBALBAN);
    }

    private void back(SecureGuiHolder holder, Player viewer, UUID target) {
        gui.button(holder, holder.getInventory().getSize() - 5, gui.item(Material.ARROW, "Zurück"), null,
                "back", event -> open(viewer, target));
    }

    private void sync(Runnable task) {
        Bukkit.getScheduler().runTask(plugin, task);
    }

    private static String format(long seconds) {
        long hours = seconds / 3600;
        long minutes = (seconds % 3600) / 60;
        return hours + "h " + minutes + "m";
    }
}
