# Changelog

## 0.1.0-SNAPSHOT
- Initial StaffCore implementation scaffold and core feature set.
- Fixed Velocity 4.1.2 `RegisteredServer` package usage (`com.velocitypowered.api.proxy.server.RegisteredServer`) in SpectateCoordinator, PunishmentCommand, BridgeListener and PunishmentRequestService.
- Added a static Velocity API guard preventing the obsolete/incorrect root-package `RegisteredServer` import.
