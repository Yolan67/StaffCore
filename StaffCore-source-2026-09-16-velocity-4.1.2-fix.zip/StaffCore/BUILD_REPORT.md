# StaffCore Build Report

Datum: 2026-09-16

## Zielplattform

- Java 25
- Velocity API `4.1.2-SNAPSHOT`
- Paper API `26.1.2.build.74-stable`
- Maven Multi-Module
- MariaDB/Flyway

## Tatsächlich verifizierter GitHub-Actions-Stand

GitHub Actions wurde mit Eclipse Temurin Java **25.0.4** und Maven ausgeführt.

### staffcore-common

- kompiliert: **JA**
- Tests: **23/23 bestanden**

### staffcore-data

- kompiliert: **JA**
- MariaDB/Testcontainers: **JA**
- getestete MariaDB-Version: **11.8**
- Flyway `V1__initial.sql`: **erfolgreich angewendet**
- Flyway `V2__spectate_inventory_priority_sessions.sql`: **erfolgreich angewendet**
- `DatabaseIntegrationTests`: **5/5 bestanden**

### staffcore-velocity

Der letzte echte GitHub-Actions-Lauf erreichte das Velocity-Modul und brach dort beim Kompilieren ab.

Gemeldete Ursache:

- `RegisteredServer` war in mehreren Dateien aus `com.velocitypowered.api.proxy.RegisteredServer` bzw. implizit über `com.velocitypowered.api.proxy.*` erwartet worden.
- Für Velocity 4.1.2-SNAPSHOT ist der korrekte Typ `com.velocitypowered.api.proxy.server.RegisteredServer`.

Im Source korrigiert wurden:

- `staffcore-velocity/src/main/java/de/yolan/staffcore/velocity/service/SpectateCoordinator.java`
- `staffcore-velocity/src/main/java/de/yolan/staffcore/velocity/command/PunishmentCommand.java`
- `staffcore-velocity/src/main/java/de/yolan/staffcore/velocity/listener/BridgeListener.java`
- `staffcore-velocity/src/main/java/de/yolan/staffcore/velocity/service/PunishmentRequestService.java`

`PunishmentRequestService.java` war ein zusätzlicher gleichartiger Fehler, der beim vollständigen Source-Audit gefunden wurde, auch wenn er im zuerst gemeldeten Compiler-Ausschnitt noch nicht enthalten war.

**Wichtig:** Für diesen korrigierten Source-Stand liegt noch kein neuer grüner GitHub-Actions-Build vor. Deshalb wird `staffcore-velocity` weiterhin **nicht** als erfolgreich gebaut bezeichnet.

### staffcore-paper

- im letzten GitHub-Actions-Lauf nicht erreicht, da der Reactor vorher in `staffcore-velocity` abgebrochen ist
- für den aktuellen korrigierten Source-Stand daher **nicht gebaut/verifiziert**

## Velocity-4.1.2-API-Audit

Zusätzlich zur konkreten Importkorrektur wurden die im Velocity-Modul verwendeten zentralen API-Verträge gegen die aktuelle PaperMC/Velocity-Dokumentation geprüft:

- `RegisteredServer` -> `com.velocitypowered.api.proxy.server.RegisteredServer`
- `ProxyServer#getServer(String)` / `getAllServers()` liefern `RegisteredServer`
- `Player#createConnectionRequest(RegisteredServer)`
- `ServerConnection#getServer()`
- `CommandManager#register(CommandMeta, Command)`
- `CommandMeta.Builder#plugin(Object)` / `aliases(String...)`
- `EventTask#async(Runnable)`
- `PluginMessageEvent.ForwardResult#handled()`
- `Scheduler.TaskBuilder#repeat(long, TimeUnit)`
- `MinecraftChannelIdentifier#from(String)`
- `ChannelMessageSink#sendPluginMessage(...)`

Es wurde kein weiterer offensichtlicher Package-/Signaturfehler in den aktuell verwendeten Velocity-API-Aufrufen gefunden. Ein vollständiger Beweis der Typkompatibilität erfolgt erst durch den nächsten echten Maven/GitHub-Actions-Lauf.

## Statische Prüfung nach der Korrektur

`scripts/verify-static.py` wurde nach den Source-Änderungen erfolgreich ausgeführt.

Zusätzlich wurde ein neuer Guard ergänzt:

- verbietet `com.velocitypowered.api.proxy.RegisteredServer`;
- verlangt für jede `RegisteredServer`-Verwendung im Velocity-Modul den korrekten `com.velocitypowered.api.proxy.server.RegisteredServer`-Import.

Weiterhin erfolgreich geprüft:

- POM XML;
- keine dynamischen `LATEST`/`RELEASE`-Dependencies;
- keine Pflicht-Stubs/TODO-Marker;
- keine native Java-Object-Deserialisierung;
- interne StaffCore-Imports;
- Java-Dateinamen/Public-Types;
- Paper `plugin.yml` und Commands;
- Permission-Matrix;
- Paper-Listener-Registrierung;
- Velocity `@Plugin`-Metadaten;
- Bridge-MessageType-Matrix;
- Config-Leaf-Keys;
- Repository-SQL gegen Flyway-Migrationstabellen/-spalten;
- Java-Syntaxparserlauf.

## Lokale Arbeitsumgebung dieses Chats

Die lokale Tool-Umgebung dieses Chats besitzt weiterhin kein nutzbares Java-25/Maven-Setup mit externem Dependency-Download. Daher wurde hier **kein** neuer echter Maven-Build ausgeführt.

## Aktueller Buildstatus

- `staffcore-common`: **ECHT GEBAUT + 23/23 TESTS BESTANDEN**
- `staffcore-data`: **ECHT GEBAUT + 5/5 DB-INTEGRATIONSTESTS BESTANDEN**
- `staffcore-velocity`: **SOURCE KORRIGIERT, NEUER BUILD AUSSTEHEND**
- `staffcore-paper`: **NOCH NICHT GEBAUT**
- gesamter Reactor `mvn clean verify`: **NOCH NICHT GRÜN BESTÄTIGT**
- verifizierte Release-JARs: **NEIN**

Erst der nächste vollständig grüne GitHub-Actions-Lauf darf als erfolgreicher Gesamtbuild gelten.
