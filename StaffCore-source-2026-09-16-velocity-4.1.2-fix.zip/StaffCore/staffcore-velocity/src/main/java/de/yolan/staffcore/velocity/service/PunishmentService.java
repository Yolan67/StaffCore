package de.yolan.staffcore.velocity.service;

import com.velocitypowered.api.proxy.Player;import de.yolan.staffcore.common.model.Punishment;import de.yolan.staffcore.common.punishment.*;import de.yolan.staffcore.common.util.*;import de.yolan.staffcore.data.*;import java.time.*;import java.util.*;

public final class PunishmentService {
    private final Repositories repos;private final BridgeHub bridge;
    public PunishmentService(Repositories repos,BridgeHub bridge){this.repos=repos;this.bridge=bridge;}
    public List<Punishment> active(UUID u){return repos.punishments.activeFor(u,Instant.now());}
    public Optional<Punishment> globalBan(UUID u){return active(u).stream().filter(p->p.type().isBan()&&p.scope()==PunishmentScope.NETWORK).findFirst();}
    public Optional<Punishment> serverBan(UUID u,String server){return active(u).stream().filter(p->p.type().isBan()&&p.scope()==PunishmentScope.SERVER&&p.appliesToServer(server)).findFirst();}
    public boolean muted(UUID u){return active(u).stream().anyMatch(p->p.type().isMute());}
    public Punishment create(UUID target,UUID actor,String actorName,PunishmentType type,PunishmentScope scope,String server,String reason,String description,Optional<Duration> duration,String idem){Instant now=Instant.now();Punishment p=new Punishment(UUID.randomUUID(),target,actor,actorName,type,scope,server,InputPolicy.bounded(reason,256,"reason"),description==null?null:InputPolicy.bounded(description,2048,"description"),now,(type==PunishmentType.KICK?now:duration.map(now::plus).orElse(null)),PunishmentStatus.ACTIVE,idem,false);p=repos.punishments.createIdempotent(p);bridge.broadcast(MessageType.PUNISHMENT_CHANGED,target,0,p);return p;}
    public boolean revoke(UUID id,UUID actor,String reason){boolean ok=repos.punishments.revoke(id,actor,InputPolicy.bounded(reason==null?"manual revoke":reason,512,"revoke reason"));if(ok)bridge.broadcast(MessageType.PUNISHMENT_CHANGED,null,0,Map.of("id",id.toString(),"status","REVOKED"));return ok;}
}
