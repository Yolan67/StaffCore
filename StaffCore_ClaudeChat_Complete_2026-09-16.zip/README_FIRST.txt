CLAUDE CHAT:
1. Lade dieses komplette ZIP hoch.
2. Schreibe nur: "Lies START_HERE_CLAUDE_CHAT.md vollständig und führe die Aufgabe aus."
3. Claude soll den bestehenden StaffCore-Source prüfen/fixen, NICHT neu anfangen.

Im ZIP:
- StaffCore/ = aktueller Source
- Reference/MaintenanceCore/ = MaintenanceCore-Source für Integration
- START_HERE_CLAUDE_CHAT.md = verbindlicher Prompt
- Reference/Original_StaffCore_MasterPrompt.txt = ursprüngliche Anforderungen
