package de.yolan.staffcore.velocity.listener;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.velocitypowered.api.event.EventTask;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.PluginMessageEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.RegisteredServer;
import com.velocitypowered.api.proxy.ServerConnection;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.common.protocol.FreezeRequestPayload;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.NotificationPayload;
import de.yolan.staffcore.common.protocol.ProtocolEnvelope;
import de.yolan.staffcore.common.protocol.PunishmentRequestPayload;
import de.yolan.staffcore.common.protocol.SpectatePayload;
import de.yolan.staffcore.common.protocol.StaffChatPayload;
import de.yolan.staffcore.common.protocol.StaffModeRoutePayload;
import de.yolan.staffcore.common.protocol.StatePayload;
import de.yolan.staffcore.common.protocol.StateRequestPayload;
import de.yolan.staffcore.common.protocol.TeleportPayload;
import de.yolan.staffcore.common.util.InputPolicy;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.velocity.service.AuditService;
import de.yolan.staffcore.velocity.service.BridgeHub;
import de.yolan.staffcore.velocity.service.FreezeRequestService;
import de.yolan.staffcore.velocity.service.GlobalStateService;
import de.yolan.staffcore.velocity.service.PunishmentRequestService;
import de.yolan.staffcore.velocity.service.RankService;
import de.yolan.staffcore.velocity.service.SpectateCoordinator;
import de.yolan.staffcore.velocity.service.TicketRoutingService;
import java.util.Arrays;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;
import net.kyori.adventure.text.Component;
import org.slf4j.Logger;

public final class BridgeListener {
    private final ProxyServer proxy;
    private final BridgeHub bridge;
    private final TicketRoutingService routing;
    private final SpectateCoordinator spectate;
    private final PunishmentRequestService punishmentRequests;
    private final FreezeRequestService freezeRequests;
    private final GlobalStateService states;
    private final Repositories repositories;
    private final RankService ranks;
    private final AuditService audit;
    private final Logger logger;
    private final ObjectMapper mapper = new ObjectMapper();
    private final AtomicLong lastBadLog = new AtomicLong();

    public BridgeListener(
            ProxyServer proxy,
            BridgeHub bridge,
            TicketRoutingService routing,
            SpectateCoordinator spectate,
            PunishmentRequestService punishmentRequests,
            FreezeRequestService freezeRequests,
            GlobalStateService states,
            Repositories repositories,
            RankService ranks,
            AuditService audit,
            Logger logger) {
        this.proxy = proxy;
        this.bridge = bridge;
        this.routing = routing;
        this.spectate = spectate;
        this.punishmentRequests = punishmentRequests;
        this.freezeRequests = freezeRequests;
        this.states = states;
        this.repositories = repositories;
        this.ranks = ranks;
        this.audit = audit;
        this.logger = logger;
    }

    @Subscribe
    public EventTask onPluginMessage(PluginMessageEvent event) {
        if (!BridgeHub.CHANNEL.equals(event.getIdentifier())) return null;
        event.setResult(PluginMessageEvent.ForwardResult.handled());
        if (!(event.getSource() instanceof ServerConnection source)) return null;
        byte[] data = Arrays.copyOf(event.getData(), event.getData().length);
        return EventTask.async(() -> process(source, data));
    }

    private void process(ServerConnection source, byte[] data) {
        try {
            ProtocolEnvelope envelope = bridge.decode(data);
            if (!bridge.markNew(envelope.messageId())) return;

            switch (envelope.type()) {
                case STAFFCHAT_MESSAGE -> handleStaffChat(
                        source, mapper.treeToValue(envelope.payload(), StaffChatPayload.class));
                case TELEPORT_ROUTE -> {
                    TeleportPayload payload = mapper.treeToValue(envelope.payload(), TeleportPayload.class);
                    requireActorFromSource(payload.staffUuid(), source, Permissions.TELEPORT);
                    routeTeleport(payload);
                }
                case STAFFMODE_ROUTE -> {
                    StaffModeRoutePayload payload = mapper.treeToValue(envelope.payload(), StaffModeRoutePayload.class);
                    requireActorFromSource(payload.playerUuid(), source, null);
                    routeStaffMode(payload);
                }
                case SPECTATE_ROUTE -> {
                    SpectatePayload payload = mapper.treeToValue(envelope.payload(), SpectatePayload.class);
                    requireActorFromSource(payload.staffUuid(), source, null);
                    spectate.route(payload);
                }
                case PUNISHMENT_REQUEST -> {
                    PunishmentRequestPayload payload = mapper.treeToValue(envelope.payload(), PunishmentRequestPayload.class);
                    requireActorFromSource(payload.actorUuid(), source, null);
                    punishmentRequests.handle(payload);
                }
                case FREEZE_REQUEST -> {
                    FreezeRequestPayload payload = mapper.treeToValue(envelope.payload(), FreezeRequestPayload.class);
                    requireActorFromSource(payload.actorUuid(), source, Permissions.FREEZE);
                    freezeRequests.handle(payload);
                }
                case STATE_RESYNC_REQUEST -> handleStateResync(
                        source, mapper.treeToValue(envelope.payload(), StateRequestPayload.class));
                case TICKET_CHANGED -> routing.route();
                case VANISH_CHANGED -> {
                    requireActorFromSource(envelope.subjectUuid(), source, Permissions.VANISH);
                    bridge.broadcastRaw(data, source.getServerInfo().getName());
                }
                case STAFFCHAT_CHANGED -> {
                    requireActorFromSource(envelope.subjectUuid(), source, Permissions.STAFFCHAT_USE);
                    bridge.broadcastRaw(data, source.getServerInfo().getName());
                }
                case STAFFMODE_CHANGED -> {
                    requireActorFromSource(envelope.subjectUuid(), source, null);
                    bridge.broadcastRaw(data, source.getServerInfo().getName());
                }
                case STAFF_NOTIFICATION -> {
                    NotificationPayload payload = mapper.treeToValue(envelope.payload(), NotificationPayload.class);
                    if (payload.recipientUuid() == null) throw new IllegalArgumentException("recipient missing");
                    bridge.broadcastRaw(data, source.getServerInfo().getName());
                }
                case FREEZE_CHANGED, PUNISHMENT_CHANGED, STATE_RESYNC_RESPONSE ->
                        throw new SecurityException("backend may not originate " + envelope.type());
            }
        } catch (Exception exception) {
            rateLimitedRejectLog(source, exception);
        }
    }

    private void handleStaffChat(ServerConnection source, StaffChatPayload payload) {
        Player sender = requireActorFromSource(payload.senderUuid(), source, Permissions.STAFFCHAT_USE);
        String text = InputPolicy.bounded(payload.message(), 512, "staffchat message");
        String server = source.getServerInfo().getName();
        String rank = ranks.rank(sender).map(StaffRank::displayName).orElse("Staff");
        Component component = Component.text(
                "[SC] [" + server + "] " + rank + " " + sender.getUsername() + ": " + text);
        for (Player recipient : proxy.getAllPlayers()) {
            if (recipient.hasPermission(Permissions.STAFFCHAT_SEE)) recipient.sendMessage(component);
        }
        audit.log(
                sender.getUniqueId(),
                sender.getUsername(),
                null,
                server,
                "STAFFCHAT_MESSAGE",
                null,
                "{\"length\":" + text.length() + "}");
    }

    private void handleStateResync(ServerConnection source, StateRequestPayload request) {
        if (request.playerUuid() == null) throw new IllegalArgumentException("player UUID missing");
        Player player = requireActorFromSource(request.playerUuid(), source, null);
        if (request.serverName() != null
                && !request.serverName().equalsIgnoreCase(source.getServerInfo().getName())) {
            throw new SecurityException("resync server mismatch");
        }

        var state = states.state(player.getUniqueId());
        var freeze = repositories.freezes.find(player.getUniqueId()).filter(record -> record.active());
        boolean staffMode = repositories.staffMode.findActive(player.getUniqueId()).isPresent();
        bridge.broadcast(
                MessageType.STATE_RESYNC_RESPONSE,
                player.getUniqueId(),
                state.revision(),
                new StatePayload(
                        player.getUniqueId(),
                        state.vanished(),
                        state.staffChat(),
                        freeze.isPresent(),
                        freeze.map(record -> record.reason()).orElse(null),
                        staffMode,
                        source.getServerInfo().getName()));
    }

    private Player requireActorFromSource(UUID actorUuid, ServerConnection source, String permission) {
        if (actorUuid == null) throw new SecurityException("actor missing");
        Player actor = proxy.getPlayer(actorUuid).orElseThrow(() -> new SecurityException("actor offline"));
        String currentServer = actor.getCurrentServer()
                .map(connection -> connection.getServerInfo().getName())
                .orElseThrow(() -> new SecurityException("actor has no backend"));
        if (!currentServer.equalsIgnoreCase(source.getServerInfo().getName())) {
            throw new SecurityException("actor/source backend mismatch");
        }
        if (permission != null && !actor.hasPermission(permission)) {
            throw new SecurityException("actor lacks " + permission);
        }
        return actor;
    }

    private void routeStaffMode(StaffModeRoutePayload payload) {
        var active = repositories.staffMode.findActive(payload.playerUuid())
                .orElseThrow(() -> new SecurityException("no active StaffMode session"));
        if (!active.sessionId().equals(payload.sessionId())
                || !active.originServer().equalsIgnoreCase(payload.originServer())) {
            throw new SecurityException("StaffMode route does not match active persisted session");
        }
        Optional<Player> player = proxy.getPlayer(payload.playerUuid());
        Optional<RegisteredServer> target = proxy.getServer(payload.originServer());
        if (player.isEmpty() || target.isEmpty()) {
            player.ifPresent(value -> value.sendMessage(
                    Component.text("StaffMode-Restore wartet: Origin-Server nicht verfügbar.")));
            return;
        }
        player.get().createConnectionRequest(target.get()).connect().thenAccept(result -> {
            if (!result.isSuccessful()) {
                player.get().sendMessage(Component.text("StaffMode-Routing zum Origin-Server fehlgeschlagen."));
            }
        });
    }

    private void routeTeleport(TeleportPayload payload) {
        Optional<Player> staff = proxy.getPlayer(payload.staffUuid());
        Optional<Player> target = proxy.getPlayer(payload.targetUuid());
        if (staff.isEmpty() || target.isEmpty()) {
            staff.ifPresent(value -> value.sendMessage(Component.text("Teleport fehlgeschlagen: Ziel offline.")));
            return;
        }
        if (!staff.get().hasPermission(Permissions.TELEPORT)) {
            staff.get().sendMessage(Component.text("Keine Teleport-Berechtigung."));
            return;
        }

        RegisteredServer server = target.get().getCurrentServer().map(ServerConnection::getServer).orElse(null);
        if (server == null) {
            staff.get().sendMessage(Component.text("Teleport fehlgeschlagen: Zielserver unbekannt."));
            return;
        }
        staff.get().createConnectionRequest(server).connect().thenAccept(result -> {
            if (result.isSuccessful()) {
                bridge.broadcast(
                        MessageType.TELEPORT_ROUTE,
                        payload.staffUuid(),
                        0,
                        new TeleportPayload(
                                payload.staffUuid(),
                                payload.targetUuid(),
                                server.getServerInfo().getName(),
                                payload.requestId()));
            } else {
                staff.get().sendMessage(Component.text("Teleport fehlgeschlagen: Serverwechsel nicht erfolgreich."));
            }
        });
    }

    private void rateLimitedRejectLog(ServerConnection source, Exception exception) {
        long now = System.currentTimeMillis();
        long old = lastBadLog.get();
        if (now - old > 10_000 && lastBadLog.compareAndSet(old, now)) {
            logger.warn(
                    "Rejected malformed, unauthorized, or unauthenticated StaffCore bridge payload from {}: {}",
                    source.getServerInfo().getName(),
                    exception.toString());
        }
    }
}
