package de.yolan.staffcore.velocity.command;

import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.RegisteredServer;
import de.yolan.staffcore.common.model.Punishment;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.punishment.PunishmentScope;
import de.yolan.staffcore.common.punishment.PunishmentType;
import de.yolan.staffcore.common.util.DurationParser;
import de.yolan.staffcore.common.util.InputPolicy;
import de.yolan.staffcore.velocity.service.AuditService;
import de.yolan.staffcore.velocity.service.PlayerResolver;
import de.yolan.staffcore.velocity.service.PunishmentService;
import de.yolan.staffcore.velocity.service.RankService;
import java.time.Duration;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;

public final class PunishmentCommand implements SimpleCommand {
    public enum Action {
        WARN, KICK, MUTE, TEMPMUTE, UNMUTE,
        SERVERBAN, TEMPSERVERBAN, SERVERUNBAN,
        GLOBALBAN, TEMPGLOBALBAN, GLOBALUNBAN
    }

    private final ProxyServer proxy;
    private final PlayerResolver resolver;
    private final PunishmentService service;
    private final AuditService audit;
    private final RankService ranks;
    private final Executor executor;
    private final Action action;

    public PunishmentCommand(
            ProxyServer proxy,
            PlayerResolver resolver,
            PunishmentService service,
            AuditService audit,
            RankService ranks,
            Executor executor,
            Action action) {
        this.proxy = proxy;
        this.resolver = resolver;
        this.service = service;
        this.audit = audit;
        this.ranks = ranks;
        this.executor = executor;
        this.action = action;
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        return invocation.source().hasPermission(permission());
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        String[] args = invocation.arguments();
        if (args.length <= 1) {
            String prefix = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
            return proxy.getAllPlayers().stream()
                    .filter(target -> visibleSuggestion(invocation, target))
                    .map(Player::getUsername)
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(prefix))
                    .limit(50)
                    .toList();
        }
        if (needsServer() && args.length == 2) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            return proxy.getAllServers().stream()
                    .map(server -> server.getServerInfo().getName())
                    .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(prefix))
                    .sorted()
                    .toList();
        }
        return List.of();
    }

    @Override
    public void execute(Invocation invocation) {
        String[] args = invocation.arguments();
        if (args.length < minimumArgs()) {
            invocation.source().sendMessage(Component.text(usage()));
            return;
        }
        executor.execute(() -> run(invocation, args));
    }

    private void run(Invocation invocation, String[] args) {
        if (!invocation.source().hasPermission(permission())) {
            invocation.source().sendMessage(Component.text("Punishment-Permission ist nicht mehr vorhanden."));
            return;
        }
        Optional<UUID> target = resolver.uuid(args[0]);
        if (target.isEmpty()) {
            invocation.source().sendMessage(Component.text("Spieler unbekannt."));
            return;
        }
        UUID actor = invocation.source() instanceof Player player ? player.getUniqueId() : null;
        String actorName = invocation.source() instanceof Player player ? player.getUsername() : "CONSOLE";
        try {
            if (isRevoke()) {
                revoke(invocation, target.get(), actor, actorName);
                return;
            }

            int position = 1;
            String server = null;
            if (needsServer()) {
                server = args[position++];
                if (proxy.getServer(server).isEmpty()) throw new IllegalArgumentException("Server unbekannt: " + server);
            }

            Optional<Duration> duration = Optional.empty();
            if (isTemp()) {
                duration = DurationParser.parse(args[position++]);
                if (duration.isEmpty()) throw new IllegalArgumentException("Temporäre Strafen brauchen eine endliche Dauer.");
            }

            String reason = position < args.length
                    ? InputPolicy.bounded(String.join(" ", Arrays.copyOfRange(args, position, args.length)), 512, "reason")
                    : "Kein Grund angegeben";
            PunishmentType type = type();
            PunishmentScope scope = needsServer() ? PunishmentScope.SERVER : PunishmentScope.NETWORK;
            String bucket = Long.toString(System.currentTimeMillis() / 3000);
            String durationKey = duration.map(value -> Long.toString(value.toMillis())).orElse("permanent");
            String idempotency = "manual:" + actor + ":" + target.get() + ":" + action + ":"
                    + (server == null ? "-" : server.toLowerCase(Locale.ROOT)) + ":"
                    + durationKey + ":" + Integer.toHexString(reason.hashCode()) + ":" + bucket;

            Punishment punishment = service.create(
                    target.get(), actor, actorName, type, scope, server, reason, null, duration, idempotency);
            audit.log(actor, actorName, target.get(), server, "PUNISHMENT_CREATE", null,
                    "{\"id\":\"" + punishment.id() + "\",\"type\":\"" + type + "\"}");
            applyImmediate(target.get(), punishment);
            invocation.source().sendMessage(Component.text("Aktion gespeichert. ID: " + punishment.id()));
        } catch (Exception exception) {
            invocation.source().sendMessage(Component.text("Aktion fehlgeschlagen: " + safe(exception.getMessage())));
        }
    }

    private void revoke(Invocation invocation, UUID target, UUID actor, String actorName) {
        PunishmentType type = switch (action) {
            case UNMUTE -> PunishmentType.MUTE;
            case SERVERUNBAN -> PunishmentType.SERVER_BAN;
            case GLOBALUNBAN -> PunishmentType.GLOBAL_BAN;
            default -> throw new IllegalStateException();
        };
        String server = action == Action.SERVERUNBAN && invocation.arguments().length > 1
                ? invocation.arguments()[1]
                : null;
        if (action == Action.SERVERUNBAN && (server == null || proxy.getServer(server).isEmpty())) {
            throw new IllegalArgumentException("Server unbekannt: " + server);
        }
        int count = 0;
        for (Punishment punishment : service.active(target)) {
            if (punishment.type() != type) continue;
            if (action == Action.SERVERUNBAN && !punishment.appliesToServer(server)) continue;
            if (service.revoke(punishment.id(), actor, "manual revoke")) {
                count++;
                audit.log(actor, actorName, target, server, "PUNISHMENT_REVOKE",
                        "{\"id\":\"" + punishment.id() + "\"}", null);
            }
        }
        invocation.source().sendMessage(Component.text(count + " passende aktive Strafe(n) aufgehoben."));
    }

    private void applyImmediate(UUID target, Punishment punishment) {
        proxy.getPlayer(target).ifPresent(player -> {
            if (punishment.type() == PunishmentType.KICK || punishment.type() == PunishmentType.GLOBAL_BAN) {
                player.disconnect(Component.text(punishment.type() == PunishmentType.KICK
                        ? "Gekickt: " + punishment.reason()
                        : "Global gebannt: " + punishment.reason()));
                return;
            }
            if (punishment.type() == PunishmentType.SERVER_BAN
                    && player.getCurrentServer()
                    .map(server -> server.getServerInfo().getName().equalsIgnoreCase(punishment.serverName()))
                    .orElse(false)) {
                for (RegisteredServer fallback : proxy.getAllServers()) {
                    String name = fallback.getServerInfo().getName();
                    if (name.equalsIgnoreCase(punishment.serverName())) continue;
                    if (service.serverBan(target, name).isPresent()) continue;
                    player.createConnectionRequest(fallback).connect();
                    return;
                }
                player.disconnect(Component.text(
                        "Du bist auf deinem aktuellen Server gesperrt und es gibt keinen erlaubten Fallback-Server."));
            }
        });
    }

    private boolean visibleSuggestion(Invocation invocation, Player target) {
        if (!(invocation.source() instanceof Player viewer)) return true;
        var targetRank = ranks.rank(target);
        if (targetRank.isEmpty()) return true;
        var viewerRank = ranks.rank(viewer);
        return viewerRank.isPresent() && viewerRank.get().level() >= targetRank.get().level();
    }

    private String permission() {
        return switch (action) {
            case WARN -> Permissions.PUNISH_WARN;
            case KICK -> Permissions.PUNISH_KICK;
            case MUTE, TEMPMUTE, UNMUTE -> Permissions.PUNISH_MUTE;
            case SERVERBAN, TEMPSERVERBAN, SERVERUNBAN -> Permissions.PUNISH_SERVERBAN;
            case GLOBALBAN, TEMPGLOBALBAN, GLOBALUNBAN -> Permissions.PUNISH_GLOBALBAN;
        };
    }

    private PunishmentType type() {
        return switch (action) {
            case WARN -> PunishmentType.WARN;
            case KICK -> PunishmentType.KICK;
            case MUTE, TEMPMUTE -> PunishmentType.MUTE;
            case SERVERBAN, TEMPSERVERBAN -> PunishmentType.SERVER_BAN;
            case GLOBALBAN, TEMPGLOBALBAN -> PunishmentType.GLOBAL_BAN;
            default -> throw new IllegalStateException();
        };
    }

    private boolean needsServer() {
        return action == Action.SERVERBAN || action == Action.TEMPSERVERBAN || action == Action.SERVERUNBAN;
    }

    private boolean isTemp() {
        return action == Action.TEMPMUTE || action == Action.TEMPSERVERBAN || action == Action.TEMPGLOBALBAN;
    }

    private boolean isRevoke() {
        return action == Action.UNMUTE || action == Action.SERVERUNBAN || action == Action.GLOBALUNBAN;
    }

    private int minimumArgs() {
        if (isRevoke()) return action == Action.SERVERUNBAN ? 2 : 1;
        return 1 + (needsServer() ? 1 : 0) + (isTemp() ? 1 : 0);
    }

    private String usage() {
        return switch (action) {
            case WARN -> "/warn <spieler> [grund]";
            case KICK -> "/kick <spieler> [grund]";
            case MUTE -> "/mute <spieler> [grund]";
            case TEMPMUTE -> "/tempmute <spieler> <dauer> [grund]";
            case UNMUTE -> "/unmute <spieler>";
            case SERVERBAN -> "/serverban <spieler> <server> [grund]";
            case TEMPSERVERBAN -> "/tempserverban <spieler> <server> <dauer> [grund]";
            case SERVERUNBAN -> "/serverunban <spieler> <server>";
            case GLOBALBAN -> "/globalban <spieler> [grund]";
            case TEMPGLOBALBAN -> "/tempglobalban <spieler> <dauer> [grund]";
            case GLOBALUNBAN -> "/globalunban <spieler>";
        };
    }

    private static String safe(String value) {
        return value == null ? "unbekannter Fehler" : value.substring(0, Math.min(180, value.length()));
    }
}
