#!/usr/bin/env python3
from __future__ import annotations

import re
import subprocess
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []
notes: list[str] = []


def ok(message: str) -> None:
    print(f"OK: {message}")


def fail(message: str) -> None:
    errors.append(message)
    print(f"FAIL: {message}", file=sys.stderr)


def java_files() -> list[Path]:
    return sorted(ROOT.glob("staffcore-*/src/**/*.java"))


# POM structure/version policy.
for pom in ROOT.glob("**/pom.xml"):
    ET.parse(pom)
ok("POM XML gültig")
all_poms = "\n".join(p.read_text(errors="replace") for p in ROOT.glob("**/pom.xml"))
if re.search(r"<version>\s*(LATEST|RELEASE)\s*</version>", all_poms, re.I):
    fail("dynamische LATEST/RELEASE Dependency-Version gefunden")
else:
    ok("keine dynamische Dependency-Version")

# No mandatory stubs or Java native object serialization.
source_blob = "\n".join(p.read_text(errors="replace") for p in java_files())
if re.search(r"\b(TODO|FIXME|UnsupportedOperationException)\b|rest omitted|PSEUDOCODE", source_blob, re.I):
    fail("Pflicht-Stub/TODO-Marker im Java-Source gefunden")
else:
    ok("keine Pflicht-Stubs/TODO-Marker im Java-Source")
if re.search(r"ObjectInputStream|ObjectOutputStream", source_blob):
    fail("unsichere native Java Object-Serialisierung gefunden")
else:
    ok("keine ObjectInputStream/ObjectOutputStream-Nutzung")

# Internal package/import resolution.
classes: dict[str, Path] = {}
for p in java_files():
    text = p.read_text(errors="replace")
    package = re.search(r"\bpackage\s+([\w.]+)\s*;", text)
    if not package:
        fail(f"Java-Datei ohne package: {p.relative_to(ROOT)}")
        continue
    for match in re.finditer(r"\b(?:public\s+)?(?:final\s+)?(?:sealed\s+)?(?:class|interface|enum|record)\s+(\w+)", text):
        classes[package.group(1) + "." + match.group(1)] = p
for p in java_files():
    text = p.read_text(errors="replace")
    for imp in re.findall(r"\bimport\s+(de\.yolan\.staffcore\.[\w.]+)\s*;", text):
        if imp not in classes:
            fail(f"{p.relative_to(ROOT)}: fehlender interner Import {imp}")
if not any("fehlender interner Import" in x for x in errors):
    ok("interne StaffCore-Imports auflösbar")

# Public top-level type must match its source filename; FQCNs must be unique.
fqcn_seen: dict[str, Path] = {}
for p in java_files():
    text = p.read_text(errors="replace")
    package_match = re.search(r"\bpackage\s+([\w.]+)\s*;", text)
    public_match = re.search(r"\bpublic\s+(?:final\s+|sealed\s+|abstract\s+)?(?:class|interface|enum|record)\s+(\w+)", text)
    if public_match and public_match.group(1) != p.stem:
        fail(f"{p.relative_to(ROOT)}: public type {public_match.group(1)} passt nicht zum Dateinamen")
    if package_match and public_match:
        fqcn = package_match.group(1) + "." + public_match.group(1)
        if fqcn in fqcn_seen:
            fail(f"doppelte FQCN {fqcn}: {fqcn_seen[fqcn].relative_to(ROOT)} / {p.relative_to(ROOT)}")
        fqcn_seen[fqcn] = p
if not any("public type" in x or "doppelte FQCN" in x for x in errors):
    ok(f"Java-Dateinamen/Public-Types eindeutig ({len(fqcn_seen)} public types)")

# Paper metadata vs bootstrap.
plugin_path = ROOT / "staffcore-paper/src/main/resources/plugin.yml"
plugin = yaml.safe_load(plugin_path.read_text())
if plugin.get("main") != "de.yolan.staffcore.paper.StaffCorePaper":
    fail("plugin.yml main zeigt nicht auf StaffCorePaper")
else:
    ok("plugin.yml main korrekt")
if str(plugin.get("api-version")) != "26.1":
    fail("plugin.yml api-version ist nicht 26.1")
else:
    ok("plugin.yml api-version 26.1")
paper_main = ROOT / "staffcore-paper/src/main/java/de/yolan/staffcore/paper/StaffCorePaper.java"
paper_main_text = paper_main.read_text()
registered_commands = set(re.findall(r'command\("([a-z0-9_-]+)"\s*,', paper_main_text, re.I))
yaml_commands = set((plugin.get("commands") or {}).keys())
if registered_commands != yaml_commands:
    fail(f"Paper command registration mismatch: Java={sorted(registered_commands)}, plugin.yml={sorted(yaml_commands)}")
else:
    ok(f"Paper commands vollständig registriert ({len(yaml_commands)})")

permission_values = set(re.findall(r'"(staffcore\.[a-z0-9_.-]+)"', (ROOT / "staffcore-common/src/main/java/de/yolan/staffcore/common/permission/Permissions.java").read_text(), re.I))
permission_values |= set(re.findall(r'"(staffcore\.rank\.[a-z0-9_.-]+)"', (ROOT / "staffcore-common/src/main/java/de/yolan/staffcore/common/permission/StaffRank.java").read_text(), re.I))
yaml_permissions = set((plugin.get("permissions") or {}).keys())
missing_permissions = sorted(permission_values - yaml_permissions)
if missing_permissions:
    fail("plugin.yml fehlen Permissions: " + ", ".join(missing_permissions))
else:
    ok(f"plugin.yml deckt alle Code-/Rank-Permissions ab ({len(permission_values)})")

# Listener registration completeness for listener package plus Listener services explicitly instantiated.
listener_classes = set()
for p in (ROOT / "staffcore-paper/src/main/java/de/yolan/staffcore/paper/listener").glob("*.java"):
    text = p.read_text()
    m = re.search(r"class\s+(\w+)\s+implements\s+Listener", text)
    if m:
        listener_classes.add(m.group(1))
registered_listener_classes = set(re.findall(r"register\(new\s+(\w+)\s*\(", paper_main_text))
missing_listeners = sorted(listener_classes - registered_listener_classes)
if missing_listeners:
    fail("Paper Listener nicht registriert: " + ", ".join(missing_listeners))
else:
    ok(f"alle Listener-Package-Klassen registriert ({len(listener_classes)})")

# Velocity metadata should be generated from @Plugin, not conflicting static metadata.
velocity_main = ROOT / "staffcore-velocity/src/main/java/de/yolan/staffcore/velocity/StaffCoreVelocity.java"
velocity_text = velocity_main.read_text()
if not re.search(r"@Plugin\s*\(.*?id\s*=\s*\"staffcore\"", velocity_text, re.S):
    fail("Velocity @Plugin-Metadaten fehlen/Plugin-ID unerwartet")
else:
    ok("Velocity @Plugin-Metadaten vorhanden")
if (ROOT / "staffcore-velocity/src/main/resources/velocity-plugin.json").exists():
    fail("manuelle velocity-plugin.json vorhanden; Annotation-Processor ist Authority")
else:
    ok("keine widersprüchliche manuelle velocity-plugin.json")

# Message type matrix. These are intentional transport directions, not necessarily request/reply pairs.
enum_path = ROOT / "staffcore-common/src/main/java/de/yolan/staffcore/common/protocol/MessageType.java"
enum_text = enum_path.read_text()
body = re.search(r"enum\s+MessageType\s*\{(.*?)\}", enum_text, re.S).group(1)
message_types = {x.strip() for x in body.split(",") if x.strip()}
expected_types = {
    "STATE_RESYNC_REQUEST", "STATE_RESYNC_RESPONSE", "VANISH_CHANGED", "STAFFCHAT_CHANGED",
    "FREEZE_CHANGED", "FREEZE_REQUEST", "STAFFMODE_CHANGED", "STAFFMODE_ROUTE", "SPECTATE_ROUTE",
    "TELEPORT_ROUTE", "STAFF_NOTIFICATION", "TICKET_CHANGED", "PUNISHMENT_CHANGED",
    "PUNISHMENT_REQUEST", "STAFFCHAT_MESSAGE"
}
if message_types != expected_types:
    fail(f"MessageType-Matrix unerwartet: {sorted(message_types ^ expected_types)}")
else:
    ok(f"MessageType-Matrix vollständig ({len(message_types)} Typen)")
used_message_types = set(re.findall(r"MessageType\.([A-Z0-9_]+)", source_blob))
unknown_message_types = sorted(used_message_types - message_types)
unused_message_types = sorted(message_types - used_message_types)
if unknown_message_types:
    fail("unbekannte MessageType-Referenzen: " + ", ".join(unknown_message_types))
else:
    ok(f"alle MessageType-Referenzen sind definiert ({len(used_message_types)} verwendet)")
if unused_message_types:
    notes.append("nicht referenzierte MessageTypes: " + ", ".join(unused_message_types))
velocity_bridge_listener = (ROOT / "staffcore-velocity/src/main/java/de/yolan/staffcore/velocity/listener/BridgeListener.java").read_text()
paper_bridge_coord = (ROOT / "staffcore-paper/src/main/java/de/yolan/staffcore/paper/service/BridgeStateCoordinator.java").read_text()
paper_spectate = (ROOT / "staffcore-paper/src/main/java/de/yolan/staffcore/paper/service/SpectateService.java").read_text()
# Backend-origin types must have a Velocity switch case.
backend_origin = {
    "STATE_RESYNC_REQUEST", "VANISH_CHANGED", "STAFFCHAT_CHANGED", "FREEZE_REQUEST", "STAFFMODE_CHANGED",
    "STAFFMODE_ROUTE", "SPECTATE_ROUTE", "TELEPORT_ROUTE", "STAFF_NOTIFICATION", "TICKET_CHANGED",
    "PUNISHMENT_REQUEST", "STAFFCHAT_MESSAGE"
}
for t in sorted(backend_origin):
    if not re.search(rf"case\s+[^\n]*\b{re.escape(t)}\b", velocity_bridge_listener):
        fail(f"Bridge backend->Velocity ohne Handler: {t}")
# Velocity-origin types must be handled/consumed by Paper.
paper_origin = {
    "STATE_RESYNC_RESPONSE", "VANISH_CHANGED", "STAFFCHAT_CHANGED", "FREEZE_CHANGED", "STAFFMODE_CHANGED",
    "SPECTATE_ROUTE", "TELEPORT_ROUTE", "STAFF_NOTIFICATION", "PUNISHMENT_CHANGED"
}
combined_paper_handlers = paper_bridge_coord + "\n" + paper_spectate
for t in sorted(paper_origin):
    if f"MessageType.{t}" not in combined_paper_handlers:
        fail(f"Bridge Velocity->Paper ohne Handler: {t}")
if not any("Bridge " in x for x in errors):
    ok("Bridge Sender/Empfänger-Matrix abgedeckt")

# Config: every leaf key in shipped YAML must at minimum be parsed/validated by its module loader.
def leaf_paths(value, prefix=""):
    if isinstance(value, dict):
        for k, v in value.items():
            p = f"{prefix}.{k}" if prefix else str(k)
            yield from leaf_paths(v, p)
    elif isinstance(value, list):
        yield prefix
    else:
        yield prefix

for module in ("paper", "velocity"):
    cfg_path = ROOT / f"staffcore-{module}/src/main/resources/config.yml"
    loader_path = ROOT / f"staffcore-{module}/src/main/java/de/yolan/staffcore/{module}/config/ConfigLoader.java"
    cfg = yaml.safe_load(cfg_path.read_text())
    loader = loader_path.read_text()
    unseen = []
    dynamic_map_prefixes = {
        "paper": (
            "priority.category-weights.",
            "priority.subcategory-weights.",
            "priority.category-min-rank.",
            "priority.priority-min-rank.",
        ),
        "velocity": ("routing.max-active-tickets.",),
    }
    for path in leaf_paths(cfg):
        if any(path.startswith(prefix) for prefix in dynamic_map_prefixes[module]):
            # The whole map is consumed generically and its keys are validated as enum/string/rank entries.
            continue
        key = path.split(".")[-1]
        if f'"{key}"' not in loader:
            unseen.append(path)
    if unseen:
        fail(f"{module} config leaf keys nicht im Loader referenziert: {', '.join(unseen)}")
    else:
        ok(f"{module} config.yml: alle Leaf-Keys werden geladen/validiert")

# Migration schema incl. forward ALTER ADD COLUMN + repository SQL table/column checks.
migration_dir = ROOT / "staffcore-data/src/main/resources/db/migration"
migration_sql = "\n".join(p.read_text() for p in sorted(migration_dir.glob("V*.sql")))
schema: dict[str, set[str]] = {}
for m in re.finditer(r"CREATE\s+TABLE\s+(\w+)\s*\((.*?)\)\s*ENGINE=", migration_sql, re.I | re.S):
    table = m.group(1).lower()
    body = m.group(2)
    pieces = []
    current = []
    depth = 0
    for char in body:
        if char == "(": depth += 1
        elif char == ")": depth -= 1
        if char == "," and depth == 0:
            pieces.append("".join(current).strip())
            current = []
        else:
            current.append(char)
    if current: pieces.append("".join(current).strip())
    columns = set()
    for piece in pieces:
        if re.match(r"(?i)^(PRIMARY|UNIQUE|INDEX|KEY|CONSTRAINT|FOREIGN|CHECK)\b", piece):
            continue
        cm = re.match(r"`?(\w+)`?\s+", piece)
        if cm: columns.add(cm.group(1).lower())
    schema[table] = columns
for m in re.finditer(r"ALTER\s+TABLE\s+(\w+)\s+ADD\s+COLUMN\s+(\w+)\b", migration_sql, re.I):
    schema.setdefault(m.group(1).lower(), set()).add(m.group(2).lower())

queries: list[tuple[Path, str]] = []
repo_files = sorted((ROOT / "staffcore-data/src/main/java/de/yolan/staffcore/data").glob("*Repository.java"))
for p in repo_files:
    text = p.read_text()
    # Prepared statements cover the mutation paths. Dynamic list/count helpers are added below.
    for pattern in [r"prepareStatement\((.*?)\)", r"\blist\((\"(?:\\.|[^\"\\])*\"(?:\s*\+\s*[^,;]+)*?)\s*,", r"\bcount\((\"(?:\\.|[^\"\\])*\"(?:\s*\+\s*[^,;]+)*?)\s*,"]:
        for match in re.finditer(pattern, text, re.S):
            literals = re.findall(r'"((?:\\.|[^"\\])*)"', match.group(1))
            if not literals: continue
            q = "".join(bytes(x, "utf-8").decode("unicode_escape") for x in literals)
            if re.match(r"(?is)^\s*(SELECT|INSERT|UPDATE|DELETE)", q): queries.append((p, q))

sql_errors = []
def check_column(file: Path, table: str, column: str, query: str):
    column = column.lower().strip("`")
    if column in {"*", "1"} or column in {"null"}: return
    if table in schema and column not in schema[table]:
        sql_errors.append(f"{file.name}: {table}.{column} fehlt in Migration ({' '.join(query.split())[:160]})")

for file, query in queries:
    q = " ".join(query.split())
    insert = re.search(r"(?i)INSERT(?:\s+IGNORE)?\s+INTO\s+(\w+)\s*\(([^)]*)\)", q)
    update = re.search(r"(?i)UPDATE\s+(\w+)\s+SET\s+(.+?)(?:\s+WHERE\s+|$)", q)
    from_match = re.search(r"(?i)\bFROM\s+(\w+)", q)
    table = (insert or update or from_match).group(1).lower() if (insert or update or from_match) else None
    if table is None: continue
    if table not in schema:
        sql_errors.append(f"{file.name}: Tabelle {table} fehlt in Migration")
        continue
    if insert:
        for col in insert.group(2).split(","): check_column(file, table, col.strip(), q)
    if update:
        for assignment in update.group(2).split(","):
            cm = re.match(r"`?(\w+)`?\s*=", assignment.strip())
            if cm: check_column(file, table, cm.group(1), q)
    where = re.search(r"(?i)\sWHERE\s(.+?)(?:\sORDER\s|\sGROUP\s|\sLIMIT\s|\sFOR\s+UPDATE|$)", q)
    if where:
        for col in re.findall(r"(?<![.\w])([A-Za-z_]\w*)\s*(?:=|<=>|<=|>=|<|>|\s+IS\s|\s+IN\s)", where.group(1), re.I):
            if col.upper() not in {"AND", "OR", "NOT"}: check_column(file, table, col, q)

all_columns = set().union(*schema.values())
for p in repo_files:
    text = p.read_text()
    for col in re.findall(r'\b(?:getString|getLong|getInt|getBoolean|getDouble|getFloat|getBytes|Sql\.uuid|Sql\.instant)\s*\(\s*(?:\w+\s*,\s*)?"([A-Za-z_]\w*)"', text):
        if col.lower() not in all_columns:
            sql_errors.append(f"{p.name}: ResultSet-Spalte {col} existiert in keiner Migration")
if sql_errors:
    for issue in sorted(set(sql_errors)): fail(issue)
else:
    ok(f"Repository SQL gegen {len(schema)} Migrationstabellen/Spalten statisch abgeglichen ({len(queries)} extrahierte Queries)")

# Removed privilege bypass stays gone.
whole_tree = "\n".join(p.read_text(errors="replace") for p in ROOT.glob("**/*") if p.is_file() and p.suffix in {".java", ".md", ".yml"})
if "staffcore.vanish.supersee" in whole_tree:
    fail("entfernter Vanish-Hierarchie-Bypass wird noch referenziert")
else:
    ok("kein Vanish-Hierarchie-Bypass referenziert")

# Weak syntax-only javac pass. Missing external API classes are expected; only syntax diagnostics fail this check.
java_paths = [str(p) for p in java_files()]
proc = subprocess.run(
    ["javac", "-proc:none", "-XDshouldStop.at=PARSE", "-Xmaxerrs", "10000", *java_paths],
    cwd=ROOT, capture_output=True, text=True)
syntax_markers = (
    "';' expected", "illegal start of", "reached end of file while parsing", "')' expected",
    "not a statement", "class, interface, enum, or record expected", "unclosed string literal"
)
syntax_lines = [line for line in proc.stderr.splitlines() if any(marker in line for marker in syntax_markers)]
if syntax_lines:
    fail("javac Parser-Syntaxdiagnosen: " + " | ".join(syntax_lines[:10]))
else:
    ok("javac Parserlauf: keine Java-Syntaxdiagnose (externe Typen nicht geprüft)")

if errors:
    print(f"\nStatic verification FAILED with {len(errors)} issue(s).", file=sys.stderr)
    sys.exit(1)
for note in notes:
    print("NOTE: " + note)
print("\nStatic verification completed successfully.")
