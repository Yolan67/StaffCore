# Changelog

## 0.1.0-SNAPSHOT
- Initial StaffCore implementation scaffold and core feature set.
