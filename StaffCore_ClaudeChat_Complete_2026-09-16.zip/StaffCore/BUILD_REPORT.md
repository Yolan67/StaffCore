# StaffCore Build Report

Datum: 2026-09-16

## Zielplattform

- Java 25
- Velocity API `4.1.2-SNAPSHOT`
- Paper API `26.1.2.build.74-stable`
- Maven Multi-Module
- MariaDB/Flyway

## Tatsächlich vorhandene Build-Umgebung

- `java -version`: OpenJDK **21.0.11**
- systemweites `mvn`: **nicht installiert**
- Java 25: **nicht installiert**
- `./mvnw -version`: nicht erfolgreich, da `repo.maven.apache.org` in dieser Laufzeit nicht per DNS auflösbar war.

## Maven-Build

`mvn clean verify`: **NICHT AUSGEFÜHRT**

Es werden daher ausdrücklich **keine** erfolgreichen JAR-Builds, keine Testzahlen aus Maven und keine JAR-SHA256-Werte behauptet.

## Final ausgeführte statische Prüfung

`./scripts/verify-static.sh` wurde nach den letzten Source-Korrekturen erfolgreich ausgeführt.

Geprüft und erfolgreich:

- alle POMs XML-valid;
- keine `LATEST`/`RELEASE`-Dependencies;
- keine Pflicht-TODO/FIXME-/Stub-Marker im Java-Source;
- keine `ObjectInputStream`/`ObjectOutputStream`-Nutzung;
- alle internen `de.yolan.staffcore.*`-Imports auflösbar;
- **146** Public-Types eindeutig und passend zu ihren Dateinamen;
- Paper `plugin.yml` Main-Class korrekt;
- Paper `api-version: 26.1`;
- **6** Paper-Commands zwischen Bootstrap und `plugin.yml` konsistent;
- **44** Code-/Rank-Permissions durch `plugin.yml` abgedeckt;
- **8** Listener-Klassen aus dem Paper-Listener-Package registriert;
- Velocity `@Plugin`-Metadaten vorhanden;
- keine widersprüchliche manuelle `velocity-plugin.json`;
- **15** Bridge-MessageTypes definiert und **15** verwendet;
- Backend→Velocity- und Velocity→Paper-Handler-Matrix vollständig;
- alle Leaf-Keys beider ausgelieferten Configs werden geladen/validiert;
- **57** extrahierte Repository-SQL-Queries gegen **27** Migrationstabellen/-spalten statisch abgeglichen;
- kein entfernter Vanish-Hierarchie-Bypass referenziert;
- `javac` Parserlauf: keine Java-Syntaxdiagnosen; externe API-Typen wurden mangels Maven-Classpath **nicht** vollständig typgeprüft;
- `bash -n` für `mvnw`, `scripts/verify-static.sh`, `scripts/sha256.sh` erfolgreich;
- `python3 -m py_compile scripts/verify-static.py` erfolgreich;
- ausgelieferte YAML-Dateien erfolgreich geparst.

## Drei finale DoD-Korrekturen

1. StaffMode-Recovery: zuvor stille Recovery-/Backend-Restore-Fehlerpfade loggen jetzt serverseitig, erzeugen Audit-Events und erhalten den persistenten Recovery-Snapshot statt Fehler zu verschlucken.
2. Manuelle Punishment-Idempotenz: die kanonische temporäre Dauer (`Duration.toMillis()`) ist Bestandteil des Idempotency-Keys; permanente Aktionen verwenden `permanent`.
3. Velocity Presence: periodischer Heartbeat plus konfigurierbare Stale-Schwelle; stale Cleanup schließt die zugehörigen offenen `player_server_sessions` derselben Network-Session, bevor Presence entfernt wird.

## Tests

Vorhandene Test-Source-Dateien: **11**.

Tatsächlich ausgeführt:

- Maven Unit Tests: **NEIN**
- Testcontainers/MariaDB-Integrationstests: **NEIN**
- Velocity/Paper-Runtime-Tests: **NEIN**

Grund: kein JDK 25/Maven-Classpath in dieser Laufzeit.

## Release-Artefakte

Erzeugt:

- vollständiger Sourcebaum;
- Dokumentation;
- Configs/Migrationen;
- Maven Wrapper-Skripte/-Properties;
- statischer Prüfer;
- Runtime-Testplan;
- Source-ZIP außerhalb des Projektordners.

Nicht erzeugt:

- StaffCore-Velocity JAR;
- StaffCore-PaperBridge JAR;
- JAR-SHA256.

## Reproduzierbarer echter Build

Auf einem Rechner mit JDK 25 und funktionierendem Maven/Internet bzw. Maven-Cache:

```bash
java -version
./mvnw -version
./mvnw clean verify
./scripts/sha256.sh
```

Erst nach erfolgreichem `clean verify` dürfen JARs als verifiziert bezeichnet werden.
