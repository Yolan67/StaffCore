# StaffCore — Claude Chat Final Build / Review / Fix Master Prompt

## WICHTIG: Was du mit diesem Upload tun sollst

Du erhältst in diesem ZIP ein bereits sehr weit entwickeltes Minecraft-Netzwerkprojekt **StaffCore** inklusive vollständigem Source-Stand sowie die Source des bereits vorhandenen **MaintenanceCore** als Referenz.

**Schreibe StaffCore NICHT von vorne neu.**

Deine Aufgabe ist, den vorhandenen Source vollständig zu lesen, ihn gegen die Anforderungen unten zu prüfen, echte Fehler zu korrigieren, fehlende Pflichtfunktionen zu ergänzen, einen echten Build zu versuchen, Tests auszuführen soweit deine Umgebung es erlaubt und am Ende möglichst ein korrigiertes vollständiges Source-ZIP sowie echte JARs zu liefern.

Wenn deine Umgebung keinen Java-25-/Maven-Build erlaubt, darfst du deswegen **nicht** nach einer Zusammenfassung stoppen. Arbeite dann alle Source-Korrekturen und statischen Prüfungen trotzdem vollständig ab und liefere ein korrigiertes Source-ZIP. Behaupte niemals einen Build oder Runtime-Test, der nicht wirklich stattgefunden hat.

---

# 1. Enthaltene Dateien

- `StaffCore/` — aktueller StaffCore-Source-Stand.
- `Reference/MaintenanceCore/` — Source meines vorhandenen Velocity-Wartungsplugins als Referenz für die optionale/read-only Integration.
- `Reference/Original_StaffCore_MasterPrompt.txt` — ursprünglicher großer Anforderungsprompt als zusätzliche Referenz.
- diese Datei — aktuelle, verbindliche Aufgabenbeschreibung für deinen Review.

Bei Widersprüchen gilt die **aktuellere Anforderung in dieser Datei**.

---

# 2. Zielplattform

- Java **25**
- Velocity **4.1.2**
- Paper **26.1.2**
- MariaDB/MySQL-kompatible Persistenz, produktiv MariaDB
- Maven Multi-Module
- aktuelle Server: `lobby`, `survival`, `events`
- später beliebig weitere Paper-Backends

Servernamen dürfen nicht fest verdrahtet sein.

StaffCore besteht grundsätzlich aus:

- `staffcore-common`
- `staffcore-data`
- `staffcore-velocity`
- `staffcore-paper`

Velocity ist die zentrale Authority für netzwerkweite Zustände/Enforcement; Paper ist für lokale Welt-, Entity-, Inventar- und GUI-Funktionen zuständig.

---

# 3. Aktueller Status des Projekts

Der vorhandene Stand wurde bereits umfangreich statisch geprüft, aber **noch nicht erfolgreich mit Java 25 per `mvn clean verify` gebaut** und **noch nicht in echter Velocity/Paper-Runtime getestet**.

Der bisherige Erzeugungschat hat zuletzt gemeldet:

- Source vollständig: JA
- statische Prüfung: JA
- Maven-Build: NEIN
- Runtime getestet: NEIN
- verifizierte JARs: NEIN

Die drei zuletzt gefundenen DoD-Probleme sollen im aktuellen Source bereits behoben sein und müssen von dir verifiziert werden:

1. StaffMode-Recovery-Fehlerpfade besitzen Logging/Audit/Recovery-Verhalten.
2. Manuelle Punishment-Idempotency berücksichtigt bei temporären Strafen die Dauer/Expiry in der Eindeutigkeit.
3. Velocity-Presence besitzt periodischen Heartbeat und sichere stale-session-Bereinigung.

Vertraue diesen Aussagen nicht blind: **prüfe den Source selbst.**

---

# 4. Deine primäre Aufgabe

Arbeite in dieser Reihenfolge, ohne nach jeder Phase auf meine Bestätigung zu warten:

## A. Vollständige Source-Inventur

1. Entpacke/lese den kompletten Sourcebaum.
2. Lies insbesondere:
   - Root-`pom.xml`
   - Modul-POMs
   - `PROJECT_MANIFEST.md`
   - `README.md`
   - `BUILD_REPORT.md`
   - `docs/ARCHITECTURE.md`
   - `docs/DATABASE.md`
   - `docs/RECOVERY.md`
   - `docs/SECURITY.md`
   - `docs/RUNTIME_TEST_PLAN.md`
   - `docs/PERMISSIONS.md`
   - `docs/KNOWN_LIMITATIONS.md`
   - Flyway-Migrationen
   - alle Entry-Points, Commands, Listener, Services, Repositories, GUIs und Tests.
3. Prüfe, ob Dokumentation und tatsächlicher Source übereinstimmen.

## B. Echten Build versuchen

Wenn deine Umgebung es erlaubt:

```bash
java -version
./mvnw -version
./mvnw clean verify
```

Ziel ist ein **echter grüner Maven-Build mit Java 25**.

Wenn Compile-/Testfehler auftreten:

- Fehler vollständig lesen.
- Ursache beheben.
- Nicht durch Feature-Entfernung, Stubs oder das Abschalten sinnvoller Tests „grün machen“.
- Build erneut ausführen.
- Wiederholen, bis `clean verify` grün ist oder ein externer Blocker eindeutig nachgewiesen ist.

Wenn der Build wegen Umgebung/Netzwerk unmöglich ist:

- klar dokumentieren,
- keine JAR erfinden,
- trotzdem mit C–H vollständig fortfahren.

## C. API-/Compile-Review

Prüfe insbesondere echte API-Signaturen für:

- Velocity 4.1.2 Command API
- Login/PreLogin/PostLogin/Disconnect/ServerPreConnect/ServerConnected Events
- Scheduler
- Plugin Messaging
- Adventure/MiniMessage
- Velocity Permissions
- Paper 26.1.2 Events
- `hidePlayer/showPlayer`
- Inventar-/ItemStack-Serialisierung
- AsyncChat/Command Preprocess
- Spectator/Gamemode/Teleport APIs
- PDC/GUI-Action-IDs
- Plugin metadata / `plugin.yml`

Keine erfundenen oder veralteten API-Aufrufe akzeptieren.

## D. Vollständiger Verdrahtungsreview

Gleiche vollständig ab:

- Commands ↔ Registrierungen ↔ Permissions ↔ Implementierungen
- Listener ↔ Registrierung ↔ Events
- GUI-Actions ↔ serverseitige Action-IDs ↔ Permission-Recheck
- Bridge-MessageTypes ↔ Sender ↔ Empfänger ↔ Payload-Validierung
- Config-Keys ↔ Default-Configs ↔ tatsächliche Nutzung
- Repositories ↔ SQL ↔ Flyway-Spalten/Tabellen/Indizes
- State-Machines ↔ Recoverypfade
- Services ↔ Lifecycle start/stop
- Scheduler ↔ Shutdown/Cancellation
- Async DB ↔ Mainthread Paper API

## E. Sicherheitsreview

Prüfe mindestens:

- SQL Injection
- Permission-Bypass
- GUI spoofing
- Plugin-Message spoofing/replay
- HMAC/Clock-Skew/Payloadlimit
- Dupe-Gefahr bei StaffMode/InventoryEdit
- doppelte Punishments
- Race Conditions bei Ticket Claims
- Freeze disconnect vs. Backend-Wechsel
- stale Presence
- unsafe deserialization
- Usertext als MiniMessage
- Secret-Leaks
- sensible IP-Daten
- DB-Ausfall / degraded mode

---

# 5. Verbindliche Funktionsanforderungen

## 5.1 Staff-Hierarchie

Nur Permissions, keine LuckPerms-Gruppennamen:

- `staffcore.rank.jrmod`
- `staffcore.rank.mod`
- `staffcore.rank.srmod`
- `staffcore.rank.admin`
- `staffcore.rank.owner`

Hierarchie:

`JrMod < Mod < SrMod < Admin < Owner`

Mehrere Rank-Permissions -> höchste gewinnt.

### Vanish-Sichtbarkeit

Vanish folgt dieser Regel:

- Owner sieht alle vanished Staff.
- Admin sieht Admin/SrMod/Mod/JrMod, aber keinen vanished Owner.
- SrMod sieht SrMod/Mod/JrMod, aber Admin/Owner nicht.
- Mod sieht Mod/JrMod.
- JrMod sieht JrMod.
- normale Spieler sehen vanished Staff nie.

Also bei Vanish: **gleicher oder niedrigerer Rang sichtbar**.

### `/stafflist` — wichtige Abweichung

Der User hat für `/stafflist` ausdrücklich gesagt: **nur Staff unter einem selbst anzeigen**.

Daher soll `/stafflist` standardmäßig **streng niedrigere Ränge** anzeigen, nicht denselben Rang.

Beispiele:

- Owner -> Admin/SrMod/Mod/JrMod
- Admin -> SrMod/Mod/JrMod
- SrMod -> Mod/JrMod
- Mod -> JrMod
- JrMod -> niemand

Passe Source/README/Tests an, falls aktuell dieselbe Regel wie Vanish verwendet wird.

Keine höhere Staff-Stufe darf durch StaffList/TabCompletion/Assignee-Auswahl versehentlich geleakt werden.

---

## 5.2 Vanish

Command:

`/vanish`

Anforderungen:

- netzwerkweit persistenter/erhaltener Zustand
- Serverwechsel ohne sichtbaren Leak
- normale Spieler sehen vanished Staff nicht
- TAB/Entity/NameTag soweit öffentliche APIs es erlauben
- Mob-/Interaktions-/Meldungsleaks soweit sauber vermeidbar
- beim Aktivieren normale Minecraft-artige Leave-Nachricht
- beim Entvanish normale Minecraft-artige Join-Nachricht
- genau einmal, keine Doppelmeldungen
- höhere unsichtbare Staff nicht an niedrigere Staff leaken
- StaffMode aktiviert Vanish NICHT automatisch

Vanish darf keine `supersee`-Permission besitzen, die die Ranghierarchie pauschal umgeht.

---

## 5.3 StaffMode

Command:

`/staffmode`

StaffMode muss:

- normalen Zustand VOR Mutation persistent snapshotten
- Inventar, Armor, Offhand, Cursor, XP, Level, Gamemode, Health, Food, Saturation, Flight, Effects, Server/Welt/Position/Blickrichtung und alle veränderten Zustände sicher erfassen
- Staff-Inventar/GUI bereitstellen
- nur wenige Hotbar-Tools; zentrales hochwertiges GUI bevorzugen
- Serverwechsel überleben
- Origin-Server kennen
- beim Beenden ggf. zurück zum Origin routen
- bei Origin offline NICHT unsicher auf anderem Server restaurieren
- Crash/Disconnect/Backend-Restart/Proxy-Restart überleben
- keine Items addieren, sondern deterministisch SETzen
- niemals einen aktiven Snapshot überschreiben
- keine Dupe-/Itemverlust-Möglichkeit
- `RECOVERY_REQUIRED` sauber behandeln
- Recovery-Fehler immer loggen und auditen

Keine extra `/staffpanic`-Pflicht. `/staffmode` ist Toggle/Exit.

---

## 5.4 Staff-Haupt-GUI

Sehr detailliertes, serverseitig abgesichertes GUI.

Mindestens Bereiche:

- Spieler suchen
- Online-Spieler
- Tickets/Reports
- mir zugewiesen
- High/Critical/Escalated
- Punishments
- Notes
- StaffChat
- Staff online
- Staff Activity (Admin/Owner)
- Logs
- Vanish
- Spectate
- Freeze
- Serverstatus
- eigene Settings

Anforderungen:

- Pagination
- Suche
- Filter
- Sortierung
- Zurücknavigation
- Permission-Recheck bei Aktion
- serverseitige Action-ID, niemals Itemname/Lore als Authority
- Bestätigung für gefährliche Aktionen
- stale revisions verhindern Last-Write-Wins

---

## 5.5 Inspect / technische Spielerdaten

`/inspect <spieler>` + GUI.

Soweit tatsächlich verfügbar:

- Name/UUID
- bekannte Namen
- Online/Offline
- Server
- Ping
- Protocol-Version
- Client Brand
- erkennbarer Modloader/Plugin-Channels
- niemals behaupten, alle installierten Mods zu kennen
- First/Last Join
- Sessiondauer
- Gesamtplaytime / pro Server
- Gamemode
- Health/Food/XP
- Welt/Position
- Effects
- Tickets
- Punishments
- Notes
- Freeze/Staff states
- letzte Moderationsaktionen

IP nur mit eigener Permission `staffcore.inspect.ip`, nicht unnötig langfristig persistieren und Zugriff auditieren.

Inventory View und Edit getrennt:

- `staffcore.inspect.inventory`
- `staffcore.inspect.inventory.edit`

Live-Edit mit Lease/Baseline/Revision und Audit; keine Dupe-/Last-Write-Wins-Probleme.

---

## 5.6 Freeze

Commands:

- `/freeze <spieler>`
- `/unfreeze <spieler>`

Gefreezter Spieler:

- kann sich nicht bewegen/jumpen/sprinten
- keine Items nutzen/drop/pickup
- keine relevante Inventarmanipulation
- keine unerlaubten Commands
- keine Teleport-/Portal-/Vehicle-Umgehung
- verursacht keinen Schaden / möglichst geschützt
- **DARF normal im Chat schreiben**, solange nicht separat gemutet

Freeze ist persistent und netzwerkweit.

### Freeze-Leave

Bei echtem Velocity-Netzwerk-Disconnect eines gefreezten Spielers:

1. nicht bei normalem Backend-Wechsel auslösen
2. letzte Position/Server persistieren
3. genau einen idempotenten System-TempGlobalBan erstellen
4. Standarddauer 5 Minuten, konfigurierbar
5. Grund sinngemäß `Leave while frozen`
6. Freeze bleibt NACH Ban-Ablauf bestehen
7. Staff Alert + Audit + persistente Notification
8. nach erneutem Join weiterhin frozen bis `/unfreeze`

### WICHTIG: sichtbare Freeze-Leave-Figur ist ein Pflichtwunsch

Der aktuelle Source behandelt den Fake Body offenbar als optional/deaktiviert. Der User wollte jedoch ausdrücklich, dass beim Leave **eine sichtbare Figur an der letzten Position zurückbleibt**.

Implementiere deshalb eine stabile Version mit öffentlichen Paper-APIs, ohne NMS-/fragile Packet-Abhängigkeit.

Akzeptable robuste Umsetzung:

- eine rein visuelle, nicht interaktive, unverwundbare, kollisionslose öffentliche-API-Repräsentation am letzten Standort,
- idealerweise ArmorStand/Display-Kombination mit Spielername und wenn zuverlässig möglich Player-Head/Profile,
- klar als Freeze-/Offline-Figur erkennbar,
- kein Gameplay-Einfluss,
- keine Drops,
- keine Interaktion/Schaden,
- beim Rejoin oder `/unfreeze` entfernen,
- bei Backend-Restart aus persistentem Freeze-/Position-State wiederherstellen, sofern Spieler noch offline+frozen ist,
- keine NMS-Pflicht.

Wenn eine exakte vollständige Spieler-Skin-Figur ohne NMS nicht stabil möglich ist, ist eine hochwertige öffentliche-API-Ersatzdarstellung akzeptabel. **Das Feature selbst darf aber nicht einfach komplett fehlen.**

Dokumentation/`KNOWN_LIMITATIONS.md` entsprechend aktualisieren.

---

## 5.7 Spectate

- `/spectate <spieler>` -> Spectator, Vanish unverändert
- `/spectate super <spieler>` -> Spectator + temporärer Vanish/Fake-Leave, falls vorher nicht vanished
- `/spectate stop`

Beim Ende exakt herstellen:

- Originserver
- Position
- Gamemode
- ursprünglicher Vanish-Zustand

War Staff vorher schon vanished, beim Stop NICHT entvanishen.

---

## 5.8 StaffChat

- `/sc <nachricht>`
- `/sc` als Toggle
- netzwerkweit
- Toggle bleibt über Backendwechsel erhalten
- bei Toggle wird normale Chatnachricht nicht öffentlich gesendet
- Sender sieht klar, dass es StaffChat war
- andere berechtigte Staff netzwerkweit erhalten sie
- Format enthält optional Server/Rank/Name
- Vanish-/Rank-Hierarchie darf keine höher gestuften Staff an unberechtigte niedrigere Staff leaken, wo relevant

Wichtige Aktionen und Zustandsänderungen auditieren.

---

## 5.9 Tickets / Reports

Spieler können über GUI melden:

- Spieler
- Bugs
- Serverprobleme
- Hilfe/Fragen
- Staff
- Sonstiges

Spieler können:

- eigenes Ticket sehen
- Status sehen
- Staffantworten lesen
- darauf antworten
- Verlauf sehen

Staff-GUI:

- offen
- mir zugewiesen
- unzugewiesen
- High
- Critical
- Escalated
- Waiting for Player
- gelöst/geschlossen/abgelehnt
- Suche
- Verlauf

Aktionen:

- claim/release
- reply
- interne Note
- Status
- priority
- escalate
- player inspect
- teleport
- spectate
- freeze
- punishment GUI
- close/reject/reopen
- reassign

Doppelclaims atomar via CAS/Revision.

Höhere Staff dürfen Entscheidungen niedrigerer Staff ändern; dabei:

- alter Staff benachrichtigen
- Ticket-Ersteller benachrichtigen, wenn relevant
- Audit mit alt/neu/Actor/Grund
- niedrigere Staff dürfen höhere Entscheidungen nicht still überschreiben

### Priority Engine

KEINE externe KI in v1.

Regelbasiert, deterministisch, erklärbar:

- LOW/NORMAL/HIGH/CRITICAL
- Kategorie
- Subcategory
- Ticketalter
- ähnliche Reports
- mehrere Reports gegen Ziel
- Server-/Netzwerkrelevanz
- Crash/Datenverlust/Dupe/Security/Exploit höher gewichten
- Reopen/Eskalation/Freeze/Outage-Faktoren
- Mindest-Staff-Level empfehlen

Priority Engine darf niemals automatisch bestrafen.

### Assignment Engine

Faire Verteilung:

- Staff online
- Rank
- Permissions
- aktuelle Last
- Capacity
- Ticket-Kategorie/Priority
- least-recently-assigned als Tie-Breaker
- niedrigsten ausreichenden Staff-Level bevorzugen

Nicht 282 Tickets an eine Person geben.

Wenn ein Mod „zum Owner“ eskaliert, soll Routing prüfen, ob SrMod/Admin genügt.

---

## 5.10 Punishments

Unterstützen:

- Warn
- Kick
- Mute
- TempMute
- Unmute
- ServerBan
- TempServerBan
- ServerUnban
- GlobalBan
- TempGlobalBan
- GlobalUnban

### ServerBan

- nur ausgewählter Backendserver
- Spieler darf andere Server weiter nutzen
- bei Connect zum gesperrten Backend sauber blockieren
- kein Fallback-Loop

### GlobalBan

- gesamtes Netzwerk
- eigene Permission `staffcore.punishment.globalban`
- standardmäßig nur Admin/Owner in empfohlener Permission-Matrix
- NICHT hardcoded anhand Rangname, sondern Permission serverseitig prüfen

### Mute

- normaler Chat aus
- StaffCore-PMs `/msg`, `/reply` etc. aus
- bekannte konfigurierte Aliase blockieren
- Freeze allein blockiert Chat NICHT

### Punishment GUI

Detailliert:

- Scope
- Typ
- Dauer
- Grund
- Beschreibung
- betroffener Server
- Vorschau
- Bestätigung
- History
- Revoke

Kein separates Upload-/Evidence-System erforderlich; ausführliche Beschreibung reicht.

### Idempotency

- kritische Aktionen idempotent
- temporäre Dauer/Expiry muss bei manuellen temporären Punishments Teil der Eindeutigkeit sein
- doppelte Requests dürfen nicht zwei Strafen erzeugen

---

## 5.11 Notes / Logs / Activity

Staff Notes:

- intern
- Autor
- Zeit
- Edit-History
- Archive statt stilles Hard-Delete
- höhere Staff dürfen niedriger erstellte Notes korrigieren/archivieren mit Audit

Audit:

Hauptlogs mindestens:

- Punishments
- Ticket status/reassign/override/escalate
- Freeze/unfreeze/freeze leave
- Inventory Edit
- Staff Notes
- GlobalBan/Unban
- StaffMode recovery

Nebenlogs:

- Vanish toggle
- StaffMode toggle
- Spectate start/stop
- StaffChat toggle
- GUI administrative changes

GUI-Suche nach:

- Spieler
- Staff
- Ticket-ID
- Punishment-ID
- Zeitraum
- Aktion
- Server

Staff Activity nur standardmäßig Admin/Owner; keine öffentliche Wettbewerbsrangliste.

---

## 5.12 Notifications

Persistente Inbox für relevante Events:

- Ticket assignment
- Critical ticket
- Reply
- Ticket change
- Override
- Eskalation
- Freeze leave
- Punishment-relevante Meldung

Read/unread, keine Spam-Flut, Delivery-Ausfall darf Moderationscommit nicht zurückrollen.

---

## 5.13 Cross-Server Protocol

Mindestens:

- versioniertes Envelope
- Message-ID
- Type allow-list
- timestamp
- HMAC-SHA256
- Payloadlimit
- Replay/Dedupe
- Revision/stale rejection
- validierte Sender/Empfänger

Kein Client darf über Plugin Channels vertrauenswürdige Staff-Aktionen injizieren können.

Bridge Message Sender und Empfänger vollständig abgleichen.

---

## 5.14 Presence

Velocity ist Authority.

Erforderlich:

- Session beim Login
- Backendwechsel atomar
- periodischer Heartbeat
- Disconnect cleanup
- beim Proxy-Start und periodisch stale-session cleanup
- keine aktiven Sessions aufgrund zu kurzer/fehlender Heartbeats fälschlich löschen
- Scheduler bei Shutdown sauber abbrechen

Verifiziere den bereits implementierten Fix.

---

## 5.15 Datenbank / Recovery

MariaDB Source of Truth.

- HikariCP
- Flyway forward-only migrations
- PreparedStatements
- sinnvolle Indizes
- UUID als Identität
- keine DB Queries auf Paper Mainthread
- kritische Mutationen committen, dann erst Erfolg melden
- Outbox für retrybare Folgeevents
- CAS/Revision wo konkurrierende Mutationen möglich

DB-Ausfall:

- kritische neue Mutationen fail-closed
- bereits validierte Enforcement-Caches dürfen weiterwirken
- keine pauschale Netzwerk-Lockout nur wegen kurzer DB-Störung
- keine unbounded Fake-Queue für kritische Wahrheit
- Health sichtbar

---

# 6. MaintenanceCore Integration

Unter `Reference/MaintenanceCore/` liegt die Source meines vorhandenen MaintenanceCore-Plugins.

Gewünschte StaffCore-Funktion:

- im Staff-GUI Wartungsstatus von Velocity-Servern **anzeigen**
- StaffCore muss ohne MaintenanceCore starten
- StaffCore soll Wartung derzeit NICHT zwingend steuern

Prüfe MaintenanceCore-Source.

Wenn dort noch keine saubere öffentliche API/Velocity-Service vorhanden ist:

- implementiere vorzugsweise eine kleine read-only ServiceManager-Schnittstelle in einer **separaten korrigierten MaintenanceCore-Source-Version**, ohne die Wartungslogik zu beschädigen,
- StaffCore entdeckt den Service optional,
- keine harte Classloading-Abhängigkeit, die StaffCore ohne MaintenanceCore crashen lässt.

Wenn dies den Haupt-StaffCore-Abschluss unverhältnismäßig blockieren würde, StaffCore sauber kapseln und exakt dokumentieren, welche minimale MaintenanceCore-Änderung noch erforderlich ist. Aber versuche die konkrete Integration, da die Source mitgeliefert ist.

---

# 7. Tests

Bestehende Tests prüfen und ergänzen.

Mindestens pure Unit Tests für:

- StaffHierarchy / Vanish visibility
- striktes `/stafflist` lower-rank behavior
- Duration Parser
- Priority Engine
- Assignment Engine
- StaffMode transitions
- Freeze transitions
- Spectate transitions
- Vanish transitions
- Punishment expiry/scopes/idempotency
- Protocol HMAC/clock skew/replay/limits
- Input limits

DB Integration wenn Umgebung erlaubt:

- Flyway leer -> latest
- CRUD
- Ticket CAS/double claim
- Freeze Leave genau ein Punishment
- StaffMode snapshot uniqueness/recovery
- Inventory edit leases
- manual temporary punishment idempotency with duration
- Presence stale cleanup

Keine Tests löschen, nur um Build grün zu bekommen.

---

# 8. Runtime-Testplan

Wenn echte Minecraft-Runtime in deiner Umgebung nicht möglich ist, nicht vortäuschen.

Dokumentiere trotzdem genaue Testschritte für:

- 1 Velocity
- 3 Paper: lobby/survival/events
- MariaDB
- normal player
- JrMod/Mod
- Admin/Owner

Kritische Runtime-Cases:

- vanish hierarchy
- no 1-tick leak on backend switch
- fake leave/join once
- staffmode snapshot/restore/crash
- freeze chat allowed
- freeze leave -> body + one 5m ban + still frozen
- spectate normal/super restore
- staffchat cross-server
- ticket claim/routing/override
- serverban only backend
- globalban network
- mute
- inventory edit conflict
- DB 30–60s outage/recovery

---

# 9. PROJECT_MANIFEST / Docs

Am Ende anhand der **tatsächlich vorhandenen Dateien und tatsächlichen Implementierung** aktualisieren:

- `PROJECT_MANIFEST.md`
- `README.md`
- `BUILD_REPORT.md`
- `docs/KNOWN_LIMITATIONS.md`
- `docs/RUNTIME_TEST_PLAN.md`
- `docs/PERMISSIONS.md`
- ggf. `CHANGELOG.md`

Nichts als DONE markieren, nur weil es geplant ist.

`KNOWN_LIMITATIONS.md` darf echte Grenzen nennen, aber nicht ein vom User gefordertes Pflichtfeature einfach als „optional“ wegdefinieren, wenn eine stabile öffentliche-API-Variante möglich ist.

---

# 10. Definition of Done

`Source vollständig: JA` darf nur ausgegeben werden, wenn:

- alle Pflichtfunktionen Source-seitig vorhanden
- keine Pflicht-TODOs/Stubs/Pseudocode
- Commands/Permissions/Listener/GUI/Bridge/Config/DB abgeglichen
- Manifest aktuell
- Freeze-Leave-Figur in stabiler öffentlicher-API-Form vorhanden
- StaffList lower-rank-Regel korrekt

`Maven-Build: JA` nur wenn ein echter Java-25 `mvn clean verify`/`./mvnw clean verify` erfolgreich durchlief.

`Runtime getestet: JA` nur wenn echte Velocity/Paper-Tests wirklich ausgeführt wurden.

Keine erfundenen JARs.

---

# 11. Gewünschte Endartefakte

Wenn technisch möglich, liefere am Ende:

1. korrigiertes vollständiges `StaffCore-source-final.zip`
2. `staffcore-velocity-...-all.jar` — nur aus echtem erfolgreichen Build
3. `staffcore-paper-...-all.jar` — nur aus echtem erfolgreichen Build
4. SHA256 der JARs und Source-ZIP
5. finalen `BUILD_REPORT.md`
6. finale `PROJECT_MANIFEST.md`
7. ggf. aktualisierte MaintenanceCore-Source/JAR, falls du für die read-only Integration eine Service-API ergänzt hast

Wenn dein Chat keine Dateien direkt patchen kann:

- gib trotzdem nicht nur Analyse aus,
- liefere die konkret korrigierten vollständigen Dateien/Änderungen in nachvollziehbaren Batches,
- priorisiere Build-/Compile-Blocker und die oben genannten Pflichtabweichungen.

---

# 12. Endausgabe

Am Ende knapp und wahrheitsgemäß:

```text
Source vollständig: JA/NEIN
Statische Prüfung: JA/NEIN
Java-25 Maven-Build: JA/NEIN
Tests ausgeführt: JA/NEIN
Runtime getestet: JA/NEIN
Velocity-JAR: <Datei oder NICHT ERZEUGT>
Paper-JAR: <Datei oder NICHT ERZEUGT>
Source-ZIP: <Datei>
MaintenanceCore-Integration: JA/NEIN/TEILWEISE
Freeze-Leave-Figur: JA/NEIN
Verbleibende Probleme: ...
```

**Beginne jetzt mit der vollständigen Inventur des vorhandenen StaffCore-Projekts. Schreibe es nicht neu. Versuche danach sofort den echten Build und arbeite alle gefundenen Fehler und Pflichtabweichungen bis zum bestmöglichen finalen Stand ab. Stoppe nicht nach einer Zwischenzusammenfassung.**
