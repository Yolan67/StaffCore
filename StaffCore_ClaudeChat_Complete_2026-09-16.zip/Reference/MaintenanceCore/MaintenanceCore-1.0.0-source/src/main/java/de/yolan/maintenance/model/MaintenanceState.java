package de.yolan.maintenance.model;

public enum MaintenanceState {
    ONLINE,
    COUNTDOWN,
    MAINTENANCE
}
