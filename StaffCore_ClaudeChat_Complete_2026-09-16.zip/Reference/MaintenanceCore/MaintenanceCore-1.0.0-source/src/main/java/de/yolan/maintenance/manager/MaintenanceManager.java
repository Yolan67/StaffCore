package de.yolan.maintenance.manager;

import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import com.velocitypowered.api.scheduler.ScheduledTask;
import de.yolan.maintenance.config.MaintenanceConfig;
import de.yolan.maintenance.model.MaintenanceState;
import de.yolan.maintenance.storage.MaintenanceStorage;
import de.yolan.maintenance.util.TextUtil;
import org.slf4j.Logger;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public final class MaintenanceManager {
    public static final String ADMIN_PERMISSION = "maintenance.admin";
    public static final String BYPASS_PERMISSION = "maintenance.bypass";

    private final ProxyServer proxy;
    private final Object plugin;
    private final Logger logger;
    private final MaintenanceConfig config;
    private final MaintenanceStorage storage;
    private final TextUtil text;

    private final ConcurrentHashMap<String, MaintenanceState> states = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, CountdownContext> countdowns = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Object> locks = new ConcurrentHashMap<>();
    private final AtomicBoolean shuttingDown = new AtomicBoolean(false);

    public MaintenanceManager(ProxyServer proxy,
                              Object plugin,
                              Logger logger,
                              MaintenanceConfig config,
                              MaintenanceStorage storage,
                              TextUtil text) {
        this.proxy = proxy;
        this.plugin = plugin;
        this.logger = logger;
        this.config = config;
        this.storage = storage;
        this.text = text;
    }

    public void initialize() {
        Map<String, MaintenanceState> loaded = storage.load();
        int promotedCountdowns = 0;
        int ignoredOrphans = 0;

        for (RegisteredServer server : proxy.getAllServers()) {
            String key = key(server.getServerInfo().getName());
            MaintenanceState saved = loaded.remove(key);
            if (saved == MaintenanceState.COUNTDOWN) {
                saved = MaintenanceState.MAINTENANCE;
                promotedCountdowns++;
            }
            states.put(key, saved == MaintenanceState.MAINTENANCE ? MaintenanceState.MAINTENANCE : MaintenanceState.ONLINE);
        }

        ignoredOrphans = loaded.size();
        if (promotedCountdowns > 0) {
            logger.info("MaintenanceCore: {} COUNTDOWN-State(s) nach Neustart sicher zu MAINTENANCE hochgestuft.", promotedCountdowns);
        }
        if (ignoredOrphans > 0) {
            logger.info("MaintenanceCore: {} verwaiste state.yml-Einträge ignoriert und beim nächsten Speichern entfernt.", ignoredOrphans);
        }
        persist();
    }

    public boolean isInMaintenance(String serverName) {
        return getState(serverName) == MaintenanceState.MAINTENANCE;
    }

    public boolean isRestricted(String serverName) {
        MaintenanceState state = getState(serverName);
        return state == MaintenanceState.COUNTDOWN || state == MaintenanceState.MAINTENANCE;
    }

    public MaintenanceState getState(String serverName) {
        return states.getOrDefault(key(serverName), MaintenanceState.ONLINE);
    }

    public int getRemainingSeconds(String serverName) {
        CountdownContext context = countdowns.get(key(serverName));
        return context == null ? 0 : Math.max(0, context.remaining.get());
    }

    public Optional<RegisteredServer> findRegisteredServer(String input) {
        String wanted = key(input);
        return proxy.getAllServers().stream()
                .filter(server -> key(server.getServerInfo().getName()).equals(wanted))
                .findFirst();
    }

    public List<RegisteredServer> getRegisteredServersSorted() {
        return proxy.getAllServers().stream()
                .sorted(Comparator.comparing(server -> server.getServerInfo().getName(), String.CASE_INSENSITIVE_ORDER))
                .toList();
    }

    public StartResult startMaintenance(RegisteredServer server) {
        String name = server.getServerInfo().getName();
        String key = key(name);
        Object lock = lockFor(key);

        synchronized (lock) {
            MaintenanceState state = states.getOrDefault(key, MaintenanceState.ONLINE);
            if (state == MaintenanceState.MAINTENANCE) {
                return StartResult.ALREADY_MAINTENANCE;
            }
            if (state == MaintenanceState.COUNTDOWN) {
                return StartResult.ALREADY_COUNTDOWN;
            }

            int seconds = config.countdownSeconds();
            CountdownContext context = new CountdownContext(seconds);
            states.put(key, MaintenanceState.COUNTDOWN);
            countdowns.put(key, context);
            persist();

            if (config.countdownAnnouncements().contains(seconds)) {
                broadcastCountdown(server, seconds);
            }

            try {
                ScheduledTask task = proxy.getScheduler()
                        .buildTask(plugin, scheduledTask -> tick(key, context, scheduledTask))
                        .delay(1L, TimeUnit.SECONDS)
                        .repeat(1L, TimeUnit.SECONDS)
                        .schedule();
                context.task = task;
                logger.info("MaintenanceCore: Countdown für '{}' gestartet ({}s).", name, seconds);
                return StartResult.STARTED;
            } catch (RuntimeException ex) {
                context.cancelled.set(true);
                countdowns.remove(key, context);
                states.put(key, MaintenanceState.ONLINE);
                persist();
                logger.error("MaintenanceCore: Scheduler konnte Countdown für '{}' nicht starten.", name, ex);
                return StartResult.FAILED;
            }
        }
    }

    private void tick(String serverKey, CountdownContext context, ScheduledTask scheduledTask) {
        Object lock = lockFor(serverKey);
        synchronized (lock) {
            if (shuttingDown.get()
                    || context.cancelled.get()
                    || countdowns.get(serverKey) != context
                    || states.getOrDefault(serverKey, MaintenanceState.ONLINE) != MaintenanceState.COUNTDOWN) {
                scheduledTask.cancel();
                return;
            }

            int remaining = context.remaining.decrementAndGet();
            if (remaining > 0) {
                if (config.countdownAnnouncements().contains(remaining)) {
                    findRegisteredServer(serverKey).ifPresent(server -> broadcastCountdown(server, remaining));
                }
                return;
            }

            context.cancelled.set(true);
            countdowns.remove(serverKey, context);
            scheduledTask.cancel();
            states.put(serverKey, MaintenanceState.MAINTENANCE);
            persist();

            Optional<RegisteredServer> serverOptional = findRegisteredServer(serverKey);
            if (serverOptional.isEmpty()) {
                logger.info("MaintenanceCore: Wartung für '{}' aktiviert; Backend ist aktuell nicht registriert.", serverKey);
                return;
            }

            RegisteredServer server = serverOptional.get();
            List<Player> players = new ArrayList<>(server.getPlayersConnected());
            for (Player player : players) {
                player.sendMessage(text.message("maintenance-active", false));
            }

            int kicked = 0;
            for (Player player : players) {
                if (player.hasPermission(BYPASS_PERMISSION)) {
                    continue;
                }
                player.disconnect(text.message("kick", false,
                        TextUtil.placeholders("server", server.getServerInfo().getName())));
                kicked++;
            }
            logger.info("MaintenanceCore: Wartung für '{}' aktiviert; {} Spieler getrennt.", server.getServerInfo().getName(), kicked);
        }
    }

    public StopResult stopMaintenance(RegisteredServer server) {
        String name = server.getServerInfo().getName();
        String key = key(name);
        Object lock = lockFor(key);

        synchronized (lock) {
            MaintenanceState state = states.getOrDefault(key, MaintenanceState.ONLINE);
            if (state == MaintenanceState.ONLINE) {
                return StopResult.ALREADY_ONLINE;
            }

            if (state == MaintenanceState.COUNTDOWN) {
                CountdownContext context = countdowns.remove(key);
                if (context != null) {
                    context.cancelled.set(true);
                    ScheduledTask task = context.task;
                    if (task != null) {
                        task.cancel();
                    }
                }
                states.put(key, MaintenanceState.ONLINE);
                persist();
                broadcast(server, text.message("countdown-cancelled", false,
                        TextUtil.placeholders("server", name)));
                logger.info("MaintenanceCore: Countdown für '{}' abgebrochen.", name);
                return StopResult.COUNTDOWN_CANCELLED;
            }

            states.put(key, MaintenanceState.ONLINE);
            persist();
            logger.info("MaintenanceCore: Wartung für '{}' deaktiviert.", name);
            return StopResult.MAINTENANCE_DISABLED;
        }
    }

    public AllStartResult startAll() {
        int started = 0;
        int skipped = 0;
        int failed = 0;
        List<RegisteredServer> servers = new ArrayList<>(proxy.getAllServers());
        for (RegisteredServer server : servers) {
            StartResult result = startMaintenance(server);
            switch (result) {
                case STARTED -> started++;
                case FAILED -> failed++;
                case ALREADY_COUNTDOWN, ALREADY_MAINTENANCE -> skipped++;
            }
        }
        logger.info("MaintenanceCore: all on -> {} gestartet, {} bereits eingeschränkt, {} fehlgeschlagen.", started, skipped, failed);
        return new AllStartResult(started, skipped, failed);
    }

    public AllStopResult stopAll() {
        int changed = 0;
        int alreadyOnline = 0;
        List<RegisteredServer> servers = new ArrayList<>(proxy.getAllServers());
        for (RegisteredServer server : servers) {
            StopResult result = stopMaintenance(server);
            if (result == StopResult.ALREADY_ONLINE) {
                alreadyOnline++;
            } else {
                changed++;
            }
        }
        logger.info("MaintenanceCore: all off -> {} deaktiviert/abgebrochen, {} bereits online.", changed, alreadyOnline);
        return new AllStopResult(changed, alreadyOnline);
    }

    public void registerServer(RegisteredServer server) {
        String key = key(server.getServerInfo().getName());
        states.putIfAbsent(key, MaintenanceState.ONLINE);
        persist();
        logger.info("MaintenanceCore: Neuer Velocity-Server '{}' erkannt; State {}.",
                server.getServerInfo().getName(), states.get(key));
    }

    public void unregisterServer(RegisteredServer server) {
        String key = key(server.getServerInfo().getName());
        Object lock = lockFor(key);
        synchronized (lock) {
            CountdownContext context = countdowns.remove(key);
            if (context != null) {
                context.cancelled.set(true);
                if (context.task != null) {
                    context.task.cancel();
                }
            }
            states.remove(key);
            persist();
            logger.info("MaintenanceCore: Entfernten Velocity-Server '{}' aus dem aktiven State entfernt.", server.getServerInfo().getName());
        }
    }

    public void shutdown() {
        if (!shuttingDown.compareAndSet(false, true)) {
            return;
        }
        for (CountdownContext context : countdowns.values()) {
            context.cancelled.set(true);
            if (context.task != null) {
                context.task.cancel();
            }
        }
        // States bleiben unverändert: COUNTDOWN wird beim nächsten Start zu MAINTENANCE.
        persist();
    }

    private void broadcastCountdown(RegisteredServer server, int seconds) {
        broadcast(server, text.message("countdown", false,
                TextUtil.placeholders(
                        "server", server.getServerInfo().getName(),
                        "seconds", seconds)));
    }

    private static void broadcast(RegisteredServer server, net.kyori.adventure.text.Component component) {
        List<Player> snapshot = new ArrayList<>(server.getPlayersConnected());
        for (Player player : snapshot) {
            player.sendMessage(component);
        }
    }

    private Object lockFor(String serverKey) {
        return locks.computeIfAbsent(serverKey, ignored -> new Object());
    }

    private void persist() {
        Map<String, MaintenanceState> snapshot = new LinkedHashMap<>();
        for (RegisteredServer server : proxy.getAllServers()) {
            String key = key(server.getServerInfo().getName());
            snapshot.put(key, states.getOrDefault(key, MaintenanceState.ONLINE));
        }
        storage.save(snapshot);
    }

    private static String key(String serverName) {
        return serverName.toLowerCase(Locale.ROOT);
    }

    public enum StartResult {
        STARTED,
        ALREADY_COUNTDOWN,
        ALREADY_MAINTENANCE,
        FAILED
    }

    public enum StopResult {
        COUNTDOWN_CANCELLED,
        MAINTENANCE_DISABLED,
        ALREADY_ONLINE
    }

    public record AllStartResult(int started, int skipped, int failed) {
    }

    public record AllStopResult(int changed, int alreadyOnline) {
    }

    private static final class CountdownContext {
        private final AtomicInteger remaining;
        private final AtomicBoolean cancelled = new AtomicBoolean(false);
        private volatile ScheduledTask task;

        private CountdownContext(int seconds) {
            this.remaining = new AtomicInteger(seconds);
        }
    }
}
