package de.yolan.maintenance;

import com.google.inject.Inject;
import com.velocitypowered.api.command.CommandMeta;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.proxy.ProxyInitializeEvent;
import com.velocitypowered.api.event.proxy.ProxyShutdownEvent;
import com.velocitypowered.api.plugin.Plugin;
import com.velocitypowered.api.plugin.annotation.DataDirectory;
import com.velocitypowered.api.proxy.ProxyServer;
import de.yolan.maintenance.command.MaintenanceCommand;
import de.yolan.maintenance.config.MaintenanceConfig;
import de.yolan.maintenance.listener.ServerConnectionListener;
import de.yolan.maintenance.manager.MaintenanceManager;
import de.yolan.maintenance.storage.MaintenanceStorage;
import de.yolan.maintenance.util.TextUtil;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.file.Path;

@Plugin(
        id = "maintenancecore",
        name = "MaintenanceCore",
        version = "1.0.0",
        description = "Zentrales Wartungssystem für ein Velocity-Netzwerk.",
        authors = {"Yolan"}
)
public final class MaintenancePlugin {
    private final ProxyServer proxy;
    private final Logger logger;
    private final Path dataDirectory;

    private MaintenanceManager manager;

    @Inject
    public MaintenancePlugin(ProxyServer proxy, Logger logger, @DataDirectory Path dataDirectory) {
        this.proxy = proxy;
        this.logger = logger;
        this.dataDirectory = dataDirectory;
    }

    @Subscribe
    public void onProxyInitialize(ProxyInitializeEvent event) {
        try {
            MaintenanceConfig config = MaintenanceConfig.load(dataDirectory, logger);
            TextUtil text = new TextUtil(config);
            MaintenanceStorage storage = new MaintenanceStorage(dataDirectory, logger);

            manager = new MaintenanceManager(proxy, this, logger, config, storage, text);
            manager.initialize();

            proxy.getEventManager().register(this, new ServerConnectionListener(manager, text));

            MaintenanceCommand command = new MaintenanceCommand(manager, config, text);
            CommandMeta meta = proxy.getCommandManager()
                    .metaBuilder("wartungsarbeiten")
                    .plugin(this)
                    .build();
            proxy.getCommandManager().register(meta, command);

            logger.info("MaintenanceCore 1.0.0 gestartet. Registrierte Server: {}.", proxy.getAllServers().size());
        } catch (IOException ex) {
            logger.error("MaintenanceCore konnte wegen eines Konfigurationsfehlers nicht initialisiert werden.", ex);
        } catch (RuntimeException ex) {
            logger.error("MaintenanceCore konnte nicht initialisiert werden.", ex);
        }
    }

    @Subscribe
    public void onProxyShutdown(ProxyShutdownEvent event) {
        if (manager != null) {
            manager.shutdown();
        }
    }
}
