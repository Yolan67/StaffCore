package de.yolan.maintenance.command;

import com.velocitypowered.api.command.CommandSource;
import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import de.yolan.maintenance.config.MaintenanceConfig;
import de.yolan.maintenance.manager.MaintenanceManager;
import de.yolan.maintenance.model.MaintenanceState;
import de.yolan.maintenance.util.TextUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

public final class MaintenanceCommand implements SimpleCommand {
    private final MaintenanceManager manager;
    private final MaintenanceConfig config;
    private final TextUtil text;

    public MaintenanceCommand(MaintenanceManager manager, MaintenanceConfig config, TextUtil text) {
        this.manager = manager;
        this.config = config;
        this.text = text;
    }

    @Override
    public void execute(Invocation invocation) {
        CommandSource source = invocation.source();
        if (!isAdmin(source)) {
            source.sendMessage(text.message("no-permission", true));
            return;
        }

        String[] args = invocation.arguments();
        if (args.length == 1 && args[0].equalsIgnoreCase("list")) {
            sendList(source);
            return;
        }

        if (args.length != 2) {
            source.sendMessage(text.message("usage", true));
            return;
        }

        String target = args[0];
        String action = args[1].toLowerCase(Locale.ROOT);

        if (target.equalsIgnoreCase("all")) {
            handleAll(source, action);
            return;
        }

        Optional<RegisteredServer> serverOptional = manager.findRegisteredServer(target);
        if (serverOptional.isEmpty()) {
            String possible = manager.getRegisteredServersSorted().stream()
                    .map(server -> server.getServerInfo().getName())
                    .reduce((a, b) -> a + ", " + b)
                    .orElse("-");
            source.sendMessage(text.message("unknown-server", true,
                    TextUtil.placeholders("server", target, "servers", possible)));
            return;
        }

        RegisteredServer server = serverOptional.get();
        switch (action) {
            case "on" -> handleOn(source, server);
            case "off" -> handleOff(source, server);
            case "status" -> sendStatus(source, server);
            default -> source.sendMessage(text.message("usage", true));
        }
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (!isAdmin(invocation.source())) {
            return List.of();
        }

        String[] args = invocation.arguments();
        if (args.length <= 1) {
            String prefix = args.length == 0 ? "" : args[0].toLowerCase(Locale.ROOT);
            List<String> values = new ArrayList<>();
            values.add("all");
            values.add("list");
            manager.getRegisteredServersSorted().stream()
                    .map(server -> server.getServerInfo().getName())
                    .forEach(values::add);
            return values.stream()
                    .filter(value -> value.toLowerCase(Locale.ROOT).startsWith(prefix))
                    .toList();
        }

        if (args.length == 2 && !args[0].equalsIgnoreCase("list")) {
            String prefix = args[1].toLowerCase(Locale.ROOT);
            return List.of("on", "off", "status").stream()
                    .filter(value -> value.startsWith(prefix))
                    .toList();
        }
        return List.of();
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        // Absichtlich true: fehlende Rechte werden in execute() selbst behandelt.
        // So wird /wartungsarbeiten nicht an einen Backend-Server weitergereicht.
        return true;
    }

    private void handleOn(CommandSource source, RegisteredServer server) {
        String name = server.getServerInfo().getName();
        MaintenanceManager.StartResult result = manager.startMaintenance(server);
        switch (result) {
            case STARTED -> source.sendMessage(text.message("countdown-started", true,
                    TextUtil.placeholders("server", name, "seconds", config.countdownSeconds())));
            case ALREADY_COUNTDOWN -> source.sendMessage(text.message("already-countdown", true,
                    TextUtil.placeholders("server", name)));
            case ALREADY_MAINTENANCE -> source.sendMessage(text.message("already-maintenance", true,
                    TextUtil.placeholders("server", name)));
            case FAILED -> source.sendMessage(text.message("start-failed", true,
                    TextUtil.placeholders("server", name)));
        }
    }

    private void handleOff(CommandSource source, RegisteredServer server) {
        String name = server.getServerInfo().getName();
        MaintenanceManager.StopResult result = manager.stopMaintenance(server);
        switch (result) {
            case COUNTDOWN_CANCELLED -> source.sendMessage(text.message("countdown-cancelled", true,
                    TextUtil.placeholders("server", name)));
            case MAINTENANCE_DISABLED -> source.sendMessage(text.message("disabled", true,
                    TextUtil.placeholders("server", name)));
            case ALREADY_ONLINE -> source.sendMessage(text.message("already-online", true,
                    TextUtil.placeholders("server", name)));
        }
    }

    private void handleAll(CommandSource source, String action) {
        switch (action) {
            case "on" -> {
                MaintenanceManager.AllStartResult result = manager.startAll();
                source.sendMessage(text.message("all-started", true,
                        TextUtil.placeholders("started", result.started(), "skipped", result.skipped())));
                if (result.failed() > 0) {
                    source.sendMessage(text.message("all-failed", true,
                            TextUtil.placeholders("failed", result.failed())));
                }
            }
            case "off" -> {
                MaintenanceManager.AllStopResult result = manager.stopAll();
                source.sendMessage(text.message("all-disabled", true,
                        TextUtil.placeholders("changed", result.changed(), "skipped", result.alreadyOnline())));
            }
            case "status" -> sendList(source);
            default -> source.sendMessage(text.message("usage", true));
        }
    }

    private void sendStatus(CommandSource source, RegisteredServer server) {
        String name = server.getServerInfo().getName();
        MaintenanceState state = manager.getState(name);
        int playerCount = server.getPlayersConnected().size();
        long bypassCount = server.getPlayersConnected().stream()
                .filter(player -> player.hasPermission(MaintenanceManager.BYPASS_PERMISSION))
                .count();

        source.sendMessage(text.component("<red><bold>MaintenanceCore</bold></red>"));
        source.sendMessage(text.component("<gray>Server: <white>" + name + "</white></gray>"));
        source.sendMessage(text.component("<gray>Status: " + stateComponent(state) + "</gray>"));
        if (state == MaintenanceState.COUNTDOWN) {
            source.sendMessage(text.component("<gray>Restzeit: <yellow>" + manager.getRemainingSeconds(name) + " Sekunden</yellow></gray>"));
        }
        source.sendMessage(text.component("<gray>Spieler: <white>" + playerCount + "</white></gray>"));
        if (state == MaintenanceState.MAINTENANCE) {
            source.sendMessage(text.component("<gray>Bypass-Spieler online: <white>" + bypassCount + "</white></gray>"));
        }
    }

    private void sendList(CommandSource source) {
        List<RegisteredServer> servers = manager.getRegisteredServersSorted();
        source.sendMessage(text.message("list-header", false));
        int restricted = 0;
        for (RegisteredServer server : servers) {
            String name = server.getServerInfo().getName();
            MaintenanceState state = manager.getState(name);
            if (state != MaintenanceState.ONLINE) {
                restricted++;
            }
            String suffix = state == MaintenanceState.COUNTDOWN
                    ? " <gray>(" + manager.getRemainingSeconds(name) + "s)</gray>"
                    : "";
            source.sendMessage(text.component("<white>" + name + "</white>  " + stateComponent(state) + suffix));
        }
        source.sendMessage(text.message("list-footer", false,
                Map.of("restricted", restricted, "total", servers.size())));
    }

    private static String stateComponent(MaintenanceState state) {
        return switch (state) {
            case ONLINE -> "<green>ONLINE</green>";
            case COUNTDOWN -> "<yellow>COUNTDOWN</yellow>";
            case MAINTENANCE -> "<red>WARTUNG</red>";
        };
    }

    private static boolean isAdmin(CommandSource source) {
        return !(source instanceof Player) || source.hasPermission(MaintenanceManager.ADMIN_PERMISSION);
    }
}
