package de.yolan.maintenance.config;

import org.slf4j.Logger;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class MaintenanceConfig {
    private static final int DEFAULT_COUNTDOWN = 10;
    private static final Set<Integer> DEFAULT_ANNOUNCEMENTS = Set.of(10, 5, 4, 3, 2, 1);

    private final int countdownSeconds;
    private final Set<Integer> countdownAnnouncements;
    private final Map<String, String> messages;

    private MaintenanceConfig(int countdownSeconds, Set<Integer> countdownAnnouncements, Map<String, String> messages) {
        this.countdownSeconds = countdownSeconds;
        this.countdownAnnouncements = Collections.unmodifiableSet(new LinkedHashSet<>(countdownAnnouncements));
        this.messages = Collections.unmodifiableMap(new LinkedHashMap<>(messages));
    }

    public static MaintenanceConfig load(Path dataDirectory, Logger logger) throws IOException {
        Files.createDirectories(dataDirectory);
        Path configFile = dataDirectory.resolve("config.yml");
        ensureDefaultConfig(configFile);

        List<String> lines = Files.readAllLines(configFile, StandardCharsets.UTF_8);
        int countdown = DEFAULT_COUNTDOWN;
        Set<Integer> announcements = new LinkedHashSet<>();
        Map<String, String> messages = new LinkedHashMap<>();

        String section = "";
        String listKey = "";

        for (String rawLine : lines) {
            if (rawLine == null) {
                continue;
            }
            String trimmed = rawLine.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                continue;
            }

            int indent = countLeadingSpaces(rawLine);
            if (indent == 0 && trimmed.endsWith(":")) {
                section = trimmed.substring(0, trimmed.length() - 1).trim();
                listKey = "";
                continue;
            }

            if ("maintenance".equals(section)) {
                if (trimmed.startsWith("- ") && "countdown-announcements".equals(listKey)) {
                    String number = trimmed.substring(2).trim();
                    try {
                        int value = Integer.parseInt(number);
                        if (value > 0) {
                            announcements.add(value);
                        }
                    } catch (NumberFormatException ex) {
                        logger.warn("MaintenanceCore: Ignoriere ungültigen Countdown-Announcement-Wert '{}'.", number);
                    }
                    continue;
                }

                int colon = trimmed.indexOf(':');
                if (colon < 0) {
                    continue;
                }
                String key = trimmed.substring(0, colon).trim();
                String value = trimmed.substring(colon + 1).trim();
                listKey = key;

                if ("countdown-seconds".equals(key)) {
                    try {
                        countdown = Math.max(1, Integer.parseInt(value));
                    } catch (NumberFormatException ex) {
                        logger.warn("MaintenanceCore: Ungültiger countdown-seconds-Wert '{}'; verwende {}.", value, DEFAULT_COUNTDOWN);
                        countdown = DEFAULT_COUNTDOWN;
                    }
                }
                continue;
            }

            if ("messages".equals(section)) {
                int colon = trimmed.indexOf(':');
                if (colon < 0) {
                    continue;
                }
                String key = trimmed.substring(0, colon).trim();
                String value = trimmed.substring(colon + 1).trim();
                messages.put(key, parseScalar(value));
            }
        }

        if (announcements.isEmpty()) {
            announcements.addAll(DEFAULT_ANNOUNCEMENTS);
        }

        Map<String, String> defaults = defaultMessages();
        defaults.putAll(messages);
        return new MaintenanceConfig(countdown, announcements, defaults);
    }

    private static void ensureDefaultConfig(Path target) throws IOException {
        if (Files.exists(target)) {
            return;
        }
        try (InputStream in = MaintenanceConfig.class.getResourceAsStream("/config.yml")) {
            if (in == null) {
                throw new IOException("Gebündelte config.yml wurde nicht gefunden.");
            }
            Path temp = target.resolveSibling(target.getFileName() + ".tmp");
            Files.copy(in, temp, StandardCopyOption.REPLACE_EXISTING);
            try {
                Files.move(temp, target, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicMoveFailed) {
                Files.move(temp, target, StandardCopyOption.REPLACE_EXISTING);
            }
        }
    }

    private static int countLeadingSpaces(String line) {
        int count = 0;
        while (count < line.length() && line.charAt(count) == ' ') {
            count++;
        }
        return count;
    }

    private static String parseScalar(String value) {
        if (value.length() >= 2 && value.startsWith("\"") && value.endsWith("\"")) {
            value = value.substring(1, value.length() - 1);
            StringBuilder out = new StringBuilder(value.length());
            boolean escaped = false;
            for (int i = 0; i < value.length(); i++) {
                char c = value.charAt(i);
                if (!escaped && c == '\\') {
                    escaped = true;
                    continue;
                }
                if (escaped) {
                    switch (c) {
                        case 'n' -> out.append('\n');
                        case 't' -> out.append('\t');
                        case 'r' -> out.append('\r');
                        case '\\' -> out.append('\\');
                        case '"' -> out.append('"');
                        default -> {
                            out.append('\\');
                            out.append(c);
                        }
                    }
                    escaped = false;
                } else {
                    out.append(c);
                }
            }
            if (escaped) {
                out.append('\\');
            }
            return out.toString();
        }
        if (value.length() >= 2 && value.startsWith("'") && value.endsWith("'")) {
            return value.substring(1, value.length() - 1).replace("''", "'");
        }
        return value;
    }

    private static Map<String, String> defaultMessages() {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("prefix", "<dark_gray>[<red>Wartung</red>]</dark_gray> ");
        map.put("countdown", "<yellow><bold>⚠ WARTUNGSARBEITEN</bold></yellow>\n<gray><server> wird in <red><seconds></red> Sekunden für Wartungsarbeiten geschlossen.</gray>");
        map.put("maintenance-active", "<red><bold>WARTUNGSARBEITEN AKTIV</bold></red>");
        map.put("countdown-cancelled", "<green>Die angekündigten Wartungsarbeiten für <white><server></white> wurden abgebrochen.</green>");
        map.put("countdown-started", "<yellow>Wartungs-Countdown für <white><server></white> gestartet: <red><seconds></red> Sekunden.</yellow>");
        map.put("enabled", "<red>Wartungsmodus für <white><server></white> wurde aktiviert.</red>");
        map.put("disabled", "<green>Wartungsmodus für <white><server></white> wurde deaktiviert.</green>");
        map.put("join-denied", "<red><bold>WARTUNGSARBEITEN</bold></red>\n\n<gray>Der Server <white><server></white> ist aktuell nicht verfügbar.</gray>\n<gray>Bitte versuche es später erneut.</gray>");
        map.put("kick", "<red><bold>WARTUNGSARBEITEN</bold></red>\n\n<gray>Der Server <white><server></white> wurde für Wartungsarbeiten geschlossen.</gray>\n<gray>Bitte versuche es später erneut.</gray>");
        map.put("no-permission", "<red>Keine Berechtigung.</red>");
        map.put("unknown-server", "<red>Server <white><server></white> wurde nicht gefunden.</red> <gray>Mögliche Server: <servers></gray>");
        map.put("already-online", "<yellow><server> befindet sich bereits im normalen Betrieb.</yellow>");
        map.put("already-maintenance", "<yellow><server> befindet sich bereits im Wartungsmodus.</yellow>");
        map.put("already-countdown", "<yellow>Für <server> läuft bereits ein Wartungs-Countdown.</yellow>");
        map.put("usage", "<gray>Verwendung: <white>/wartungsarbeiten [server|all] [on|off|status]</white> oder <white>/wartungsarbeiten list</white></gray>");
        map.put("list-header", "<red><bold>MaintenanceCore</bold></red>");
        map.put("list-footer", "<gray><restricted>/<total> Server eingeschränkt</gray>");
        map.put("all-started", "<yellow>Wartungs-Countdown für <started> Server gestartet. Bereits eingeschränkt: <skipped>.</yellow>");
        map.put("all-disabled", "<green>Wartung für <changed> Server deaktiviert. Bereits online: <skipped>.</green>");
        map.put("start-failed", "<red>Countdown für <white><server></white> konnte nicht gestartet werden. Details stehen in der Proxy-Konsole.</red>");
        map.put("all-failed", "<red>Fehlgeschlagen: <failed> Server. Details stehen in der Proxy-Konsole.</red>");
        return map;
    }

    public int countdownSeconds() {
        return countdownSeconds;
    }

    public Set<Integer> countdownAnnouncements() {
        return countdownAnnouncements;
    }

    public String message(String key) {
        return messages.getOrDefault(key, "<red>Fehlende Nachricht: " + key + "</red>");
    }

    public List<String> messageKeys() {
        return new ArrayList<>(messages.keySet());
    }
}
