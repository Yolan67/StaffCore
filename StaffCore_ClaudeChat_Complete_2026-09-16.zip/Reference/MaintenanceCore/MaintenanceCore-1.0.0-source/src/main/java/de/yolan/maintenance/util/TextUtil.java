package de.yolan.maintenance.util;

import de.yolan.maintenance.config.MaintenanceConfig;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

import java.util.LinkedHashMap;
import java.util.Map;

public final class TextUtil {
    private final MaintenanceConfig config;
    private final MiniMessage miniMessage = MiniMessage.miniMessage();

    public TextUtil(MaintenanceConfig config) {
        this.config = config;
    }

    public Component message(String key, boolean includePrefix, Map<String, ?> placeholders) {
        String raw = (includePrefix ? config.message("prefix") : "") + config.message(key);
        return component(raw, placeholders);
    }

    public Component message(String key, boolean includePrefix) {
        return message(key, includePrefix, Map.of());
    }

    public Component component(String raw, Map<String, ?> placeholders) {
        String rendered = raw;
        for (Map.Entry<String, ?> entry : placeholders.entrySet()) {
            rendered = rendered.replace("<" + entry.getKey() + ">", String.valueOf(entry.getValue()));
        }
        return miniMessage.deserialize(rendered);
    }

    public Component component(String raw) {
        return component(raw, Map.of());
    }

    public static Map<String, Object> placeholders(Object... keyValues) {
        if (keyValues.length % 2 != 0) {
            throw new IllegalArgumentException("Placeholder arguments must be key/value pairs.");
        }
        Map<String, Object> map = new LinkedHashMap<>();
        for (int i = 0; i < keyValues.length; i += 2) {
            map.put(String.valueOf(keyValues[i]), keyValues[i + 1]);
        }
        return map;
    }
}
