package de.yolan.maintenance.storage;

import de.yolan.maintenance.model.MaintenanceState;
import org.slf4j.Logger;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MaintenanceStorage {
    private final Path stateFile;
    private final Logger logger;

    public MaintenanceStorage(Path dataDirectory, Logger logger) {
        this.stateFile = dataDirectory.resolve("state.yml");
        this.logger = logger;
    }

    public synchronized Map<String, MaintenanceState> load() {
        Map<String, MaintenanceState> states = new LinkedHashMap<>();
        if (!Files.exists(stateFile)) {
            return states;
        }

        try {
            List<String> lines = Files.readAllLines(stateFile, StandardCharsets.UTF_8);
            boolean inServers = false;
            for (String raw : lines) {
                String trimmed = raw.trim();
                if (trimmed.isEmpty() || trimmed.startsWith("#")) {
                    continue;
                }
                if (!raw.startsWith(" ") && trimmed.equals("servers:")) {
                    inServers = true;
                    continue;
                }
                if (!inServers || !raw.startsWith("  ")) {
                    continue;
                }

                int colon = trimmed.indexOf(':');
                if (colon <= 0) {
                    continue;
                }
                String server = trimmed.substring(0, colon).trim().toLowerCase(Locale.ROOT);
                String stateText = trimmed.substring(colon + 1).trim().toUpperCase(Locale.ROOT);
                try {
                    states.put(server, MaintenanceState.valueOf(stateText));
                } catch (IllegalArgumentException ex) {
                    logger.warn("MaintenanceCore: Ignoriere unbekannten gespeicherten State '{}' für '{}'.", stateText, server);
                }
            }
            logger.info("MaintenanceCore: {} gespeicherte Server-States geladen.", states.size());
        } catch (IOException ex) {
            logger.error("MaintenanceCore: state.yml konnte nicht geladen werden.", ex);
        }
        return states;
    }

    public synchronized boolean save(Map<String, MaintenanceState> states) {
        try {
            Files.createDirectories(stateFile.getParent());
            StringBuilder yaml = new StringBuilder("servers:\n");
            states.entrySet().stream()
                    .sorted(Map.Entry.comparingByKey(String.CASE_INSENSITIVE_ORDER))
                    .forEach(entry -> yaml.append("  ")
                            .append(entry.getKey())
                            .append(": ")
                            .append(entry.getValue().name())
                            .append('\n'));

            Path temp = stateFile.resolveSibling(stateFile.getFileName() + ".tmp");
            byte[] bytes = yaml.toString().getBytes(StandardCharsets.UTF_8);
            try (FileChannel channel = FileChannel.open(temp,
                    StandardOpenOption.CREATE,
                    StandardOpenOption.TRUNCATE_EXISTING,
                    StandardOpenOption.WRITE)) {
                ByteBuffer buffer = ByteBuffer.wrap(bytes);
                while (buffer.hasRemaining()) {
                    channel.write(buffer);
                }
                channel.force(true);
            }

            try {
                Files.move(temp, stateFile,
                        StandardCopyOption.ATOMIC_MOVE,
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (AtomicMoveNotSupportedException ex) {
                Files.move(temp, stateFile, StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (IOException ex) {
            logger.error("MaintenanceCore: state.yml konnte nicht atomar gespeichert werden.", ex);
            return false;
        }
    }
}
