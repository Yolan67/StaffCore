package de.yolan.maintenance.listener;

import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.player.ServerPreConnectEvent;
import com.velocitypowered.api.event.proxy.server.ServerRegisteredEvent;
import com.velocitypowered.api.event.proxy.server.ServerUnregisteredEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.server.RegisteredServer;
import de.yolan.maintenance.manager.MaintenanceManager;
import de.yolan.maintenance.util.TextUtil;

public final class ServerConnectionListener {
    private final MaintenanceManager manager;
    private final TextUtil text;

    public ServerConnectionListener(MaintenanceManager manager, TextUtil text) {
        this.manager = manager;
        this.text = text;
    }

    @Subscribe
    public void onServerPreConnect(ServerPreConnectEvent event) {
        Player player = event.getPlayer();
        RegisteredServer target = event.getOriginalServer();
        String targetName = target.getServerInfo().getName();

        if (!manager.isRestricted(targetName) || player.hasPermission(MaintenanceManager.BYPASS_PERMISSION)) {
            return;
        }

        event.setResult(ServerPreConnectEvent.ServerResult.denied());
        player.disconnect(text.message("join-denied", false,
                TextUtil.placeholders("server", targetName)));
    }

    @Subscribe
    public void onServerRegistered(ServerRegisteredEvent event) {
        manager.registerServer(event.registeredServer());
    }

    @Subscribe
    public void onServerUnregistered(ServerUnregisteredEvent event) {
        manager.unregisterServer(event.unregisteredServer());
    }
}
