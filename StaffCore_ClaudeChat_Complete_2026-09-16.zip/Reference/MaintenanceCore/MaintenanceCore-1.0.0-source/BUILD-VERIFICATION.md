# Build- und Prüfbericht

## API-Abgleich

- Ziel: Velocity 4.1.2
- Offizielle Dependency laut PaperMC: `com.velocitypowered:velocity-api:4.1.2-SNAPSHOT`
- Java-Anforderung für Velocity 4.x: Java 25+
- Zentraler Join-/Switch-Schutz: `ServerPreConnectEvent`
- Command-Registrierung: `CommandManager#metaBuilder(...).plugin(...).build()` + `register(...)`
- Scheduler: `Scheduler#buildTask(...)`, `delay(...)`, `repeat(...)`, `ScheduledTask#cancel()`
- Dynamische Server: `ServerRegisteredEvent` / `ServerUnregisteredEvent`

## Build in dieser Arbeitsumgebung

Die bereitgestellte Umgebung hatte nur JDK 21 und kein installiertes Maven. Der Paket-/Downloadzugriff für eine lokale Maven-Installation war nicht verfügbar. Deshalb konnte `mvn clean package` hier nicht gegen das echte Remote-Artefakt ausgeführt werden.

Stattdessen wurden alle Projektquellen mit `javac` gegen minimale, anhand der offiziellen Velocity-/Adventure-Javadocs abgeglichene API-Signaturen kompiliert. Daraus wurde eine echte `MaintenanceCore-1.0.0.jar` erstellt. Diese JAR nutzt Java-21-Bytecode und ist damit auf Java 25 lauffähig. Das enthaltene Maven-Projekt selbst ist auf `release 25` und die offizielle Velocity-4.1.2-SNAPSHOT-API konfiguriert.

## Ausgeführte Simulationstests

Bestanden:

1. Initialzustand aller registrierten Server ist `ONLINE`.
2. Einzelserver `on` startet genau einen `COUNTDOWN`.
3. Countdown-Warnungen gehen nur an Spieler des betroffenen Servers.
4. `off` während `COUNTDOWN` setzt sofort `ONLINE`.
5. Ein abgebrochener Countdown kann auch nach weiteren Scheduler-Ticks niemanden mehr kicken.
6. Nach Ablauf wird der Zielserver `MAINTENANCE`.
7. Normale Spieler auf genau diesem Server werden getrennt.
8. `maintenance.bypass`-Spieler bleiben verbunden.
9. Spieler auf anderen Servern werden nicht getrennt.
10. Ein gespeicherter `COUNTDOWN` wird nach simuliertem Proxy-Neustart zu `MAINTENANCE`.
11. `all on` startet parallele Countdowns für alle aktuell registrierten Server.
12. `all off` bricht alle laufenden Countdowns ab und lässt keine späteren Kicks zu.
13. Neu registrierte Server starten automatisch `ONLINE`.
14. Entfernte und später neu registrierte Server übernehmen keinen alten verwaisten Wartungsstate.
15. `state.yml` wird in gültiger, serverweiser Form geschrieben.

Zusätzlich geprüft:

- Keine TODOs/Platzhalter in den Java-Quellen.
- Keine fest codierten Backend-Namen in den Java-Quellen.
- `velocity-plugin.json` der erzeugten JAR ist gültiges JSON.
- `pom.xml` ist gültiges XML.
- Die JAR enthält keine eingebetteten Compile-Stubs.
