# MaintenanceCore 1.0.0

Zentrales Wartungssystem für ein Velocity-4.1.2-Netzwerk. Das Plugin läuft ausschließlich auf dem Proxy; auf den Paper-Backends ist kein Companion-Plugin nötig.

## Voraussetzungen

- Velocity 4.1.2
- Java 25 oder neuer
- Maven 3.9+ zum Bauen
- Optional LuckPerms auf Velocity; MaintenanceCore verwendet ausschließlich das normale Velocity-Permissionsystem.

## Build

```bash
mvn clean package
```

Ergebnis: `target/MaintenanceCore-1.0.0.jar`

## Installation

1. `MaintenanceCore-1.0.0.jar` in den `plugins/`-Ordner des Velocity-Proxys kopieren.
2. Proxy starten.
3. `plugins/maintenancecore/config.yml` prüfen/anpassen.
4. Berechtigungen auf Proxy-Ebene vergeben:
   - `maintenance.admin`
   - `maintenance.bypass`

Paper-/Backend-OP verleiht **keinen** Bypass.

## Commands

```text
/wartungsarbeiten <server> on
/wartungsarbeiten <server> off
/wartungsarbeiten <server> status
/wartungsarbeiten list
/wartungsarbeiten all on
/wartungsarbeiten all off
/wartungsarbeiten all status
```

Es gibt bewusst keine Aliase.

## Verhalten

- `on` setzt den Zielserver sofort auf `COUNTDOWN`; ab diesem Moment werden neue Verbindungen ohne `maintenance.bypass` zentral in `ServerPreConnectEvent` blockiert und der Spieler wird vom Proxy getrennt.
- Nach Ablauf wird der State `MAINTENANCE`; nur normale Spieler, die dann noch auf genau diesem Server sind, werden getrennt. Bypass-Spieler bleiben.
- `off` während `COUNTDOWN` markiert den Countdown als abgebrochen, cancelt dessen Task und setzt den Server auf `ONLINE`. Ein alter Task kann danach keinen Kick mehr auslösen.
- `all on` arbeitet nur auf einem Snapshot der zu diesem Zeitpunkt registrierten Velocity-Server. Später registrierte Server starten `ONLINE`.
- Dynamisch neu registrierte Server werden automatisch erkannt. Wird ein Server aus Velocity entfernt, wird sein aktiver State entfernt und nicht später aus einem verwaisten `state.yml`-Eintrag reaktiviert.
- Ein gespeicherter `COUNTDOWN` wird nach einem Proxy-Neustart direkt zu `MAINTENANCE`; er wird nicht halb fortgesetzt.
- Persistenz erfolgt über eine temporäre Datei und anschließend einen atomaren Replace, sofern das Dateisystem `ATOMIC_MOVE` unterstützt.

## Dateien

```text
MaintenanceCore/
├── pom.xml
├── README.md
└── src/main/
    ├── java/de/yolan/maintenance/
    │   ├── MaintenancePlugin.java
    │   ├── command/MaintenanceCommand.java
    │   ├── config/MaintenanceConfig.java
    │   ├── listener/ServerConnectionListener.java
    │   ├── manager/MaintenanceManager.java
    │   ├── model/MaintenanceState.java
    │   ├── storage/MaintenanceStorage.java
    │   └── util/TextUtil.java
    └── resources/config.yml
```

## Sicherheits-/Edge-Case-Entscheidungen

- `maintenance.bypass` ist die einzige Ausnahme vom Wartungsschutz.
- Wer den Bypass während eines Aufenthalts auf einem Wartungsserver verliert, wird nicht sofort aggressiv getrennt; spätestens der nächste Serverwechsel wird blockiert.
- Serverwechsel über `/server`, `/hub`, NPCs, Plugin Messaging oder andere normale Velocity-Connect-Aufrufe landen zentral im `ServerPreConnectEvent` und werden dadurch einheitlich geschützt.
- Backend offline: Solange es in Velocity registriert ist, lässt sich sein Wartungsstate weiterhin setzen; ein Ping zum Backend ist dafür nicht nötig.
