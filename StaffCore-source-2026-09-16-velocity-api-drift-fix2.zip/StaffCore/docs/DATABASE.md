# Datenbankmodell

Alle Zeitpunkte sind UTC (`TIMESTAMP(6)`) und UUIDs werden als `BINARY(16)` persistiert. Namen sind Such-/Anzeigedaten, nie Identität.

| Tabelle | Zweck | wichtige Konsistenzregeln |
|---|---|---|
| `players` | kanonische Spieler | UUID PK, current_name index |
| `known_names` | Namenshistorie | unique(player_uuid, name) |
| `staff_preferences` | Staff-UI/Notification-Einstellungen | UUID PK |
| `staff_sessions` | Proxy-Staff-Sessions | session UUID, heartbeat/stale cleanup |
| `staff_states` | vanish/staffchat + revision | UUID PK, revision CAS |
| `staffmode_snapshots` | versionierte sichere Snapshots | höchstens eine aktive Session je Spieler via active-key |
| `freeze_states` | persistenter Freeze | UUID PK, revision, session_id |
| `spectate_sessions` | laufende Spectate-Sessions | staff UUID + status |
| `punishments` | Warn/Mute/Ban | idempotency_key unique, scope/indexe |
| `punishment_actions` | revoke/expire/change history | append-only |
| `tickets` | Ticketkopf | revision für CAS, status/priority indexes |
| `ticket_messages` | Spieler-/Staff-Antworten | append-only |
| `ticket_internal_notes` | interne Ticketnotizen | Staff only |
| `ticket_assignments` | Assignment history | append-only |
| `ticket_events` | Status/Override/Eskalation | append-only |
| `staff_notes` | aktuelle Note-Metadaten | archived statt hard delete |
| `staff_note_revisions` | Edit-History | append-only |
| `notifications` | persistente Inbox | unread/read indexes |
| `audit_log` | sicherheitsrelevantes Audit | append-only, correlation id |
| `staff_activity_events` | Management-Aktivität | append-only |
| `server_presence` | aktuelle Präsenz/Heartbeat | player UUID PK, `last_seen_at`, stale cleanup |
| `presence_sessions` | Netzwerk-Presence-Historie/Reserve | session UUID |
| `player_server_sessions` | tatsächliche Backend-Aufenthalte/Playtime | network_session_id, server_name, started_at/ended_at |
| `transactional_outbox` | retrybare Folgeevents | status/next_attempt index |
| `processed_messages` | Replay-Dedupe | message UUID PK + TTL cleanup |

Kritische Aktionen verwenden eine DB-Transaktion. Erfolgsnachrichten werden erst nach Commit gesendet. UI-/Bridge-Folgereaktionen sind Outbox/after-commit und dürfen keinen bereits erfolgreichen Moderationscommit zurückrollen.
