# Release Checklist

- [ ] alle Manifest-Dateien vorhanden
- [ ] keine Pflicht-TODOs/Pseudocode/`...` in Source
- [ ] Java 25 Buildumgebung
- [ ] `mvn clean verify`
- [ ] Unit Tests grün
- [ ] MariaDB Testcontainers Tests grün oder explizit als nicht ausführbar dokumentiert
- [ ] Runtime-Matrix ausgeführt und Ergebnisse dokumentiert
- [ ] Flyway auf leerer DB erfolgreich
- [ ] StaffMode Crash-/Restore-Szenarien geprüft
- [ ] Vanish Hierarchie/Join/Serverwechsel geprüft
- [ ] Freeze Leave genau ein Ban geprüft
- [ ] Ticket Doppelclaim getestet
- [ ] Punishment Idempotency/Scopes getestet
- [ ] README/Permissions/Config aktuell
- [ ] Backups vor Upgrade empfohlen
- [ ] finale Velocity-/PaperBridge-JARs identifiziert
- [ ] SHA256 erstellt
