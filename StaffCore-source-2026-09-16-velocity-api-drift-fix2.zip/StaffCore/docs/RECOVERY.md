# Recovery

## StaffMode
1. Beim Join/Enable aktive Snapshot-Session lesen.
2. `CAPTURED`: lokale StaffMode-Mutation wurde möglicherweise nicht abgeschlossen. Der Service vergleicht den erwarteten Modusmarker und setzt eindeutig fort; bei Unsicherheit `RECOVERY_REQUIRED`.
3. `ACTIVE`: StaffMode-Inventar/State erneut deterministisch projizieren, ohne Snapshot zu verändern.
4. `RESTORE_REQUESTED/ROUTING_TO_ORIGIN`: zum Origin routen; wenn nicht erreichbar, keine Ersatzwiederherstellung auf anderem Server.
5. `RESTORING`: Snapshot erneut vollständig SETzen; der Vorgang ist idempotent.
6. `RECOVERY_REQUIRED`: nur `staffcore.staffmode.recover`; jeder Eingriff Audit.

Snapshot wird nie überschrieben. Ein neuer StaffMode ist blockiert, solange eine nicht terminale Session existiert.

## Freeze
Freeze ist unabhängig vom 5m Leave-Ban. Nach Ban-Ablauf bleibt `freeze_states.active=1`. Doppelte Disconnect-Erkennung verwendet denselben idempotency key und erzeugt maximal einen Systemban.

## DB-Ausfall
- Mutation fail-closed für Punishments, Tickets, StaffMode snapshot, Freeze state und Inventory edits.
- bereits validierte aktive Ban/Mute/Freeze/Vanish-Caches dürfen weiter enforcebar bleiben.
- keine globale Login-Sperre nur wegen DB-Ausfall.
- bounded Telemetrie-/Notification-Queues; keine kritischen Daten still verwerfen.

## Presence
Velocity schreibt standardmäßig alle `15s` einen Heartbeat (`runtime.presence-heartbeat-interval`). Presence-Einträge ohne frischen Heartbeat werden nach `90s` (`runtime.presence-stale-after`) in einer DB-Transaktion entfernt; dabei werden offene `player_server_sessions` derselben Network-Session zuerst mit `ended_at` geschlossen. Die Config erzwingt, dass die Stale-Schwelle größer als das Doppelte des Heartbeat-Intervalls ist. Backend-Wechsel aktualisieren Presence und Server-Session-Historie atomar.
