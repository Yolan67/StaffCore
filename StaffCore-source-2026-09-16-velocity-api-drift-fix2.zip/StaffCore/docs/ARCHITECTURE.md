# StaffCore – Architektur (Phase 0)

## 1. Zielarchitektur

StaffCore wird als Maven-Multi-Module-Projekt mit vier klar getrennten Modulen umgesetzt:

- `staffcore-common`: ausschließlich plattformfreie Domain-Modelle, Permissions, Hierarchie, State-Machines, Priority-/Routing-Logik, Protokollverträge und Utilities.
- `staffcore-data`: HikariCP, Flyway, MariaDB-Repositories, atomare Transaktionsoperationen, Audit/Outbox und Datenbank-Health. Keine Paper-/Velocity-Abhängigkeiten.
- `staffcore-velocity`: globale Authority für Presence, globale Staff-States, StaffChat, Punishments, ServerBans, Login-/PreConnect-Enforcement, Ticket-Routing und Cross-Server-Koordination.
- `staffcore-paper`: lokale Welt-/Entity-/Inventar-/GUI-Funktionen, StaffMode-Snapshots und Restore, Freeze-Enforcement, Vanish-Visibility, Spectate, Inspect und Inventar-Edit.

MariaDB ist die dauerhafte Source of Truth. Velocity hält autoritative Netzwerk-Caches und verteilt Revisionen. Paper hält nur lokale Projektionen und lädt bei Join/Serverwechsel erneut aus DB/Velocity.

## 2. Verifizierte Plattformbasis

Stand 2026-09-16 wurden die offiziellen PaperMC-Quellen geprüft:

- Velocity-API: `com.velocitypowered:velocity-api:4.1.2-SNAPSHOT`.
- Velocity und Paper benötigen Java 25+ für die hier verwendete Generation.
- Paper 26.1+ verwendet das neue `{VERSION}.build.{BUILD}-{channel}`-Schema.
- Für Minecraft/Paper 26.1.2 ist ein stabiles API-Artefakt vorhanden; dieses Projekt pinnt `io.papermc.paper:paper-api:26.1.2.build.74-stable`.
- Paper dokumentiert `ItemStack.serializeAsBytes()` als sichere Alternative zu ObjectStreams; StaffMode verwendet daher keine Java-Native-Deserialisierung.

Keine NMS-/Packet-Hacks werden vorausgesetzt.

## 3. Modulbaum

```text
StaffCore/
├── pom.xml
├── staffcore-common/
├── staffcore-data/
├── staffcore-velocity/
├── staffcore-paper/
├── docs/
├── runtime-test/
├── scripts/
├── README.md
├── PROJECT_MANIFEST.md
└── CHANGELOG.md
```

## 4. Hauptservices

### Common
- `StaffHierarchy`: Rangauflösung nur aus Permissions; höchste Rank-Permission gewinnt.
- `DurationParser`: robuste Dauerstrings inkl. permanent.
- `PriorityEngine`: deterministischer, erklärbarer Ticket-Score ohne externe KI.
- `AssignmentEngine`: Eligibility, Mindest-Rang, Capacity, Load und least-recently-assigned.
- State-Machines: StaffMode, Freeze, Vanish, Spectate, Punishments.
- `ProtocolCodec`: begrenzte, versionierte JSON-Envelopes mit HMAC-SHA256.

### Data
- `DatabaseManager`: HikariCP + Flyway, kontrollierter Start/Shutdown.
- Repositories für Player, State, StaffMode, Freeze, Punishment, Ticket, Note, Notification, Audit, Presence und Outbox.
- CAS/Revision-Operationen für konfliktanfällige Ticket-/State-Mutationen.

### Velocity
- `PresenceService`: Online-/Backend-Status, periodischer Heartbeat und stale-session cleanup inklusive Abschluss offener `player_server_sessions`.
- `GlobalStateService`: Vanish, StaffChat, Freeze und Staff-State-Revisionen.
- `PunishmentService`: Erstellen/Aufheben/Expiry/Enforcement mit Idempotency-Key.
- `TicketRoutingService`: faire automatische Zuweisung.
- `StaffChatService`: netzwerkweiter StaffChat.
- `BridgeHub`/`BridgeListener`: signierter Cross-Server-Transport, Message-ID-Dedupe, Source-Kontext- und Permission-Prüfung.
- `MaintenanceStatusProvider`: optionale Integration, ohne harte Kopplung.

### Paper
- `StaffModeService`: persist-before-mutate Snapshot, deterministischer Restore, Recovery.
- `VanishService`: Hierarchie-basierte `hidePlayer/showPlayer`-Projektion.
- `FreezeService`: Bewegung/Inventar/Interaktion/Teleport/Command-Schutz; normaler Chat bleibt erlaubt.
- `SpectateService`: normal/super mit exaktem vorherigem Vanish-Zustand.
- `InventoryInspectService`: DB-Lease, Baseline-Hash, konfliktfreier Inventory-Edit und Audit.
- GUI-Framework: serverseitige Action-IDs, Permission-Recheck, Pagination/Loading.
- `TicketService` und Inspect/Player/Ticket/Punishment/Notes/Logs-/Activity-GUIs.

## 5. Datenfluss

1. Spieler verbindet sich zu Velocity.
2. Velocity prüft GlobalBan vor vollständigem Join.
3. Vor Backend-Connect prüft Velocity ServerBan für das konkrete Ziel.
4. Nach Connect schreibt Velocity Presence und sendet einen State-Resync an Paper.
5. Paper lädt/validiert lokalen Freeze/Vanish/StaffMode-Zustand und wendet Bukkit/Paper-Änderungen ausschließlich auf dem Mainthread an.
6. Kritische Mutation wird in MariaDB committed, erst danach gilt sie als erfolgreich.
7. Nach Commit erzeugt die gleiche Transaktion Audit/Outbox bzw. eine eindeutig korrelierte Folgeaktion.
8. Velocity verteilt eine signierte Bridge-Nachricht mit `protocolVersion`, `messageId`, `revision`, `type`, `payload`, `timestamp` und HMAC.
9. Empfänger verwirft falsche Signatur, zu große Payloads, unbekannte Typen, Duplikate und stale Revisionen.

## 6. Ticket-Priority und Routing

Priority ist konfigurierbar, aber deterministisch. Jede Bewertung speichert bzw. liefert:

- Basisscore nach Kategorie/Unterkategorie,
- angewendete benannte Regeln,
- Alterungszuschlag,
- resultierende Priority `LOW/NORMAL/HIGH/CRITICAL`,
- empfohlenen Mindest-Rang.

Die Engine darf niemals Schuld feststellen oder Punishments auslösen.

Routing:
1. online/available Staff sammeln,
2. Feature-Permission prüfen,
3. Mindest-Rang prüfen,
4. Capacity prüfen,
5. niedrigsten ausreichenden Rang bevorzugen,
6. innerhalb dieses Rangs normalisierte Last vergleichen,
7. least-recently-assigned als stabilen Anti-Starvation-Tie-Breaker verwenden,
8. Assignment per Revision/CAS committen,
9. Audit + Notification erzeugen.

## 7. Zustandsmaschinen

### StaffMode
`CAPTURING -> CAPTURED -> ACTIVE -> RESTORE_REQUESTED -> ROUTING_TO_ORIGIN -> RESTORING -> RESTORED`

Fehlerpfade führen nach `RECOVERY_REQUIRED`. Snapshot wird vor jeder Inventarmutation committed. Restore setzt Inventar/Armor/Offhand/XP/Gamemode/Health/Food/Flight/Effects deterministisch und addiert niemals Items.

### Freeze
`UNFROZEN -> FREEZE_REQUESTED -> FROZEN -> LEAVE_DETECTED -> LEAVE_PUNISHMENT_COMMITTED -> FROZEN_OFFLINE -> FROZEN -> UNFREEZE_REQUESTED -> UNFROZEN`

Der Freeze-Zustand bleibt nach Ablauf des Leave-Tempbans erhalten. Die Leave-Punishment-ID ist aus Freeze-Session + Leave-Ereignis idempotent.

### Vanish
`VISIBLE -> ENABLING -> VANISHED -> DISABLING -> VISIBLE` sowie `RECOVERY_REQUIRED` nur bei inkonsistentem persistentem Zustand. Schnelle doppelte Toggles werden durch Revision/Serialisierung entprellt.

### Spectate
`INACTIVE -> STARTING -> ACTIVE_NORMAL|ACTIVE_SUPER -> STOPPING -> INACTIVE`, Fehler -> `RECOVERY_REQUIRED`. Super-Spectate merkt `vanishWasEnabled`; nur ein temporär gesetzter Vanish wird beim Stop zurückgenommen.

### Punishment
`REQUESTED -> COMMITTED -> ENFORCED -> EXPIRED|REVOKED`. Persistenz ist vor Enforcement-Erfolgsmeldung erforderlich. Expiry wird bei jeder Prüfung anhand UTC berechnet.

## 8. Failure-/Recovery-Modell

- DB nicht erreichbar: keine neuen kritischen Mutationen erfolgreich melden. Validierte Last-Known-Enforcement-Caches dürfen weiterwirken. Degraded Mode wird Staff angezeigt.
- Proxy-Crash: DB bleibt Wahrheit; `PresenceService` aktualisiert standardmäßig alle 15s, Einträge älter als 90s werden stale bereinigt und die zugehörigen offenen `player_server_sessions` geschlossen. Beide Intervalle sind konfigurierbar.
- Paper-Crash: StaffMode-Session bleibt persistent. Join/Enable prüft unvollständige Sessions und setzt eindeutig fort oder markiert `RECOVERY_REQUIRED`.
- Crash zwischen Snapshot-Commit und lokaler StaffMode-Mutation: Session ist `CAPTURED`; Join-Recovery darf sicher entweder Aktivierung fortsetzen oder Originalzustand wiederherstellen, nie einen neuen Snapshot überschreiben.
- Crash während Restore: `RESTORING` bleibt mit unverändertem Snapshot bestehen; Restore ist idempotent und darf wiederholt SETzen.
- Origin offline: kein unsicherer Restore auf anderem Server; `RECOVERY_REQUIRED`/Wartezustand.
- Ticket-Doppelclaim: `UPDATE ... WHERE revision=? AND assignee IS NULL`; genau ein Update gewinnt.
- doppelte Bridge-Nachricht: `messageId`-Dedupe + monotone Revision.
- Freeze-Disconnect doppelt: Unique `idempotency_key` verhindert doppelten 5m-Systemban.
- Notification-Ausfall: Moderationscommit wird nicht rückgängig gemacht; Outbox retryt bounded.

## 9. Security-Modell

Bedrohungen und Gegenmaßnahmen:

- SQL Injection: ausschließlich PreparedStatements und feste Query-Templates.
- Permission bypass: Permission-Prüfung beim Anzeigen und erneut bei Ausführung.
- GUI spoofing: zufällige Session-/Action-IDs im PDC/Session-Mapping, nie Lore/Name als Authority.
- Cross-server spoofing: HMAC-SHA256-Secret, Source-Kontextprüfung auf Velocity, Message-ID, Zeitfenster, Größenlimit, erlaubte MessageTypes.
- Deserialisierung: keine `ObjectInputStream`; ItemStack byte serialization der Paper API, JSON für Domain-Daten.
- Replay/Doppelaktion: idempotency keys + Unique Constraints + CAS.
- Secrets: ENV-Platzhalter; keine Passwörter im Source/Log.
- User Content: harte Längenlimits; MiniMessage-Systemtexte getrennt von Spielertext.
- Backend exposure: Produktion nur mit Velocity Modern Forwarding + Firewall/private binding; StaffCore ersetzt keine Netzwerksicherung.
- Sensitive data: IP nur mit eigener Permission und optionalem Audit; keine unnötige Langzeitpersistenz.

## 10. Teststrategie

### Unit
- StaffHierarchy und Sichtbarkeit.
- DurationParser.
- PriorityEngine inklusive Erklärbarkeit/Alterung.
- AssignmentEngine inklusive Anti-Starvation/Capacity.
- State-Machine erlaubte/verbotene Transitions.
- Punishment expiry/overlap.
- Protokoll-HMAC, Größenlimit, Replay-/Revisionlogik.

### DB-Integration
- Flyway leere MariaDB -> aktuell.
- Repository CRUD.
- Duplicate idempotency key.
- atomarer Ticket-Claim/CAS.
- Freeze-Leave genau ein Punishment.
- StaffMode Snapshot uniqueness/recovery queries.

Testcontainers ist vorbereitet; wenn Docker nicht verfügbar ist, liefert `runtime-test/docker-compose.yml` eine lokale MariaDB.

### Runtime
Reproduzierbares Netz: 1 Velocity + 3 Paper (`lobby`, `survival`, `events`) + MariaDB; Matrix in `docs/RUNTIME_TEST_PLAN.md`.

## 11. Architektur-Entscheidungen

- Kein Redis in v1.
- Keine externe KI.
- Keine NMS-Abhängigkeit für Fake-NPC. Freeze Fake Body ist über ein optionales Provider-Interface kapselbar; Kernlogik hängt nicht davon ab.
- Keine LuckPerms-Gruppennamen; nur Permissions.
- Standard Bukkit `plugin.yml`, nicht experimentelles Paper-Plugin-Manifest.
- Maven bleibt gewählt, obwohl Paper Gradle bevorzugt, weil der Master-Prompt Maven Multi-Module verlangt/zulässt und Paper Maven offiziell dokumentiert.
