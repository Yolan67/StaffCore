# Permissions

Ranks werden ausschließlich durch diese Permissions ermittelt: `staffcore.rank.jrmod`, `.mod`, `.srmod`, `.admin`, `.owner`. Mehrere -> höchste Stufe.

Feature-Nodes:

- `staffcore.menu`
- `staffcore.staffmode`, `staffcore.staffmode.recover`
- `staffcore.vanish`, `staffcore.vanish.see`
- `staffcore.freeze`, `staffcore.freeze.bypass`
- `staffcore.spectate`, `staffcore.spectate.super`
- `staffcore.teleport`
- `staffcore.staffchat.use`, `staffcore.staffchat.see`
- `staffcore.stafflist`
- `staffcore.inspect`, `staffcore.inspect.inventory`, `staffcore.inspect.inventory.edit`, `staffcore.inspect.ip`
- `staffcore.ticket.view`, `.claim`, `.reply`, `.close`, `.override`, `.escalate`, `.reassign`, `.reopen`
- `staffcore.punishment.warn`, `.kick`, `.mute`, `.serverban`, `.globalban`
- `staffcore.notes.view`, `.edit`, `.archive`
- `staffcore.logs.view`, `.sensitive`
- `staffcore.activity.view`, `.details`
- `staffcore.routing.admin`
- `staffcore.recovery.admin`

## empfohlene Matrix

| Feature | JrMod | Mod | SrMod | Admin | Owner |
|---|---:|---:|---:|---:|---:|
| Staff GUI/StaffChat/StaffList | ✓ | ✓ | ✓ | ✓ | ✓ |
| Vanish/StaffMode | ✓ | ✓ | ✓ | ✓ | ✓ |
| Freeze/Spectate | ✓ | ✓ | ✓ | ✓ | ✓ |
| Ticket claim/reply/close | ✓ | ✓ | ✓ | ✓ | ✓ |
| Ticket override/reassign |  |  | ✓ | ✓ | ✓ |
| Inventory view | ✓ | ✓ | ✓ | ✓ | ✓ |
| Inventory edit |  | ✓ | ✓ | ✓ | ✓ |
| Warn/Mute | ✓ | ✓ | ✓ | ✓ | ✓ |
| ServerBan |  | ✓ | ✓ | ✓ | ✓ |
| GlobalBan |  |  |  | ✓ | ✓ |
| Sensitive logs/IP |  |  |  | ✓ | ✓ |
| Staff activity |  |  |  | ✓ | ✓ |
| Recovery admin |  |  |  | ✓ | ✓ |

Dies ist Dokumentation; StaffCore erstellt oder verändert keine LuckPerms-Gruppen.
