# Runtime-Testplan

## Topologie
- Velocity 4.1.2
- Paper 26.1.2: lobby, survival, events
- MariaDB 11.x
- Identitäten: normaler Spieler, JrMod/Mod, Admin/Owner

## Vanish
- JrMod sieht vanished Admin nicht; Admin sieht vanished SrMod; Owner sieht alle.
- Join nach aktivem Vanish: kein kurzer Sichtbarkeits-Leak.
- Backendwechsel, Weltwechsel, Respawn, Teleport, Permission-/Rank-Änderung.
- Fake Join/Leave genau einmal.
- StaffList/TabCompletion/Assignee GUI leakt keine höheren vanished Staff.
- Proxy- und Backend-Neustart.

## StaffMode
- Snapshot commit vor Inventarwechsel nachweisen.
- komplettes Inventory/Armor/Offhand/Cursor/XP/Gamemode/Health/Food/Flight/Effects sichern.
- Doppeltoggle, Disconnect vor/nach Mutation, Backendcrash, Proxycrash.
- Origin offline.
- Restore setzt exakt, ohne Drop/Dupe.
- Recovery nach Crash während `RESTORING`.

## Freeze
- Bewegung, Sprint/Jump/Vehicle/Portal/Teleport/Item/Drop/Pickup/Inventory blockiert.
- normaler Chat weiterhin erlaubt.
- Command whitelist.
- Leave erzeugt genau einen 5m TempGlobalBan (System); Freeze bleibt danach aktiv.
- paralleles `/unfreeze` + disconnect.

## Spectate
- normal/super; Original-Gamemode/Server/Position/Vanish exakt wiederherstellen.
- target disconnect/server switch.
- vorheriger Vanish bleibt; temporärer Super-Vanish wird entfernt.

## StaffChat
- Toggle backendübergreifend.
- öffentliche Nachricht wird bei Toggle nicht veröffentlicht.
- Staff auf anderem Backend erhält Nachricht.
- Freeze ändert Chat nicht; normaler Mute blockiert normalen Chat, StaffChat separat.

## Tickets
- alle Kategorien, Antworten, intern note, Claim, Doppelclaim, Release, Reassign, Escalate, Override, Reopen.
- Priority-Erklärung.
- faire Verteilung bei unterschiedlicher Last/Capacity und Anti-Starvation.
- Staff offline während Assignment.

## Punishments
- Warn/Kick/Mute/TempMute/Unmute, ServerBan/TempServerBan/Unban, GlobalBan/TempGlobalBan/Unban.
- ServerBan blockiert nur Zielbackend.
- doppelte idempotency/action ID erzeugt nur einen Datensatz.
- Expiry offline/online, Proxyrestart, DB restart.

## Inspect/Inventory
- online/offline data.
- View/Edit getrennte Permission.
- parallele Edit-Sessions -> Konflikt statt last-write-wins.
- IP nur Extra-Permission.

## Failure injection
- MariaDB 30–60s stoppen.
- kritische Mutationen müssen sicher fehlschlagen.
- Mainthread darf nicht blockieren.
- nach Recovery keine Doppelaktionen.
