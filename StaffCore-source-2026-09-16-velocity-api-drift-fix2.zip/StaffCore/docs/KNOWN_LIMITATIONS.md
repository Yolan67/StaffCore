# Known Limitations

## Build-/Runtime-Verifikation

Ein echter GitHub-Actions-Lauf mit Temurin Java 25.0.4 hat `staffcore-common` erfolgreich kompiliert und **23/23 Common-Tests** bestanden. `staffcore-data` wurde ebenfalls erfolgreich kompiliert; MariaDB 11.8 lief via Testcontainers, Flyway V1+V2 wurden erfolgreich angewendet und **5/5 DatabaseIntegrationTests** bestanden.

Der nächste Lauf bestätigte, dass die vorherigen `RegisteredServer`-Fehler behoben sind, erreichte aber zwei weitere Velocity-Compilefehler: einen fehlenden `MessageType`-Import in `PunishmentService` sowie den veralteten Aufruf `AssignmentEngine.choose(...)` in `TicketRoutingService`. Beide wurden im eigentlichen Source korrigiert; der Routing-Code verwendet jetzt die tatsächliche Common-API `select(List<StaffCandidate>, StaffRank)`. Für diesen korrigierten Stand existiert noch kein neuer grüner GitHub-Actions-Lauf. Deshalb bleiben Velocity, Paper und der Gesamt-Reactor weiterhin **nicht als erfolgreich gebaut bestätigt**.

Details stehen in `BUILD_REPORT.md`.

## Vanish

StaffCore nutzt öffentliche Paper-Visibility-APIs und Hierarchieprüfungen. Fremde Scoreboards, Placeholder, Web-APIs, Packetlisten oder selbst verwaltete Playerlisten können vanished Staff trotzdem leaken, wenn diese Plugins StaffCore nicht berücksichtigen.

Fake Join/Leave kann mit anderen Plugins kollidieren, die Join-/Leave-Meldungen ebenfalls vollständig ersetzen.

## Freeze Fake Body

Das optische Offline-Fake-Body/NPC-Feature ist bewusst optional und nicht Teil der sicherheitskritischen Freeze-Kernlogik. Es wurde keine fragile NMS-/Packet-only-Implementierung eingebaut. Freeze-Persistenz, Leave-Erkennung und System-Tempban funktionieren unabhängig davon.

## Client-/Mod-Erkennung

Paper kann Protocol-Version, Client-Brand und registrierte Plugin-Channels liefern. Daraus lässt sich keine vollständige Liste installierter Client-Mods ableiten. StaffCore behauptet deshalb keine vollständige Mod-Erkennung.

## IP / Datenschutz

Nur die aktuelle Online-IP ist aus der aktiven Verbindung verfügbar. StaffCore speichert sie nicht als dauerhaftes Spielerprofil. Produktionsbetrieb benötigt zusätzlich eigene Datenschutz-/Retention-Regeln.

## Drittanbieter-PM bei Mute

Konfigurierte Messaging-Commands können abgefangen werden. Fremde Plugins können unbekannte Aliase, eigene Channels oder andere Kommunikationswege besitzen; ohne konkrete Integration sind diese nicht garantiert vom Mute umfasst.

## Plugin Messaging

Paper→Velocity Plugin Messaging benötigt einen verbundenen Spieler als Carrier. Die Bridge besitzt nur eine begrenzte Pending-Queue. Persistente kritische Wahrheit liegt deshalb in MariaDB/Velocity-State und nicht ausschließlich im Transport.

## Mehrere Velocity-Proxies

Die aktuelle Version ist auf **eine logische Velocity-Authority** ausgelegt. Ein echtes Active/Active-Multi-Proxy-Cluster benötigt zusätzliche verteilte Koordination für Presence, Realtime-Events und Locks. Die neue Presence-Heartbeat-/Stale-Cleanup-Logik löst Crash-Recovery einer einzelnen Authority, aber nicht Multi-Proxy-Consensus.

## MaintenanceCore

Nur die optionale `MaintenanceStatusProvider`-Schnittstelle ist vorhanden. Ohne veröffentlichte MaintenanceCore-API/Source gibt es keine harte Kopplung. StaffCore funktioniert ohne MaintenanceCore.

## Live-Inventar-Edit

Inventory-Edit nutzt DB-Lease und Baseline-Hash. Fremde Plugins mit virtuellen oder vollständig eigenen Inventarsystemen sind nicht Teil dieses Editors.

## Cross-Server-/Runtime-Races

Die Source enthält CAS, Revisionen, Source-Backend-Prüfung und erneute Permissions. Trotzdem müssen Serverwechsel-, Disconnect- und Crash-Races im realen Testnetz gemäß `docs/RUNTIME_TEST_PLAN.md` geprüft werden, da diese Umgebung keine Velocity-/Paper-Runtime bereitstellt.

## Externe API-Typprüfung

Common und Data wurden inzwischen real mit Java 25 typgeprüft. Für den nachträglich korrigierten Velocity-Source und für Paper fehlt weiterhin der erneute vollständige Reactor-Build. Diese letzte Sicherheit liefert erst ein neuer grüner `./mvnw clean verify`-/GitHub-Actions-Lauf.
