# Security / Threat Model

1. **Backend-Netz**: Paper nicht öffentlich exponieren. Velocity Modern Forwarding mit Secret und Firewall/private networking verwenden.
2. **DB**: eigener DB-Benutzer mit nur erforderlichen Rechten; TLS wenn Netz nicht lokal/privat; PreparedStatements.
3. **Bridge**: `staffcore:bridge`, HMAC-SHA256, Protokollversion, Message-ID, UTC timestamp, Payloadlimit, allow-list der Typen, Replay-/Revisionprüfung.
4. **GUI**: Action-ID in PDC/Session; Permission beim Klick erneut; stale Revision vor kritischer Mutation.
5. **Inventar**: keine additiven Restore-Operationen; vollständiges SET; keine Drops; Edit-Lock/Revision.
6. **User Content**: Längenlimits, nie Spielertext als MiniMessage rendern; Systemtemplates und Usertext getrennt.
7. **Secrets**: `STAFFCORE_DB_PASSWORD` und `STAFFCORE_BRIDGE_SECRET` per Environment; nie im Repo.
8. **Sensitive data**: IP nur `staffcore.inspect.ip`, standardmäßig nicht persistieren; Zugriff optional auditieren.
9. **Dependency safety**: feste Versionen; keine Runtime-JAR-Downloads; keine Reflection-Deserialisierung.
10. **Degraded mode**: kritische Schreibaktionen werden abgewiesen statt erfunden/ungeprüft fortgesetzt.
