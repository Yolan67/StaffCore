package de.yolan.staffcore.data;

import java.sql.*;
import java.time.Instant;
import java.util.*;

public final class StaffNoteRepository {
    public record Note(long id, UUID target, UUID author, String category, String text, boolean archived, Instant createdAt, Instant updatedAt) {}
    public record Revision(long id, long noteId, UUID editor, String text, Instant createdAt) {}
    private final DatabaseManager db;
    public StaffNoteRepository(DatabaseManager db){this.db=db;}

    public long create(UUID target,UUID author,String category,String text){return db.transaction(c->{try(PreparedStatement p=c.prepareStatement("INSERT INTO staff_notes(target_uuid,author_uuid,category,current_text,archived,created_at,updated_at) VALUES(?,?,?,?,0,UTC_TIMESTAMP(6),UTC_TIMESTAMP(6))",Statement.RETURN_GENERATED_KEYS)){Sql.uuid(p,1,target);Sql.uuid(p,2,author);p.setString(3,category);p.setString(4,text);p.executeUpdate();try(ResultSet r=p.getGeneratedKeys()){if(!r.next())throw new SQLException("note id missing");long id=r.getLong(1);revision(c,id,author,text);return id;}}});}
    public List<Note> list(UUID target,boolean includeArchived,int offset,int limit){return db.read(c->{String sql="SELECT * FROM staff_notes WHERE target_uuid=?"+(includeArchived?"":" AND archived=0")+" ORDER BY updated_at DESC LIMIT ? OFFSET ?";try(PreparedStatement p=c.prepareStatement(sql)){Sql.uuid(p,1,target);p.setInt(2,clamp(limit,1,100));p.setInt(3,Math.max(0,offset));try(ResultSet r=p.executeQuery()){List<Note>x=new ArrayList<>();while(r.next())x.add(map(r));return x;}}});}
    public Optional<Note> find(long id){return db.read(c->{try(PreparedStatement p=c.prepareStatement("SELECT * FROM staff_notes WHERE id=?")){p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}}});}
    public Optional<Note> edit(long id,UUID editor,Instant expectedUpdatedAt,String text){return db.transaction(c->{try(PreparedStatement p=c.prepareStatement("UPDATE staff_notes SET current_text=?,updated_at=UTC_TIMESTAMP(6) WHERE id=? AND updated_at=?")){p.setString(1,text);p.setLong(2,id);Sql.instant(p,3,expectedUpdatedAt);if(p.executeUpdate()!=1)return Optional.empty();}revision(c,id,editor,text);return find(c,id);});}
    public Optional<Note> archive(long id,UUID editor,Instant expectedUpdatedAt,boolean archived){return db.transaction(c->{try(PreparedStatement p=c.prepareStatement("UPDATE staff_notes SET archived=?,updated_at=UTC_TIMESTAMP(6) WHERE id=? AND updated_at=?")){p.setBoolean(1,archived);p.setLong(2,id);Sql.instant(p,3,expectedUpdatedAt);if(p.executeUpdate()!=1)return Optional.empty();}try(PreparedStatement p=c.prepareStatement("INSERT INTO staff_note_revisions(note_id,editor_uuid,text,created_at) SELECT id,?,CONCAT('[ARCHIVED=',?,'] ',current_text),UTC_TIMESTAMP(6) FROM staff_notes WHERE id=?")){Sql.uuid(p,1,editor);p.setBoolean(2,archived);p.setLong(3,id);p.executeUpdate();}return find(c,id);});}
    public List<Revision> revisions(long noteId,int limit){return db.read(c->{try(PreparedStatement p=c.prepareStatement("SELECT * FROM staff_note_revisions WHERE note_id=? ORDER BY created_at DESC LIMIT ?")){p.setLong(1,noteId);p.setInt(2,clamp(limit,1,200));try(ResultSet r=p.executeQuery()){List<Revision>x=new ArrayList<>();while(r.next())x.add(new Revision(r.getLong("id"),noteId,Sql.uuid(r,"editor_uuid"),r.getString("text"),Sql.instant(r,"created_at")));return x;}}});}
    private void revision(Connection c,long id,UUID editor,String text)throws SQLException{try(PreparedStatement q=c.prepareStatement("INSERT INTO staff_note_revisions(note_id,editor_uuid,text,created_at) VALUES(?,?,?,UTC_TIMESTAMP(6))")){q.setLong(1,id);Sql.uuid(q,2,editor);q.setString(3,text);q.executeUpdate();}}
    private Optional<Note> find(Connection c,long id)throws SQLException{try(PreparedStatement p=c.prepareStatement("SELECT * FROM staff_notes WHERE id=?")){p.setLong(1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}}}
    private Note map(ResultSet r)throws SQLException{return new Note(r.getLong("id"),Sql.uuid(r,"target_uuid"),Sql.uuid(r,"author_uuid"),r.getString("category"),r.getString("current_text"),r.getBoolean("archived"),Sql.instant(r,"created_at"),Sql.instant(r,"updated_at"));}
    private static int clamp(int v,int min,int max){return Math.max(min,Math.min(max,v));}
}
