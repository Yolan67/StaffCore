package de.yolan.staffcore.data;

import de.yolan.staffcore.common.model.FreezeRecord;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class FreezeRepository {
    public record FreezeResult(FreezeRecord record, boolean changed) {}

    private final DatabaseManager db;

    public FreezeRepository(DatabaseManager db) {
        this.db = db;
    }

    public Optional<FreezeRecord> find(UUID player) {
        return db.read(connection -> select(connection, player));
    }

    /**
     * Atomically activates Freeze only if it is not already active.
     * A duplicate/parallel freeze therefore returns the existing session unchanged.
     */
    public FreezeResult freezeIfInactive(UUID player, UUID actor, String reason) {
        return db.transaction(connection -> {
            Optional<FreezeRecord> current = selectForUpdate(connection, player);
            if (current.isPresent() && current.get().active()) {
                return new FreezeResult(current.get(), false);
            }

            UUID session = UUID.randomUUID();
            if (current.isEmpty()) {
                try (PreparedStatement statement = connection.prepareStatement(
                        "INSERT INTO freeze_states(" +
                                "player_uuid,active,session_id,actor_uuid,reason,revision,created_at,updated_at" +
                                ") VALUES(?,1,?,?,?,0,UTC_TIMESTAMP(6),UTC_TIMESTAMP(6))")) {
                    Sql.uuid(statement, 1, player);
                    Sql.uuid(statement, 2, session);
                    Sql.uuid(statement, 3, actor);
                    statement.setString(4, reason);
                    statement.executeUpdate();
                }
            } else {
                try (PreparedStatement statement = connection.prepareStatement(
                        "UPDATE freeze_states SET active=1,session_id=?,actor_uuid=?,reason=?," +
                                "revision=revision+1,created_at=UTC_TIMESTAMP(6),updated_at=UTC_TIMESTAMP(6) " +
                                "WHERE player_uuid=? AND active=0")) {
                    Sql.uuid(statement, 1, session);
                    Sql.uuid(statement, 2, actor);
                    statement.setString(3, reason);
                    Sql.uuid(statement, 4, player);
                    if (statement.executeUpdate() != 1) {
                        FreezeRecord raced = select(connection, player).orElseThrow();
                        return new FreezeResult(raced, false);
                    }
                }
            }
            return new FreezeResult(select(connection, player).orElseThrow(), true);
        });
    }

    /** Kept for internal callers that explicitly want the current/created record. */
    public FreezeRecord freeze(UUID player, UUID actor, String reason) {
        return freezeIfInactive(player, actor, reason).record();
    }

    public boolean unfreeze(UUID player, long expectedRevision) {
        return db.transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE freeze_states SET active=0,revision=revision+1,updated_at=UTC_TIMESTAMP(6) " +
                            "WHERE player_uuid=? AND active=1 AND revision=?")) {
                Sql.uuid(statement, 1, player);
                statement.setLong(2, expectedRevision);
                return statement.executeUpdate() == 1;
            }
        });
    }

    public void updateLastLocation(
            UUID player, String server, String world, double x, double y, double z) {
        db.transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE freeze_states SET last_server=?,last_world=?,x=?,y=?,z=?,updated_at=UTC_TIMESTAMP(6) " +
                            "WHERE player_uuid=? AND active=1")) {
                statement.setString(1, server);
                statement.setString(2, world);
                statement.setDouble(3, x);
                statement.setDouble(4, y);
                statement.setDouble(5, z);
                Sql.uuid(statement, 6, player);
                statement.executeUpdate();
            }
            return null;
        });
    }

    public List<FreezeRecord> active(int limit) {
        return db.read(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM freeze_states WHERE active=1 ORDER BY updated_at DESC LIMIT ?")) {
                statement.setInt(1, Math.max(1, Math.min(limit, 100)));
                try (ResultSet result = statement.executeQuery()) {
                    List<FreezeRecord> records = new ArrayList<>();
                    while (result.next()) records.add(map(result));
                    return records;
                }
            }
        });
    }

    private Optional<FreezeRecord> select(Connection connection, UUID player) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT * FROM freeze_states WHERE player_uuid=?")) {
            Sql.uuid(statement, 1, player);
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? Optional.of(map(result)) : Optional.empty();
            }
        }
    }

    private Optional<FreezeRecord> selectForUpdate(Connection connection, UUID player) throws SQLException {
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT * FROM freeze_states WHERE player_uuid=? FOR UPDATE")) {
            Sql.uuid(statement, 1, player);
            try (ResultSet result = statement.executeQuery()) {
                return result.next() ? Optional.of(map(result)) : Optional.empty();
            }
        }
    }

    private FreezeRecord map(ResultSet result) throws SQLException {
        UUID player = Sql.uuid(result, "player_uuid");
        return new FreezeRecord(
                player,
                result.getBoolean("active"),
                Sql.uuid(result, "session_id"),
                Sql.uuid(result, "actor_uuid"),
                result.getString("reason"),
                result.getString("last_server"),
                result.getString("last_world"),
                number(result, "x"),
                number(result, "y"),
                number(result, "z"),
                result.getLong("revision"),
                Sql.instant(result, "created_at"),
                Sql.instant(result, "updated_at"));
    }

    private static Double number(ResultSet result, String column) throws SQLException {
        Object value = result.getObject(column);
        return value == null ? null : ((Number) value).doubleValue();
    }
}
