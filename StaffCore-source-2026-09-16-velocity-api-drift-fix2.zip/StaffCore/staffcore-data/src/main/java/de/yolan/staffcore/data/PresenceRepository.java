package de.yolan.staffcore.data;

import de.yolan.staffcore.common.model.PresenceRecord;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

public final class PresenceRepository {
    private final DatabaseManager db;

    public PresenceRepository(DatabaseManager db) {
        this.db = db;
    }

    public void online(PresenceRecord record) {
        db.transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO server_presence(player_uuid,player_name,server_name,session_id,is_staff,connected_at,last_seen_at) "
                            + "VALUES(?,?,?,?,?,?,?) ON DUPLICATE KEY UPDATE player_name=VALUES(player_name),"
                            + "server_name=VALUES(server_name),session_id=VALUES(session_id),is_staff=VALUES(is_staff),"
                            + "connected_at=VALUES(connected_at),last_seen_at=VALUES(last_seen_at)")) {
                Sql.uuid(statement, 1, record.playerUuid());
                statement.setString(2, record.playerName());
                statement.setString(3, record.serverName());
                Sql.uuid(statement, 4, record.sessionId());
                statement.setBoolean(5, record.staff());
                Sql.instant(statement, 6, record.connectedAt());
                Sql.instant(statement, 7, record.lastSeenAt());
                statement.executeUpdate();
            }
            return null;
        });
    }

    public void setRank(UUID playerId, String rank) {
        db.transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "UPDATE server_presence SET rank_name=? WHERE player_uuid=?")) {
                statement.setString(1, rank);
                Sql.uuid(statement, 2, playerId);
                statement.executeUpdate();
            }
            return null;
        });
    }

    public Optional<String> staffRank(UUID playerId) {
        return db.read(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT rank_name FROM server_presence WHERE player_uuid=? AND is_staff=1")) {
                Sql.uuid(statement, 1, playerId);
                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) return Optional.empty();
                    return Optional.ofNullable(result.getString(1));
                }
            }
        });
    }

    public void heartbeat(UUID playerId, String serverName) {
        db.transaction(connection -> {
            UUID networkSession = null;
            String oldServer = null;
            try (PreparedStatement query = connection.prepareStatement(
                    "SELECT session_id,server_name FROM server_presence WHERE player_uuid=? FOR UPDATE")) {
                Sql.uuid(query, 1, playerId);
                try (ResultSet result = query.executeQuery()) {
                    if (result.next()) {
                        networkSession = Sql.uuid(result, "session_id");
                        oldServer = result.getString("server_name");
                    }
                }
            }
            if (networkSession != null && serverName != null
                    && !serverName.equalsIgnoreCase(Objects.toString(oldServer, ""))) {
                closeServerSessions(connection, playerId, networkSession);
                try (PreparedStatement insert = connection.prepareStatement(
                        "INSERT INTO player_server_sessions(id,player_uuid,network_session_id,server_name,started_at) "
                                + "VALUES(?,?,?,?,UTC_TIMESTAMP(6))")) {
                    Sql.uuid(insert, 1, UUID.randomUUID());
                    Sql.uuid(insert, 2, playerId);
                    Sql.uuid(insert, 3, networkSession);
                    insert.setString(4, serverName);
                    insert.executeUpdate();
                }
            }
            try (PreparedStatement update = connection.prepareStatement(
                    "UPDATE server_presence SET server_name=COALESCE(?,server_name),last_seen_at=UTC_TIMESTAMP(6) WHERE player_uuid=?")) {
                update.setString(1, serverName);
                Sql.uuid(update, 2, playerId);
                update.executeUpdate();
            }
            return null;
        });
    }

    public void offline(UUID playerId) {
        db.transaction(connection -> {
            UUID sessionId = null;
            try (PreparedStatement query = connection.prepareStatement(
                    "SELECT session_id FROM server_presence WHERE player_uuid=? FOR UPDATE")) {
                Sql.uuid(query, 1, playerId);
                try (ResultSet result = query.executeQuery()) {
                    if (result.next()) sessionId = Sql.uuid(result, "session_id");
                }
            }
            if (sessionId != null) closeServerSessions(connection, playerId, sessionId);
            try (PreparedStatement delete = connection.prepareStatement(
                    "DELETE FROM server_presence WHERE player_uuid=?")) {
                Sql.uuid(delete, 1, playerId);
                delete.executeUpdate();
            }
            return null;
        });
    }

    public Optional<PresenceRecord> find(UUID playerId) {
        return db.read(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM server_presence WHERE player_uuid=?")) {
                Sql.uuid(statement, 1, playerId);
                try (ResultSet result = statement.executeQuery()) {
                    return result.next() ? Optional.of(map(result)) : Optional.empty();
                }
            }
        });
    }

    public List<PresenceRecord> staffOnline() {
        return db.read(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT * FROM server_presence WHERE is_staff=1 ORDER BY player_name")) {
                try (ResultSet result = statement.executeQuery()) {
                    List<PresenceRecord> records = new ArrayList<>();
                    while (result.next()) records.add(map(result));
                    return records;
                }
            }
        });
    }

    public int cleanupStaleBefore(Instant cutoff) {
        return db.transaction(connection -> {
            List<StalePresence> stale = new ArrayList<>();
            try (PreparedStatement select = connection.prepareStatement(
                    "SELECT player_uuid,session_id FROM server_presence WHERE last_seen_at<? FOR UPDATE")) {
                Sql.instant(select, 1, cutoff);
                try (ResultSet result = select.executeQuery()) {
                    while (result.next()) {
                        stale.add(new StalePresence(
                                Sql.uuid(result, "player_uuid"),
                                Sql.uuid(result, "session_id")));
                    }
                }
            }
            int removed = 0;
            for (StalePresence record : stale) {
                closeServerSessions(connection, record.playerId(), record.sessionId());
                try (PreparedStatement delete = connection.prepareStatement(
                        "DELETE FROM server_presence WHERE player_uuid=? AND session_id=? AND last_seen_at<?")) {
                    Sql.uuid(delete, 1, record.playerId());
                    Sql.uuid(delete, 2, record.sessionId());
                    Sql.instant(delete, 3, cutoff);
                    removed += delete.executeUpdate();
                }
            }
            return removed;
        });
    }

    private void closeServerSessions(Connection connection, UUID playerId, UUID networkSessionId) throws SQLException {
        try (PreparedStatement close = connection.prepareStatement(
                "UPDATE player_server_sessions SET ended_at=UTC_TIMESTAMP(6) "
                        + "WHERE player_uuid=? AND network_session_id=? AND ended_at IS NULL")) {
            Sql.uuid(close, 1, playerId);
            Sql.uuid(close, 2, networkSessionId);
            close.executeUpdate();
        }
    }

    private PresenceRecord map(ResultSet result) throws SQLException {
        return new PresenceRecord(
                Sql.uuid(result, "player_uuid"),
                result.getString("player_name"),
                result.getString("server_name"),
                Sql.uuid(result, "session_id"),
                result.getBoolean("is_staff"),
                Sql.instant(result, "connected_at"),
                Sql.instant(result, "last_seen_at"));
    }

    private record StalePresence(UUID playerId, UUID sessionId) {}
}
