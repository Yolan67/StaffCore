package de.yolan.staffcore.data;

import de.yolan.staffcore.common.model.AuditEvent;
import java.sql.*;
import java.time.Instant;
import java.util.*;

public final class AuditRepository {
    public record Query(UUID actor,UUID target,String action,String server,Instant from,Instant to){}
    private final DatabaseManager db;
    public AuditRepository(DatabaseManager db){this.db=db;}
    public void append(AuditEvent e){db.transaction(c->{append(c,e);return null;});}
    void append(Connection c,AuditEvent e)throws SQLException{try(PreparedStatement p=c.prepareStatement("INSERT INTO audit_log(id,correlation_id,actor_uuid,actor_name,target_uuid,server_name,action_type,before_json,after_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)")){int i=1;Sql.uuid(p,i++,e.id());Sql.uuid(p,i++,e.correlationId());Sql.uuid(p,i++,e.actorUuid());p.setString(i++,e.actorName());Sql.uuid(p,i++,e.targetUuid());p.setString(i++,e.serverName());p.setString(i++,e.actionType());p.setString(i++,e.beforeJson());p.setString(i++,e.afterJson());Sql.instant(p,i,e.createdAt());p.executeUpdate();}}
    public List<AuditEvent> search(Query q,int offset,int limit){return db.read(c->{StringBuilder sql=new StringBuilder("SELECT * FROM audit_log WHERE 1=1");List<Object>a=new ArrayList<>();if(q.actor()!=null){sql.append(" AND actor_uuid=?");a.add(q.actor());}if(q.target()!=null){sql.append(" AND target_uuid=?");a.add(q.target());}if(q.action()!=null&&!q.action().isBlank()){sql.append(" AND action_type=?");a.add(q.action());}if(q.server()!=null&&!q.server().isBlank()){sql.append(" AND server_name=?");a.add(q.server());}if(q.from()!=null){sql.append(" AND created_at>=?");a.add(q.from());}if(q.to()!=null){sql.append(" AND created_at<=?");a.add(q.to());}sql.append(" ORDER BY created_at DESC LIMIT ? OFFSET ?");try(PreparedStatement p=c.prepareStatement(sql.toString())){int i=1;for(Object o:a){if(o instanceof UUID u)Sql.uuid(p,i++,u);else if(o instanceof Instant t)Sql.instant(p,i++,t);else p.setString(i++,String.valueOf(o));}p.setInt(i++,Math.max(1,Math.min(limit,100)));p.setInt(i,Math.max(0,offset));try(ResultSet r=p.executeQuery()){List<AuditEvent>x=new ArrayList<>();while(r.next())x.add(map(r));return x;}}});}
    private AuditEvent map(ResultSet r)throws SQLException{return new AuditEvent(Sql.uuid(r,"id"),Sql.uuid(r,"correlation_id"),Sql.uuid(r,"actor_uuid"),r.getString("actor_name"),Sql.uuid(r,"target_uuid"),r.getString("server_name"),r.getString("action_type"),r.getString("before_json"),r.getString("after_json"),Sql.instant(r,"created_at"));}
}
