package de.yolan.staffcore.data;

import de.yolan.staffcore.common.model.Punishment;
import de.yolan.staffcore.common.punishment.*;
import java.sql.*;
import java.time.Instant;
import java.util.*;

public final class PunishmentRepository {
    private final DatabaseManager db;
    public PunishmentRepository(DatabaseManager db){this.db=db;}
    public Punishment create(Punishment x){return db.transaction(c->insert(c,x));}
    public Punishment createIdempotent(Punishment x){return db.transaction(c->{try{return insert(c,x);}catch(SQLException ex){if(!"23000".equals(ex.getSQLState()))throw ex;return findByIdempotency(c,x.idempotencyKey()).orElseThrow(()->ex);}});}
    public Optional<Punishment> findByIdempotency(String key){return db.read(c->findByIdempotency(c,key));}
    private Optional<Punishment> findByIdempotency(Connection c,String key)throws SQLException{try(PreparedStatement p=c.prepareStatement("SELECT * FROM punishments WHERE idempotency_key=? LIMIT 1")){p.setString(1,key);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}}}
    Punishment insert(Connection c,Punishment x)throws SQLException{
        try(PreparedStatement p=c.prepareStatement("INSERT INTO punishments(id,target_uuid,actor_uuid,actor_name,type,scope,server_name,reason,description,created_at,expires_at,status,idempotency_key,system_generated) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)")){
            int i=1;Sql.uuid(p,i++,x.id());Sql.uuid(p,i++,x.targetUuid());Sql.uuid(p,i++,x.actorUuid());p.setString(i++,x.actorName());p.setString(i++,x.type().name());p.setString(i++,x.scope().name());p.setString(i++,x.serverName());p.setString(i++,x.reason());p.setString(i++,x.description());Sql.instant(p,i++,x.createdAt());Sql.instant(p,i++,x.expiresAt());p.setString(i++,x.status().name());p.setString(i++,x.idempotencyKey());p.setBoolean(i,x.systemGenerated());p.executeUpdate();
        } return x;
    }
    public Optional<Punishment> find(UUID id){return db.read(c->{try(PreparedStatement p=c.prepareStatement("SELECT * FROM punishments WHERE id=?")){Sql.uuid(p,1,id);try(ResultSet r=p.executeQuery()){return r.next()?Optional.of(map(r)):Optional.empty();}}});}
    public List<Punishment> activeFor(UUID u,Instant now){return db.read(c->{try(PreparedStatement p=c.prepareStatement("SELECT * FROM punishments WHERE target_uuid=? AND status='ACTIVE' AND (expires_at IS NULL OR expires_at>?) ORDER BY created_at DESC")){Sql.uuid(p,1,u);Sql.instant(p,2,now);try(ResultSet r=p.executeQuery()){List<Punishment> out=new ArrayList<>();while(r.next())out.add(map(r));return out;}}});}
    public List<Punishment> historyFor(UUID u,int offset,int limit){return db.read(c->{try(PreparedStatement p=c.prepareStatement("SELECT * FROM punishments WHERE target_uuid=? ORDER BY created_at DESC LIMIT ? OFFSET ?")){Sql.uuid(p,1,u);p.setInt(2,Math.max(1,Math.min(limit,100)));p.setInt(3,Math.max(0,offset));try(ResultSet r=p.executeQuery()){List<Punishment> out=new ArrayList<>();while(r.next())out.add(map(r));return out;}}});}
    public boolean revoke(UUID id,UUID actor,String reason){return db.transaction(c->{try(PreparedStatement p=c.prepareStatement("UPDATE punishments SET status='REVOKED' WHERE id=? AND status='ACTIVE'")){Sql.uuid(p,1,id);if(p.executeUpdate()!=1)return false;}try(PreparedStatement p=c.prepareStatement("INSERT INTO punishment_actions(punishment_id,actor_uuid,action_type,reason,created_at) VALUES(?,?, 'REVOKE',?,UTC_TIMESTAMP(6))")){Sql.uuid(p,1,id);Sql.uuid(p,2,actor);p.setString(3,reason);p.executeUpdate();}return true;});}
    public int expireDue(Instant now){return db.transaction(c->{try(PreparedStatement p=c.prepareStatement("UPDATE punishments SET status='EXPIRED' WHERE status='ACTIVE' AND expires_at IS NOT NULL AND expires_at<=?")){Sql.instant(p,1,now);return p.executeUpdate();}});}
    private Punishment map(ResultSet r)throws SQLException{return new Punishment(Sql.uuid(r,"id"),Sql.uuid(r,"target_uuid"),Sql.uuid(r,"actor_uuid"),r.getString("actor_name"),PunishmentType.valueOf(r.getString("type")),PunishmentScope.valueOf(r.getString("scope")),r.getString("server_name"),r.getString("reason"),r.getString("description"),Sql.instant(r,"created_at"),Sql.instant(r,"expires_at"),PunishmentStatus.valueOf(r.getString("status")),r.getString("idempotency_key"),r.getBoolean("system_generated"));}
}
