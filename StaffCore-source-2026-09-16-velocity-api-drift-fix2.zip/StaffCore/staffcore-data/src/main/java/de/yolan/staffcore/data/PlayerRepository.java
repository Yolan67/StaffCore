package de.yolan.staffcore.data;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

public final class PlayerRepository {
    public record PlayerInfo(UUID uuid, String currentName, Instant firstSeen, Instant lastSeen, List<String> knownNames) {}

    private final DatabaseManager db;

    public PlayerRepository(DatabaseManager db) {
        this.db = db;
    }

    public void upsert(UUID uuid, String name) {
        db.transaction(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO players(uuid,current_name,first_seen,last_seen) VALUES(?,?,UTC_TIMESTAMP(6),UTC_TIMESTAMP(6)) " +
                            "ON DUPLICATE KEY UPDATE current_name=VALUES(current_name),last_seen=UTC_TIMESTAMP(6)")) {
                Sql.uuid(statement, 1, uuid);
                statement.setString(2, name);
                statement.executeUpdate();
            }
            try (PreparedStatement statement = connection.prepareStatement(
                    "INSERT INTO known_names(player_uuid,name,first_seen,last_seen) VALUES(?,?,UTC_TIMESTAMP(6),UTC_TIMESTAMP(6)) " +
                            "ON DUPLICATE KEY UPDATE last_seen=UTC_TIMESTAMP(6)")) {
                Sql.uuid(statement, 1, uuid);
                statement.setString(2, name);
                statement.executeUpdate();
            }
            return null;
        });
    }

    public Optional<UUID> findUuidByName(String name) {
        return db.read(connection -> {
            try (PreparedStatement statement = connection.prepareStatement(
                    "SELECT player_uuid FROM known_names WHERE LOWER(name)=LOWER(?) ORDER BY last_seen DESC LIMIT 1")) {
                statement.setString(1, name);
                try (ResultSet result = statement.executeQuery()) {
                    return result.next() ? Optional.of(Sql.uuid(result, "player_uuid")) : Optional.empty();
                }
            }
        });
    }

    public Optional<PlayerInfo> find(UUID uuid) {
        return db.read(connection -> {
            try (PreparedStatement statement = connection.prepareStatement("SELECT * FROM players WHERE uuid=?")) {
                Sql.uuid(statement, 1, uuid);
                try (ResultSet result = statement.executeQuery()) {
                    if (!result.next()) return Optional.empty();
                    String currentName = result.getString("current_name");
                    Instant firstSeen = Sql.instant(result, "first_seen");
                    Instant lastSeen = Sql.instant(result, "last_seen");
                    List<String> names = new ArrayList<>();
                    try (PreparedStatement namesStatement = connection.prepareStatement(
                            "SELECT name FROM known_names WHERE player_uuid=? ORDER BY last_seen DESC LIMIT 20")) {
                        Sql.uuid(namesStatement, 1, uuid);
                        try (ResultSet namesResult = namesStatement.executeQuery()) {
                            while (namesResult.next()) names.add(namesResult.getString(1));
                        }
                    }
                    return Optional.of(new PlayerInfo(uuid, currentName, firstSeen, lastSeen, List.copyOf(names)));
                }
            }
        });
    }
}
