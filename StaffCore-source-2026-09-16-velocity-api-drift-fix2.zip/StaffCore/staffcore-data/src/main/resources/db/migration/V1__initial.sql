CREATE TABLE players (
  uuid BINARY(16) NOT NULL PRIMARY KEY,
  current_name VARCHAR(16) NOT NULL,
  first_seen DATETIME(6) NOT NULL,
  last_seen DATETIME(6) NOT NULL,
  INDEX idx_players_name (current_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE known_names (
  player_uuid BINARY(16) NOT NULL,
  name VARCHAR(16) NOT NULL,
  first_seen DATETIME(6) NOT NULL,
  last_seen DATETIME(6) NOT NULL,
  PRIMARY KEY (player_uuid, name),
  INDEX idx_known_names_name (name),
  CONSTRAINT fk_known_names_player FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staff_preferences (
  staff_uuid BINARY(16) NOT NULL PRIMARY KEY,
  join_summary TINYINT(1) NOT NULL DEFAULT 1,
  notifications TINYINT(1) NOT NULL DEFAULT 1,
  updated_at DATETIME(6) NOT NULL,
  CONSTRAINT fk_staff_preferences_player FOREIGN KEY (staff_uuid) REFERENCES players(uuid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staff_sessions (
  id BINARY(16) NOT NULL PRIMARY KEY,
  staff_uuid BINARY(16) NOT NULL,
  proxy_instance VARCHAR(64) NOT NULL,
  current_server VARCHAR(64) NULL,
  rank_name VARCHAR(32) NOT NULL,
  started_at DATETIME(6) NOT NULL,
  last_seen_at DATETIME(6) NOT NULL,
  ended_at DATETIME(6) NULL,
  INDEX idx_staff_sessions_active (staff_uuid, ended_at),
  CONSTRAINT fk_staff_sessions_player FOREIGN KEY (staff_uuid) REFERENCES players(uuid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staff_states (
  staff_uuid BINARY(16) NOT NULL PRIMARY KEY,
  vanished TINYINT(1) NOT NULL DEFAULT 0,
  staff_chat TINYINT(1) NOT NULL DEFAULT 0,
  revision BIGINT NOT NULL DEFAULT 0,
  updated_at DATETIME(6) NOT NULL,
  CONSTRAINT fk_staff_states_player FOREIGN KEY (staff_uuid) REFERENCES players(uuid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staffmode_snapshots (
  session_id BINARY(16) NOT NULL PRIMARY KEY,
  player_uuid BINARY(16) NOT NULL,
  active_player_uuid BINARY(16) NULL,
  format_version INT NOT NULL,
  state VARCHAR(32) NOT NULL,
  origin_server VARCHAR(64) NOT NULL,
  origin_world VARCHAR(128) NOT NULL,
  x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL,
  yaw FLOAT NOT NULL, pitch FLOAT NOT NULL,
  payload LONGBLOB NOT NULL,
  checksum CHAR(64) NOT NULL,
  revision BIGINT NOT NULL DEFAULT 0,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_staffmode_active_player (active_player_uuid),
  INDEX idx_staffmode_player_created (player_uuid, created_at),
  CONSTRAINT fk_staffmode_player FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE freeze_states (
  player_uuid BINARY(16) NOT NULL PRIMARY KEY,
  active TINYINT(1) NOT NULL,
  session_id BINARY(16) NOT NULL,
  actor_uuid BINARY(16) NULL,
  reason VARCHAR(512) NOT NULL,
  last_server VARCHAR(64) NULL,
  last_world VARCHAR(128) NULL,
  x DOUBLE NULL, y DOUBLE NULL, z DOUBLE NULL,
  revision BIGINT NOT NULL DEFAULT 0,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  INDEX idx_freeze_active (active),
  CONSTRAINT fk_freeze_player FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE spectate_sessions (
  id BINARY(16) NOT NULL PRIMARY KEY,
  staff_uuid BINARY(16) NOT NULL,
  target_uuid BINARY(16) NOT NULL,
  mode VARCHAR(16) NOT NULL,
  origin_server VARCHAR(64) NOT NULL,
  origin_world VARCHAR(128) NOT NULL,
  origin_x DOUBLE NOT NULL, origin_y DOUBLE NOT NULL, origin_z DOUBLE NOT NULL,
  origin_yaw FLOAT NOT NULL, origin_pitch FLOAT NOT NULL,
  origin_gamemode VARCHAR(24) NOT NULL,
  origin_vanished TINYINT(1) NOT NULL,
  state VARCHAR(32) NOT NULL,
  revision BIGINT NOT NULL DEFAULT 0,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  ended_at DATETIME(6) NULL,
  INDEX idx_spectate_staff_active (staff_uuid, ended_at),
  CONSTRAINT fk_spectate_staff FOREIGN KEY (staff_uuid) REFERENCES players(uuid) ON DELETE CASCADE,
  CONSTRAINT fk_spectate_target FOREIGN KEY (target_uuid) REFERENCES players(uuid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE punishments (
  id BINARY(16) NOT NULL PRIMARY KEY,
  target_uuid BINARY(16) NOT NULL,
  actor_uuid BINARY(16) NULL,
  actor_name VARCHAR(64) NOT NULL,
  type VARCHAR(32) NOT NULL,
  scope VARCHAR(16) NOT NULL,
  server_name VARCHAR(64) NULL,
  reason VARCHAR(256) NOT NULL,
  description VARCHAR(2048) NULL,
  created_at DATETIME(6) NOT NULL,
  expires_at DATETIME(6) NULL,
  status VARCHAR(16) NOT NULL,
  idempotency_key VARCHAR(160) NOT NULL,
  system_generated TINYINT(1) NOT NULL DEFAULT 0,
  UNIQUE KEY uq_punishment_idempotency (idempotency_key),
  INDEX idx_punishment_target_status_expiry (target_uuid, status, expires_at),
  INDEX idx_punishment_scope_server (scope, server_name, status),
  CONSTRAINT fk_punishments_target FOREIGN KEY (target_uuid) REFERENCES players(uuid) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE punishment_actions (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  punishment_id BINARY(16) NOT NULL,
  actor_uuid BINARY(16) NULL,
  action_type VARCHAR(32) NOT NULL,
  reason VARCHAR(512) NULL,
  created_at DATETIME(6) NOT NULL,
  INDEX idx_punishment_actions (punishment_id, created_at),
  CONSTRAINT fk_punishment_actions_punishment FOREIGN KEY (punishment_id) REFERENCES punishments(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE tickets (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  creator_uuid BINARY(16) NOT NULL,
  target_uuid BINARY(16) NULL,
  category VARCHAR(32) NOT NULL,
  subcategory VARCHAR(64) NULL,
  subject VARCHAR(160) NOT NULL,
  description VARCHAR(4096) NOT NULL,
  server_name VARCHAR(64) NULL,
  status VARCHAR(32) NOT NULL,
  priority VARCHAR(16) NOT NULL,
  priority_score INT NOT NULL,
  minimum_rank VARCHAR(24) NOT NULL,
  assignee_uuid BINARY(16) NULL,
  assignee_rank VARCHAR(24) NULL,
  revision INT NOT NULL DEFAULT 0,
  reopen_count INT NOT NULL DEFAULT 0,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  INDEX idx_tickets_queue (status, assignee_uuid, priority_score, created_at),
  INDEX idx_tickets_creator (creator_uuid, updated_at),
  INDEX idx_tickets_target (target_uuid, updated_at),
  CONSTRAINT fk_tickets_creator FOREIGN KEY (creator_uuid) REFERENCES players(uuid) ON DELETE RESTRICT,
  CONSTRAINT fk_tickets_target FOREIGN KEY (target_uuid) REFERENCES players(uuid) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ticket_messages (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id BIGINT NOT NULL,
  author_uuid BINARY(16) NULL,
  author_name VARCHAR(64) NOT NULL,
  is_staff TINYINT(1) NOT NULL,
  message VARCHAR(4096) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  INDEX idx_ticket_messages (ticket_id, created_at),
  CONSTRAINT fk_ticket_messages_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ticket_internal_notes (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id BIGINT NOT NULL,
  author_uuid BINARY(16) NOT NULL,
  note VARCHAR(4096) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  INDEX idx_ticket_internal_notes (ticket_id, created_at),
  CONSTRAINT fk_ticket_internal_notes_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ticket_assignments (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id BIGINT NOT NULL,
  previous_staff_uuid BINARY(16) NULL,
  new_staff_uuid BINARY(16) NULL,
  reason VARCHAR(512) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  INDEX idx_ticket_assignments (ticket_id, created_at),
  CONSTRAINT fk_ticket_assignments_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE ticket_events (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  ticket_id BIGINT NOT NULL,
  event_type VARCHAR(48) NOT NULL,
  event_data VARCHAR(4096) NULL,
  created_at DATETIME(6) NOT NULL,
  INDEX idx_ticket_events (ticket_id, created_at),
  CONSTRAINT fk_ticket_events_ticket FOREIGN KEY (ticket_id) REFERENCES tickets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staff_notes (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target_uuid BINARY(16) NOT NULL,
  author_uuid BINARY(16) NOT NULL,
  category VARCHAR(64) NULL,
  current_text VARCHAR(4096) NOT NULL,
  archived TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  INDEX idx_staff_notes_target (target_uuid, archived, updated_at),
  CONSTRAINT fk_staff_notes_target FOREIGN KEY (target_uuid) REFERENCES players(uuid) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staff_note_revisions (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  note_id BIGINT NOT NULL,
  editor_uuid BINARY(16) NOT NULL,
  text VARCHAR(4096) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  INDEX idx_staff_note_revisions (note_id, created_at),
  CONSTRAINT fk_staff_note_revisions_note FOREIGN KEY (note_id) REFERENCES staff_notes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE notifications (
  id BINARY(16) NOT NULL PRIMARY KEY,
  recipient_uuid BINARY(16) NOT NULL,
  type VARCHAR(48) NOT NULL,
  title VARCHAR(160) NOT NULL,
  body VARCHAR(2048) NOT NULL,
  dedupe_key VARCHAR(160) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME(6) NOT NULL,
  read_at DATETIME(6) NULL,
  UNIQUE KEY uq_notification_dedupe (recipient_uuid, dedupe_key),
  INDEX idx_notifications_unread (recipient_uuid, is_read, created_at),
  CONSTRAINT fk_notifications_recipient FOREIGN KEY (recipient_uuid) REFERENCES players(uuid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE audit_log (
  id BINARY(16) NOT NULL PRIMARY KEY,
  correlation_id BINARY(16) NOT NULL,
  actor_uuid BINARY(16) NULL,
  actor_name VARCHAR(64) NOT NULL,
  target_uuid BINARY(16) NULL,
  server_name VARCHAR(64) NULL,
  action_type VARCHAR(64) NOT NULL,
  before_json TEXT NULL,
  after_json TEXT NULL,
  created_at DATETIME(6) NOT NULL,
  INDEX idx_audit_actor_time (actor_uuid, created_at),
  INDEX idx_audit_target_time (target_uuid, created_at),
  INDEX idx_audit_action_time (action_type, created_at),
  INDEX idx_audit_correlation (correlation_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staff_activity_events (
  id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  staff_uuid BINARY(16) NOT NULL,
  event_type VARCHAR(64) NOT NULL,
  reference_id VARCHAR(128) NULL,
  created_at DATETIME(6) NOT NULL,
  INDEX idx_staff_activity (staff_uuid, event_type, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE server_presence (
  player_uuid BINARY(16) NOT NULL PRIMARY KEY,
  player_name VARCHAR(16) NOT NULL,
  server_name VARCHAR(64) NULL,
  session_id BINARY(16) NOT NULL,
  is_staff TINYINT(1) NOT NULL DEFAULT 0,
  rank_name VARCHAR(24) NULL,
  connected_at DATETIME(6) NOT NULL,
  last_seen_at DATETIME(6) NOT NULL,
  INDEX idx_presence_server (server_name, last_seen_at),
  INDEX idx_presence_staff (is_staff, last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE presence_sessions (
  id BINARY(16) NOT NULL PRIMARY KEY,
  player_uuid BINARY(16) NOT NULL,
  server_name VARCHAR(64) NULL,
  started_at DATETIME(6) NOT NULL,
  ended_at DATETIME(6) NULL,
  INDEX idx_presence_sessions_player (player_uuid, started_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE transactional_outbox (
  id BINARY(16) NOT NULL PRIMARY KEY,
  event_type VARCHAR(64) NOT NULL,
  dedupe_key VARCHAR(160) NOT NULL,
  payload MEDIUMTEXT NOT NULL,
  status VARCHAR(16) NOT NULL,
  attempts INT NOT NULL DEFAULT 0,
  next_attempt_at DATETIME(6) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  processed_at DATETIME(6) NULL,
  UNIQUE KEY uq_outbox_dedupe (dedupe_key),
  INDEX idx_outbox_pending (status, next_attempt_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE processed_messages (
  node_id VARCHAR(96) NOT NULL,
  message_id BINARY(16) NOT NULL,
  processed_at DATETIME(6) NOT NULL,
  PRIMARY KEY (node_id, message_id),
  INDEX idx_processed_messages_time (processed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE staffmode_backend_snapshots (
  session_id BINARY(16) NOT NULL,
  player_uuid BINARY(16) NOT NULL,
  server_name VARCHAR(64) NOT NULL,
  format_version INT NOT NULL,
  payload LONGBLOB NOT NULL,
  checksum CHAR(64) NOT NULL,
  state VARCHAR(24) NOT NULL,
  revision BIGINT NOT NULL DEFAULT 0,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  PRIMARY KEY (session_id, server_name),
  INDEX idx_staffmode_backend_player_state (player_uuid, state),
  CONSTRAINT fk_staffmode_backend_session FOREIGN KEY (session_id) REFERENCES staffmode_snapshots(session_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
