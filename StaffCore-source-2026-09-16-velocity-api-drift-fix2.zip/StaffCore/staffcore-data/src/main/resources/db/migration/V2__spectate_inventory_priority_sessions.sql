ALTER TABLE spectate_sessions
  ADD COLUMN active_staff_uuid BINARY(16) NULL AFTER staff_uuid;
UPDATE spectate_sessions SET active_staff_uuid=staff_uuid WHERE ended_at IS NULL;
ALTER TABLE spectate_sessions
  ADD UNIQUE KEY uq_spectate_active_staff (active_staff_uuid);

ALTER TABLE tickets
  ADD COLUMN priority_explanation VARCHAR(4096) NULL AFTER priority_score;

CREATE TABLE inventory_edit_locks (
  target_uuid BINARY(16) NOT NULL PRIMARY KEY,
  editor_uuid BINARY(16) NOT NULL,
  session_id BINARY(16) NOT NULL,
  revision BIGINT NOT NULL DEFAULT 0,
  expires_at DATETIME(6) NOT NULL,
  created_at DATETIME(6) NOT NULL,
  updated_at DATETIME(6) NOT NULL,
  UNIQUE KEY uq_inventory_edit_session (session_id),
  INDEX idx_inventory_lock_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE player_server_sessions (
  id BINARY(16) NOT NULL PRIMARY KEY,
  player_uuid BINARY(16) NOT NULL,
  network_session_id BINARY(16) NOT NULL,
  server_name VARCHAR(64) NOT NULL,
  started_at DATETIME(6) NOT NULL,
  ended_at DATETIME(6) NULL,
  INDEX idx_player_server_sessions_player (player_uuid, started_at),
  INDEX idx_player_server_sessions_network (network_session_id, started_at),
  INDEX idx_player_server_sessions_open (player_uuid, ended_at),
  CONSTRAINT fk_player_server_sessions_player FOREIGN KEY (player_uuid) REFERENCES players(uuid) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
