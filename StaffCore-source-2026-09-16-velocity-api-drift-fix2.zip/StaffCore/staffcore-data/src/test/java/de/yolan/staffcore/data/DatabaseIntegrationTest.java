package de.yolan.staffcore.data;

import de.yolan.staffcore.common.model.*;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.common.state.StaffModeState;
import de.yolan.staffcore.common.ticket.*;
import org.junit.jupiter.api.*;
import org.testcontainers.containers.MariaDBContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import java.time.Instant;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

@Testcontainers(disabledWithoutDocker = true)
class DatabaseIntegrationTest {
    @Container static final MariaDBContainer<?> DB = new MariaDBContainer<>("mariadb:11.8").withDatabaseName("staffcore").withUsername("staffcore").withPassword("staffcore");
    static DatabaseManager manager; static Repositories repos;
    @BeforeAll static void start(){ manager=new DatabaseManager(new DatabaseConfig(DB.getJdbcUrl(),DB.getUsername(),DB.getPassword(),4,5000)); repos=new Repositories(manager); }
    @AfterAll static void stop(){ if(manager!=null) manager.close(); }
    @Test void migrationAndStateCas(){UUID u=UUID.randomUUID();repos.players.upsert(u,"Tester");var s=repos.staffStates.getOrCreate(u);assertEquals(0,s.revision());assertTrue(repos.staffStates.compareAndSet(u,0,true,null).orElseThrow().vanished());assertTrue(repos.staffStates.compareAndSet(u,0,false,null).isEmpty());}
    @Test void singleActiveStaffModeSnapshot(){UUID u=UUID.randomUUID();repos.players.upsert(u,"ModeUser");var x=new StaffModeSnapshotRecord(UUID.randomUUID(),u,1,StaffModeState.CAPTURED,"lobby","world",0,64,0,0,0,new byte[]{1,2,3},"a".repeat(64),0,Instant.now(),Instant.now());repos.staffMode.create(x);assertThrows(RepositoryException.class,()->repos.staffMode.create(new StaffModeSnapshotRecord(UUID.randomUUID(),u,1,StaffModeState.CAPTURED,"lobby","world",0,64,0,0,0,new byte[]{4},"b".repeat(64),0,Instant.now(),Instant.now())));}
    @Test void ticketClaimIsCas(){UUID creator=UUID.randomUUID(),a=UUID.randomUUID(),b=UUID.randomUUID();repos.players.upsert(creator,"Creator");Ticket t=repos.tickets.create(new Ticket(0,creator,null,TicketCategory.HELP,null,"Help","Need help",null,TicketStatus.OPEN,TicketPriority.NORMAL,30,"test",StaffRank.JR_MOD,null,0,0,Instant.now(),Instant.now()));assertTrue(repos.tickets.claim(t.id(),a,t.revision()).isPresent());assertTrue(repos.tickets.claim(t.id(),b,t.revision()).isEmpty());}

    @Test void freezeLeaveTempbanIsIdempotent(){
        UUID player=UUID.randomUUID(),actor=UUID.randomUUID();
        repos.players.upsert(player,"FrozenUser");
        repos.players.upsert(actor,"Moderator");
        var freeze=repos.freezes.freezeIfInactive(player,actor,"check").record();
        ModerationTransactions tx=new ModerationTransactions(manager,repos.punishments);
        assertTrue(tx.freezeLeave(player,freeze.sessionId(),"survival","world",1d,64d,1d,java.time.Duration.ofMinutes(5)));
        assertFalse(tx.freezeLeave(player,freeze.sessionId(),"survival","world",1d,64d,1d,java.time.Duration.ofMinutes(5)));
        assertEquals(1,repos.punishments.activeFor(player,Instant.now()).stream().filter(Punishment::systemGenerated).count());
        assertTrue(repos.freezes.find(player).orElseThrow().active());
    }

    @Test void punishmentIdempotencyKeyReturnsExistingRow(){
        UUID player=UUID.randomUUID();
        repos.players.upsert(player,"PunishedUser");
        Instant now=Instant.now();
        Punishment first=new Punishment(UUID.randomUUID(),player,null,"SYSTEM",
                de.yolan.staffcore.common.punishment.PunishmentType.MUTE,
                de.yolan.staffcore.common.punishment.PunishmentScope.NETWORK,null,"reason",null,now,
                now.plusSeconds(60),de.yolan.staffcore.common.punishment.PunishmentStatus.ACTIVE,"idem-test-"+player,false);
        Punishment saved=repos.punishments.createIdempotent(first);
        Punishment duplicate=repos.punishments.createIdempotent(new Punishment(UUID.randomUUID(),player,null,"SYSTEM",
                first.type(),first.scope(),null,"other",null,now,now.plusSeconds(120),first.status(),first.idempotencyKey(),false));
        assertEquals(saved.id(),duplicate.id());
    }
}
