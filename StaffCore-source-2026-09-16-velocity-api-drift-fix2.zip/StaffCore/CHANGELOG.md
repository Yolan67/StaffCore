# Changelog

## 0.1.0-SNAPSHOT
- Initial StaffCore implementation scaffold and core feature set.
- Fixed Velocity 4.1.2 `RegisteredServer` package usage (`com.velocitypowered.api.proxy.server.RegisteredServer`) in SpectateCoordinator, PunishmentCommand, BridgeListener and PunishmentRequestService.
- Added a static Velocity API guard preventing the obsolete/incorrect root-package `RegisteredServer` import.
- Fixed missing `de.yolan.staffcore.common.protocol.MessageType` import in `PunishmentService`.
- Updated `TicketRoutingService` from obsolete `AssignmentEngine.choose(...)` to the real Common API `select(List<StaffCandidate>, StaffRank)` with correct argument order and selected-candidate rank usage.
- Added static drift guards for unresolved Velocity `MessageType` references and obsolete `AssignmentEngine.choose(...)` calls.
