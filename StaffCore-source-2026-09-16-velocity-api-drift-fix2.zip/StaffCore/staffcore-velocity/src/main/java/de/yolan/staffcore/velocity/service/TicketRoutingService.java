package de.yolan.staffcore.velocity.service;

import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import de.yolan.staffcore.common.model.Ticket;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.ticket.AssignmentEngine;
import de.yolan.staffcore.common.ticket.DefaultAssignmentEngine;
import de.yolan.staffcore.common.ticket.RoutingDecision;
import de.yolan.staffcore.common.ticket.StaffCandidate;
import de.yolan.staffcore.data.Repositories;

import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class TicketRoutingService {
    private final ProxyServer proxy;
    private final Repositories repositories;
    private final RankService ranks;
    private final AssignmentEngine assignmentEngine = new DefaultAssignmentEngine();
    private final Map<String, Integer> capacities;
    private final Map<UUID, Instant> lastAssignedAt = new ConcurrentHashMap<>();

    public TicketRoutingService(
            ProxyServer proxy,
            Repositories repositories,
            RankService ranks,
            Map<String, Integer> capacities
    ) {
        this.proxy = proxy;
        this.repositories = repositories;
        this.ranks = ranks;
        this.capacities = capacities;
    }

    public void route() {
        for (Ticket ticket : repositories.tickets.listAssignable(50)) {
            List<StaffCandidate> candidates = buildCandidates();
            RoutingDecision decision = assignmentEngine.select(candidates, ticket.minimumRank());
            if (!decision.assigned()) {
                continue;
            }

            StaffCandidate selected = candidates.stream()
                    .filter(candidate -> candidate.uuid().equals(decision.selectedStaff()))
                    .findFirst()
                    .orElseThrow(() -> new IllegalStateException(
                            "AssignmentEngine selected a staff UUID that is not part of the candidate set"
                    ));

            repositories.tickets.claim(
                    ticket.id(),
                    decision.selectedStaff(),
                    selected.rank(),
                    ticket.revision()
            ).ifPresent(claimed -> lastAssignedAt.put(decision.selectedStaff(), Instant.now()));
        }
    }

    private List<StaffCandidate> buildCandidates() {
        List<StaffCandidate> candidates = new ArrayList<>();
        for (Player player : proxy.getAllPlayers()) {
            var rank = ranks.rank(player);
            if (rank.isEmpty()) {
                continue;
            }

            int capacity = capacities.getOrDefault(
                    rank.get().name().toLowerCase(Locale.ROOT),
                    5
            );
            int activeTickets = repositories.tickets.countActiveAssigned(player.getUniqueId());

            candidates.add(new StaffCandidate(
                    player.getUniqueId(),
                    player.getUsername(),
                    rank.get(),
                    true,
                    true,
                    player.hasPermission(Permissions.TICKET_CLAIM),
                    activeTickets,
                    capacity,
                    lastAssignedAt.get(player.getUniqueId())
            ));
        }
        return candidates;
    }
}
