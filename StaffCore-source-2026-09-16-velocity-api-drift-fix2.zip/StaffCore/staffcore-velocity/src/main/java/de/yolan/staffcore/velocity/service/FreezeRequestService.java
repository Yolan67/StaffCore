package de.yolan.staffcore.velocity.service;

import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.protocol.FreezeRequestPayload;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.StatePayload;
import de.yolan.staffcore.common.util.InputPolicy;
import de.yolan.staffcore.data.Repositories;
import java.util.ConcurrentModificationException;
import java.util.Objects;
import net.kyori.adventure.text.Component;

public final class FreezeRequestService {
    private final ProxyServer proxy;
    private final Repositories repos;
    private final BridgeHub bridge;
    private final AuditService audit;

    public FreezeRequestService(ProxyServer proxy, Repositories repos, BridgeHub bridge, AuditService audit) {
        this.proxy = proxy;
        this.repos = repos;
        this.bridge = bridge;
        this.audit = audit;
    }

    public void handle(FreezeRequestPayload request) {
        Player actor = proxy.getPlayer(request.actorUuid()).orElse(null);
        if (actor == null || !actor.hasPermission(Permissions.FREEZE)) return;
        if (request.targetUuid() == null || request.requestId() == null) {
            actor.sendMessage(Component.text("Freeze-Anfrage ungültig."));
            return;
        }

        try {
            if ("UNFREEZE".equalsIgnoreCase(request.action())) {
                unfreeze(actor, request);
                return;
            }
            if (!"FREEZE".equalsIgnoreCase(request.action())) {
                throw new IllegalArgumentException("Unbekannte Freeze-Aktion.");
            }

            String reason = InputPolicy.bounded(
                    Objects.requireNonNullElse(request.reason(), "Staff-Prüfung"), 512, "reason");
            var result = repos.freezes.freezeIfInactive(request.targetUuid(), actor.getUniqueId(), reason);
            var record = result.record();
            if (!result.changed()) {
                actor.sendMessage(Component.text("Spieler ist bereits gefreezt; bestehende Session blieb unverändert."));
                return;
            }

            audit.log(
                    actor.getUniqueId(), actor.getUsername(), request.targetUuid(), record.lastServer(),
                    "FREEZE", null,
                    "{\"requestId\":\"" + request.requestId() + "\",\"session\":\"" + record.sessionId()
                            + "\",\"reason\":\"" + json(reason) + "\"}");
            bridge.broadcast(
                    MessageType.FREEZE_CHANGED,
                    request.targetUuid(),
                    record.revision(),
                    new StatePayload(request.targetUuid(), false, false, true, reason, false, record.lastServer()));
            actor.sendMessage(Component.text("Spieler gefreezt."));
            proxy.getPlayer(request.targetUuid()).ifPresent(target -> target.sendMessage(Component.text(
                    "Du wurdest gefreezt. Du darfst normal im Chat schreiben; verlasse das Netzwerk nicht.")));
        } catch (Exception exception) {
            actor.sendMessage(Component.text("Freeze-Aktion fehlgeschlagen: " + safe(exception)));
        }
    }

    private void unfreeze(Player actor, FreezeRequestPayload request) {
        var record = repos.freezes.find(request.targetUuid())
                .filter(value -> value.active())
                .orElseThrow(() -> new IllegalStateException("Spieler ist nicht gefreezt."));
        if (!repos.freezes.unfreeze(request.targetUuid(), record.revision())) {
            throw new ConcurrentModificationException("Freeze wurde parallel verändert.");
        }
        audit.log(
                actor.getUniqueId(), actor.getUsername(), request.targetUuid(), record.lastServer(),
                "UNFREEZE",
                "{\"requestId\":\"" + request.requestId() + "\",\"revision\":" + record.revision() + "}",
                "{\"revision\":" + (record.revision() + 1) + "}");
        bridge.broadcast(
                MessageType.FREEZE_CHANGED,
                request.targetUuid(),
                record.revision() + 1,
                new StatePayload(request.targetUuid(), false, false, false, null, false, record.lastServer()));
        actor.sendMessage(Component.text("Freeze aufgehoben."));
    }

    private static String json(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }

    private static String safe(Throwable throwable) {
        while (throwable.getCause() != null) throwable = throwable.getCause();
        String message = throwable.getMessage();
        if (message == null || message.isBlank()) return throwable.getClass().getSimpleName();
        return message.substring(0, Math.min(180, message.length()));
    }
}
