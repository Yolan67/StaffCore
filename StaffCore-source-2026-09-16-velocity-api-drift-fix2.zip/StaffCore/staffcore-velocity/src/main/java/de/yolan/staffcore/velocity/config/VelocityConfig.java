package de.yolan.staffcore.velocity.config;

import de.yolan.staffcore.data.DatabaseConfig;

import java.time.Duration;
import java.util.Map;

public record VelocityConfig(
        int configVersion,
        DatabaseConfig database,
        String bridgeSecret,
        String proxyInstance,
        String messageLocale,
        Duration freezeLeaveTempban,
        String globalBanPermission,
        Map<String, Integer> ticketCapacity,
        boolean persistentInbox,
        boolean storePlayerIp,
        boolean auditCriticalActions,
        boolean maintenanceRequired,
        Duration routingInterval,
        Duration healthInterval,
        Duration punishmentExpiryInterval,
        Duration presenceHeartbeatInterval,
        Duration presenceStaleAfter,
        boolean degradedMode,
        boolean failClosedCriticalMutations) {

    public VelocityConfig {
        if (configVersion != 1) throw new IllegalArgumentException("Unsupported config-version: " + configVersion);
        if (bridgeSecret == null || bridgeSecret.length() < 32) {
            throw new IllegalArgumentException("bridge.secret must be at least 32 characters");
        }
        if (proxyInstance == null || proxyInstance.isBlank()) throw new IllegalArgumentException("proxy-instance is blank");
        if (messageLocale == null || messageLocale.isBlank()) throw new IllegalArgumentException("messages.locale is blank");
        if (freezeLeaveTempban == null || freezeLeaveTempban.isZero() || freezeLeaveTempban.isNegative()) {
            throw new IllegalArgumentException("freeze.leave-tempban must be positive");
        }
        if (!"staffcore.punishment.globalban".equals(globalBanPermission)) {
            throw new IllegalArgumentException("punishments.global-ban-requires must remain staffcore.punishment.globalban");
        }
        ticketCapacity = Map.copyOf(ticketCapacity);
        if (!persistentInbox) throw new IllegalArgumentException("notifications.persistent-inbox must remain true");
        if (storePlayerIp) throw new IllegalArgumentException("privacy.store-player-ip=true is intentionally unsupported");
        if (!auditCriticalActions) throw new IllegalArgumentException("logging.audit-critical-actions must remain true");
        if (maintenanceRequired) {
            throw new IllegalArgumentException("integrations.maintenancecore.required=true is unsupported without a public MaintenanceCore service");
        }
        if (!degradedMode) throw new IllegalArgumentException("runtime.degraded-mode must remain true");
        if (!failClosedCriticalMutations) {
            throw new IllegalArgumentException("recovery.fail-closed-for-critical-mutations must remain true");
        }
        requirePositive(routingInterval, "runtime.routing-interval");
        requirePositive(healthInterval, "runtime.health-interval");
        requirePositive(punishmentExpiryInterval, "runtime.punishment-expiry-interval");
        requirePositive(presenceHeartbeatInterval, "runtime.presence-heartbeat-interval");
        requirePositive(presenceStaleAfter, "runtime.presence-stale-after");
        if (presenceStaleAfter.compareTo(presenceHeartbeatInterval.multipliedBy(2)) <= 0) {
            throw new IllegalArgumentException(
                    "runtime.presence-stale-after must be greater than twice runtime.presence-heartbeat-interval");
        }
    }

    private static void requirePositive(Duration duration, String name) {
        if (duration == null || duration.isZero() || duration.isNegative()) {
            throw new IllegalArgumentException(name + " must be positive");
        }
    }
}
