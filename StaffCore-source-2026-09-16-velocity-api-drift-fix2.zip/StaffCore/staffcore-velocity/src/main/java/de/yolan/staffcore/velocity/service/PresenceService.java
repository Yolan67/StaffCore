package de.yolan.staffcore.velocity.service;

import com.velocitypowered.api.proxy.Player;
import de.yolan.staffcore.common.model.PresenceRecord;
import de.yolan.staffcore.data.Repositories;
import java.time.Instant;
import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PresenceService {
    public record Heartbeat(UUID playerId, String playerName, String serverName, boolean staff, String rankName) {}

    private final Repositories repositories;
    private final RankService ranks;
    private final Map<UUID, UUID> sessions = new ConcurrentHashMap<>();

    public PresenceService(Repositories repositories, RankService ranks) {
        this.repositories = repositories;
        this.ranks = ranks;
    }

    public void online(Player player, String serverName) {
        UUID sessionId = sessions.computeIfAbsent(player.getUniqueId(), ignored -> UUID.randomUUID());
        Instant now = Instant.now();
        repositories.presence.online(new PresenceRecord(
                player.getUniqueId(),
                player.getUsername(),
                serverName,
                sessionId,
                ranks.staff(player),
                now,
                now));
        repositories.presence.setRank(
                player.getUniqueId(),
                ranks.rank(player).map(Enum::name).orElse(null));
    }

    public void server(Player player, String serverName) {
        repositories.presence.heartbeat(player.getUniqueId(), serverName);
    }

    public int heartbeat(Collection<Heartbeat> players, Instant staleCutoff) {
        for (Heartbeat heartbeat : players) {
            UUID sessionId = sessions.get(heartbeat.playerId());
            if (sessionId == null) {
                sessionId = UUID.randomUUID();
                sessions.put(heartbeat.playerId(), sessionId);
                Instant now = Instant.now();
                repositories.presence.online(new PresenceRecord(
                        heartbeat.playerId(),
                        heartbeat.playerName(),
                        heartbeat.serverName(),
                        sessionId,
                        heartbeat.staff(),
                        now,
                        now));
            } else {
                repositories.presence.heartbeat(heartbeat.playerId(), heartbeat.serverName());
            }
            repositories.presence.setRank(heartbeat.playerId(), heartbeat.rankName());
        }
        return repositories.presence.cleanupStaleBefore(staleCutoff);
    }

    public void offline(Player player) {
        repositories.presence.offline(player.getUniqueId());
        sessions.remove(player.getUniqueId());
    }
}
