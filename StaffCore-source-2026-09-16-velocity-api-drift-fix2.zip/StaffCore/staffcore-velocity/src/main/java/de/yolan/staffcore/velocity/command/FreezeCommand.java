package de.yolan.staffcore.velocity.command;

import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.StatePayload;
import de.yolan.staffcore.common.util.InputPolicy;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.velocity.service.AuditService;
import de.yolan.staffcore.velocity.service.BridgeHub;
import de.yolan.staffcore.velocity.service.PlayerResolver;
import de.yolan.staffcore.velocity.service.RankService;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;

public final class FreezeCommand implements SimpleCommand {
    private final ProxyServer proxy;
    private final Repositories repos;
    private final PlayerResolver players;
    private final BridgeHub bridge;
    private final AuditService audit;
    private final RankService ranks;
    private final Executor executor;
    private final boolean unfreeze;

    public FreezeCommand(
            ProxyServer proxy,
            Repositories repos,
            PlayerResolver players,
            BridgeHub bridge,
            AuditService audit,
            RankService ranks,
            Executor executor,
            boolean unfreeze) {
        this.proxy = proxy;
        this.repos = repos;
        this.players = players;
        this.bridge = bridge;
        this.audit = audit;
        this.ranks = ranks;
        this.executor = executor;
        this.unfreeze = unfreeze;
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        return invocation.source().hasPermission(Permissions.FREEZE);
    }

    @Override
    public List<String> suggest(Invocation invocation) {
        if (invocation.arguments().length > 1) return List.of();
        String prefix = invocation.arguments().length == 0 ? "" : invocation.arguments()[0].toLowerCase(java.util.Locale.ROOT);
        return proxy.getAllPlayers().stream()
                .filter(target -> visibleSuggestion(invocation, target))
                .map(Player::getUsername)
                .filter(name -> name.toLowerCase(java.util.Locale.ROOT).startsWith(prefix))
                .limit(50)
                .toList();
    }

    @Override
    public void execute(Invocation invocation) {
        String[] args = invocation.arguments();
        if (args.length < 1) {
            invocation.source().sendMessage(Component.text(
                    "Nutzung: /" + (unfreeze ? "unfreeze" : "freeze") + " <spieler> " + (unfreeze ? "" : "[grund]")));
            return;
        }
        UUID actorId = invocation.source() instanceof Player player ? player.getUniqueId() : null;
        String actorName = invocation.source() instanceof Player player ? player.getUsername() : "CONSOLE";
        executor.execute(() -> run(invocation, args, actorId, actorName));
    }

    private void run(Invocation invocation, String[] args, UUID actorId, String actorName) {
        try {
            if (!invocation.source().hasPermission(Permissions.FREEZE)) {
                invocation.source().sendMessage(Component.text("Freeze-Permission ist nicht mehr vorhanden."));
                return;
            }
            Optional<UUID> id = players.uuid(args[0]);
            if (id.isEmpty()) {
                invocation.source().sendMessage(Component.text("Spieler unbekannt."));
                return;
            }
            UUID target = id.get();
            if (unfreeze) {
                var current = repos.freezes.find(target);
                if (current.isEmpty() || !current.get().active()) {
                    invocation.source().sendMessage(Component.text("Spieler ist nicht gefreezt."));
                    return;
                }
                if (!repos.freezes.unfreeze(target, current.get().revision())) {
                    invocation.source().sendMessage(Component.text("Freeze wurde parallel geändert; erneut versuchen."));
                    return;
                }
                audit.log(actorId, actorName, target, current.get().lastServer(), "UNFREEZE",
                        "{\"revision\":" + current.get().revision() + "}",
                        "{\"revision\":" + (current.get().revision() + 1) + "}");
                bridge.broadcast(MessageType.FREEZE_CHANGED, target, current.get().revision() + 1,
                        new StatePayload(target, false, false, false, null, false, current.get().lastServer()));
                invocation.source().sendMessage(Component.text("Freeze aufgehoben."));
                return;
            }

            String reason = args.length > 1
                    ? InputPolicy.bounded(String.join(" ", Arrays.copyOfRange(args, 1, args.length)), 512, "reason")
                    : "Staff-Prüfung";
            var result = repos.freezes.freezeIfInactive(target, actorId, reason);
            var frozen = result.record();
            if (!result.changed()) {
                invocation.source().sendMessage(Component.text("Spieler ist bereits gefreezt; bestehende Freeze-Session bleibt unverändert."));
                return;
            }
            audit.log(actorId, actorName, target, frozen.lastServer(), "FREEZE", null,
                    "{\"session\":\"" + frozen.sessionId() + "\",\"reason\":\"" + json(reason) + "\"}");
            bridge.broadcast(MessageType.FREEZE_CHANGED, target, frozen.revision(),
                    new StatePayload(target, false, false, true, reason, false, frozen.lastServer()));
            invocation.source().sendMessage(Component.text("Spieler gefreezt."));
        } catch (RuntimeException exception) {
            String message = exception.getMessage();
            invocation.source().sendMessage(Component.text("Freeze-Aktion fehlgeschlagen: "
                    + (message == null ? exception.getClass().getSimpleName() : message.substring(0, Math.min(180, message.length())))));
        }
    }

    private boolean visibleSuggestion(Invocation invocation, Player target) {
        if (!(invocation.source() instanceof Player viewer)) return true;
        var targetRank = ranks.rank(target);
        if (targetRank.isEmpty()) return true;
        var viewerRank = ranks.rank(viewer);
        return viewerRank.isPresent() && viewerRank.get().level() >= targetRank.get().level();
    }

    private static String json(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
}
