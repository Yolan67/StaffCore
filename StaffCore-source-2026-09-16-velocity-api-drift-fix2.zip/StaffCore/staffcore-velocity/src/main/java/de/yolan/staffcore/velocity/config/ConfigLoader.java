package de.yolan.staffcore.velocity.config;

import de.yolan.staffcore.common.util.DurationParser;
import de.yolan.staffcore.data.DatabaseConfig;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import org.yaml.snakeyaml.Yaml;

public final class ConfigLoader {
    private ConfigLoader() {}

    @SuppressWarnings("unchecked")
    public static VelocityConfig load(Path directory) throws IOException {
        Files.createDirectories(directory);
        Path file = directory.resolve("config.yml");
        if (Files.notExists(file)) {
            try (InputStream input = ConfigLoader.class.getResourceAsStream("/config.yml")) {
                if (input == null) throw new IOException("embedded config.yml missing");
                Files.copy(input, file);
            }
        }

        Map<String, Object> root;
        try (Reader reader = Files.newBufferedReader(file)) {
            root = new Yaml().load(reader);
        }
        if (root == null) throw new IllegalArgumentException("config.yml is empty");
        int version = integer(root, "config-version", 0);
        if (version != 1) throw new IllegalArgumentException("Unsupported config-version: " + version);

        Map<String, Object> database = map(root, "database");
        Map<String, Object> bridge = map(root, "bridge");
        Map<String, Object> messages = map(root, "messages");
        Map<String, Object> staffMode = map(root, "staffmode");
        Map<String, Object> vanish = map(root, "vanish");
        Map<String, Object> freeze = map(root, "freeze");
        Map<String, Object> punishments = map(root, "punishments");
        Map<String, Object> tickets = map(root, "tickets");
        Map<String, Object> priority = map(root, "priority");
        Map<String, Object> routing = map(root, "routing");
        Map<String, Object> notifications = map(root, "notifications");
        Map<String, Object> privacy = map(root, "privacy");
        Map<String, Object> logging = map(root, "logging");
        Map<String, Object> integrations = map(root, "integrations");
        Map<String, Object> maintenance = map(integrations, "maintenancecore");
        Map<String, Object> runtime = map(root, "runtime");
        Map<String, Object> recovery = map(root, "recovery");

        requireValue(staffMode, "authority", "velocity");
        requireValue(vanish, "authority", "velocity");
        requireValue(punishments, "authority", "velocity");
        requireValue(tickets, "authority", "database");
        requireValue(priority, "authority", "paper-create-and-persisted-explanation");

        String password = envOr(str(database, "password", ""), "STAFFCORE_DB_PASSWORD");
        String secret = envOr(str(bridge, "secret", ""), "STAFFCORE_BRIDGE_SECRET");
        DatabaseConfig db = new DatabaseConfig(
                str(database, "jdbc-url", null),
                str(database, "username", null),
                password,
                integer(database, "pool-size", 8),
                integer(database, "connection-timeout-ms", 5000));

        Map<String, Integer> capacity = new LinkedHashMap<>(Map.of(
                "jr_mod", 5,
                "mod", 8,
                "sr_mod", 10,
                "admin", 12,
                "owner", 20));
        for (Map.Entry<String, Object> entry : map(routing, "max-active-tickets").entrySet()) {
            int value = Integer.parseInt(String.valueOf(entry.getValue()));
            if (value < 1 || value > 1000) throw new IllegalArgumentException("invalid routing capacity: " + entry.getKey());
            capacity.put(entry.getKey().toLowerCase(Locale.ROOT), value);
        }

        return new VelocityConfig(
                version,
                db,
                secret,
                str(root, "proxy-instance", "proxy-1"),
                str(messages, "locale", "de_DE"),
                duration(freeze, "leave-tempban", "5m"),
                str(punishments, "global-ban-requires", "staffcore.punishment.globalban"),
                capacity,
                bool(notifications, "persistent-inbox", true),
                bool(privacy, "store-player-ip", false),
                bool(logging, "audit-critical-actions", true),
                bool(maintenance, "required", false),
                duration(runtime, "routing-interval", "10s"),
                duration(runtime, "health-interval", "15s"),
                duration(runtime, "punishment-expiry-interval", "30s"),
                duration(runtime, "presence-heartbeat-interval", "15s"),
                duration(runtime, "presence-stale-after", "90s"),
                bool(runtime, "degraded-mode", true),
                bool(recovery, "fail-closed-for-critical-mutations", true));
    }

    private static boolean bool(Map<String, Object> source, String key, boolean fallback) {
        Object value = source == null ? null : source.get(key);
        return value == null ? fallback : Boolean.parseBoolean(String.valueOf(value));
    }

    private static void requireValue(Map<String, Object> source, String key, String expected) {
        String actual = str(source, key, expected);
        if (!expected.equalsIgnoreCase(actual)) {
            throw new IllegalArgumentException(key + " must be '" + expected + "' but was '" + actual + "'");
        }
    }

    private static Duration duration(Map<String, Object> source, String key, String fallback) {
        return DurationParser.parse(str(source, key, fallback))
                .orElseThrow(() -> new IllegalArgumentException(key + " cannot be permanent"));
    }

    private static String envOr(String configured, String environmentName) {
        String value = System.getenv(environmentName);
        return value != null && !value.isBlank() ? value : configured;
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Map<String, Object> source, String key) {
        Object value = source == null ? null : source.get(key);
        return value instanceof Map<?, ?> raw ? (Map<String, Object>) raw : new LinkedHashMap<>();
    }

    private static String str(Map<String, Object> source, String key, String fallback) {
        Object value = source == null ? null : source.get(key);
        return value == null ? fallback : String.valueOf(value);
    }

    private static int integer(Map<String, Object> source, String key, int fallback) {
        Object value = source == null ? null : source.get(key);
        return value == null ? fallback : Integer.parseInt(String.valueOf(value));
    }
}
