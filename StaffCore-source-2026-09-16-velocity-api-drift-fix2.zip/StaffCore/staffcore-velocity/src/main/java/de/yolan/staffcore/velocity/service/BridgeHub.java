package de.yolan.staffcore.velocity.service;

import com.velocitypowered.api.proxy.ProxyServer;import com.velocitypowered.api.proxy.messages.MinecraftChannelIdentifier;
import de.yolan.staffcore.common.protocol.*;import de.yolan.staffcore.data.Repositories;
import java.util.*;

public final class BridgeHub {
    public static final MinecraftChannelIdentifier CHANNEL=MinecraftChannelIdentifier.from(ProtocolConstants.CHANNEL);
    private final ProxyServer proxy;private final ProtocolCodec codec;private final Repositories repos;private final String nodeId;
    public BridgeHub(ProxyServer proxy,String secret,Repositories repos,String nodeId){this.proxy=proxy;this.codec=new ProtocolCodec(secret);this.repos=repos;this.nodeId=nodeId;}
    public ProtocolEnvelope decode(byte[] data){return codec.decodeAndVerify(data);}
    public boolean markNew(UUID id){return repos.processedMessages.markIfNew(nodeId,id);}
    public void broadcast(MessageType type,UUID subject,long revision,Object payload){byte[] data=codec.encode(type,subject,revision,payload);proxy.getAllServers().forEach(s->s.sendPluginMessage(CHANNEL,data));}
    public void broadcastRaw(byte[] data,String exceptServer){proxy.getAllServers().forEach(s->{if(exceptServer==null||!s.getServerInfo().getName().equalsIgnoreCase(exceptServer))s.sendPluginMessage(CHANNEL,data);});}
    public ProtocolCodec codec(){return codec;}
}
