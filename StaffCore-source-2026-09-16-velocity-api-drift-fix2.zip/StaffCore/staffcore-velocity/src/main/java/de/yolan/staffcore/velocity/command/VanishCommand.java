package de.yolan.staffcore.velocity.command;

import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.StatePayload;
import de.yolan.staffcore.velocity.service.AuditService;
import de.yolan.staffcore.velocity.service.BridgeHub;
import de.yolan.staffcore.velocity.service.GlobalStateService;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;

public final class VanishCommand implements SimpleCommand {
    private final GlobalStateService states;
    private final BridgeHub bridge;
    private final AuditService audit;
    private final Executor executor;

    public VanishCommand(GlobalStateService states, BridgeHub bridge, AuditService audit, Executor executor) {
        this.states = states;
        this.bridge = bridge;
        this.audit = audit;
        this.executor = executor;
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        return invocation.source().hasPermission(Permissions.VANISH);
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player player)) {
            invocation.source().sendMessage(Component.text("Nur Spieler."));
            return;
        }
        if (!player.hasPermission(Permissions.VANISH)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }

        String server = player.getCurrentServer()
                .map(connection -> connection.getServerInfo().getName())
                .orElse(null);
        executor.execute(() -> toggle(player, server));
    }

    private void toggle(Player player, String server) {
        if (!player.hasPermission(Permissions.VANISH)) {
            player.sendMessage(Component.text("Vanish-Permission ist nicht mehr vorhanden."));
            return;
        }

        for (int attempt = 0; attempt < 3; attempt++) {
            var before = states.state(player.getUniqueId());
            boolean desired = !before.vanished();
            var changed = states.setVanish(player.getUniqueId(), desired, before.revision());
            if (changed.isEmpty()) continue;

            var after = changed.get();
            audit.log(
                    player.getUniqueId(),
                    player.getUsername(),
                    player.getUniqueId(),
                    server,
                    "VANISH_TOGGLE",
                    "{\"vanished\":" + before.vanished() + ",\"revision\":" + before.revision() + "}",
                    "{\"vanished\":" + after.vanished() + ",\"revision\":" + after.revision() + "}");

            bridge.broadcast(
                    MessageType.VANISH_CHANGED,
                    player.getUniqueId(),
                    after.revision(),
                    new StatePayload(
                            player.getUniqueId(),
                            after.vanished(),
                            after.staffChat(),
                            false,
                            null,
                            false,
                            server));
            player.sendMessage(Component.text("Vanish: " + (after.vanished() ? "AN" : "AUS")));
            return;
        }
        player.sendMessage(Component.text("Vanish konnte wegen paralleler Änderung nicht umgeschaltet werden."));
    }
}
