package de.yolan.staffcore.velocity.service;

import com.velocitypowered.api.proxy.Player;
import de.yolan.staffcore.common.permission.StaffHierarchy;
import de.yolan.staffcore.common.permission.StaffRank;
import java.util.Optional;

public final class RankService {
    private final StaffHierarchy hierarchy = new StaffHierarchy();

    public Optional<StaffRank> rank(Player player) {
        return hierarchy.rankOf(player::hasPermission);
    }

    public boolean staff(Player player) {
        return rank(player).isPresent();
    }

    public boolean canSee(Player viewer, Player target) {
        return hierarchy.canSeeVanished(rank(viewer), rank(target));
    }
}
