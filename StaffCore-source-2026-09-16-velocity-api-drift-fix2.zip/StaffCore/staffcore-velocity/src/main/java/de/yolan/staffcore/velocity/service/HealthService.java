package de.yolan.staffcore.velocity.service;
import de.yolan.staffcore.data.DatabaseManager;import java.util.concurrent.atomic.AtomicBoolean;
public final class HealthService{private final DatabaseManager db;private final AtomicBoolean degraded=new AtomicBoolean();public HealthService(DatabaseManager db){this.db=db;}public void probe(){degraded.set(!db.checkHealth());}public boolean degraded(){return degraded.get();}}
