package de.yolan.staffcore.velocity.service;

import de.yolan.staffcore.common.model.Punishment;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.punishment.PunishmentScope;
import de.yolan.staffcore.common.punishment.PunishmentStatus;
import de.yolan.staffcore.common.punishment.PunishmentType;
import de.yolan.staffcore.common.util.InputPolicy;
import de.yolan.staffcore.data.Repositories;

import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class PunishmentService {
    private final Repositories repos;
    private final BridgeHub bridge;

    public PunishmentService(Repositories repos, BridgeHub bridge) {
        this.repos = repos;
        this.bridge = bridge;
    }

    public List<Punishment> active(UUID target) {
        return repos.punishments.activeFor(target, Instant.now());
    }

    public Optional<Punishment> globalBan(UUID target) {
        return active(target).stream()
                .filter(punishment -> punishment.type().isBan()
                        && punishment.scope() == PunishmentScope.NETWORK)
                .findFirst();
    }

    public Optional<Punishment> serverBan(UUID target, String server) {
        return active(target).stream()
                .filter(punishment -> punishment.type().isBan()
                        && punishment.scope() == PunishmentScope.SERVER
                        && punishment.appliesToServer(server))
                .findFirst();
    }

    public boolean muted(UUID target) {
        return active(target).stream().anyMatch(punishment -> punishment.type().isMute());
    }

    public Punishment create(
            UUID target,
            UUID actor,
            String actorName,
            PunishmentType type,
            PunishmentScope scope,
            String server,
            String reason,
            String description,
            Optional<Duration> duration,
            String idempotencyKey
    ) {
        Instant now = Instant.now();
        Punishment punishment = new Punishment(
                UUID.randomUUID(),
                target,
                actor,
                actorName,
                type,
                scope,
                server,
                InputPolicy.bounded(reason, 256, "reason"),
                description == null ? null : InputPolicy.bounded(description, 2048, "description"),
                now,
                type == PunishmentType.KICK ? now : duration.map(now::plus).orElse(null),
                PunishmentStatus.ACTIVE,
                idempotencyKey,
                false
        );

        punishment = repos.punishments.createIdempotent(punishment);
        bridge.broadcast(MessageType.PUNISHMENT_CHANGED, target, 0, punishment);
        return punishment;
    }

    public boolean revoke(UUID punishmentId, UUID actor, String reason) {
        boolean revoked = repos.punishments.revoke(
                punishmentId,
                actor,
                InputPolicy.bounded(reason == null ? "manual revoke" : reason, 512, "revoke reason")
        );
        if (revoked) {
            bridge.broadcast(
                    MessageType.PUNISHMENT_CHANGED,
                    null,
                    0,
                    Map.of("id", punishmentId.toString(), "status", "REVOKED")
            );
        }
        return revoked;
    }
}
