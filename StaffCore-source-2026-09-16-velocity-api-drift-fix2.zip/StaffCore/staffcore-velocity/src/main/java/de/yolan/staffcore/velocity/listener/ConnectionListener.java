package de.yolan.staffcore.velocity.listener;

import com.velocitypowered.api.event.EventTask;
import com.velocitypowered.api.event.ResultedEvent;
import com.velocitypowered.api.event.Subscribe;
import com.velocitypowered.api.event.connection.DisconnectEvent;
import com.velocitypowered.api.event.connection.LoginEvent;
import com.velocitypowered.api.event.connection.PostLoginEvent;
import com.velocitypowered.api.event.player.ServerPostConnectEvent;
import com.velocitypowered.api.event.player.ServerPreConnectEvent;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import de.yolan.staffcore.common.model.Notification;
import de.yolan.staffcore.common.model.Punishment;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.util.DurationParser;
import de.yolan.staffcore.data.ModerationTransactions;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.velocity.config.VelocityConfig;
import de.yolan.staffcore.velocity.service.AuditService;
import de.yolan.staffcore.velocity.service.PresenceService;
import de.yolan.staffcore.velocity.service.PunishmentService;
import de.yolan.staffcore.velocity.service.SpectateCoordinator;
import java.time.Duration;
import java.time.Instant;
import java.util.UUID;
import net.kyori.adventure.text.Component;

public final class ConnectionListener {
    private final ProxyServer proxy;
    private final Repositories repos;
    private final PunishmentService punishments;
    private final PresenceService presence;
    private final ModerationTransactions transactions;
    private final VelocityConfig config;
    private final SpectateCoordinator spectate;
    private final AuditService audit;

    public ConnectionListener(
            ProxyServer proxy,
            Repositories repos,
            PunishmentService punishments,
            PresenceService presence,
            ModerationTransactions transactions,
            VelocityConfig config,
            SpectateCoordinator spectate,
            AuditService audit) {
        this.proxy = proxy;
        this.repos = repos;
        this.punishments = punishments;
        this.presence = presence;
        this.transactions = transactions;
        this.config = config;
        this.spectate = spectate;
        this.audit = audit;
    }

    @Subscribe
    public EventTask onLogin(LoginEvent event) {
        return EventTask.async(() -> {
            Player player = event.getPlayer();
            repos.players.upsert(player.getUniqueId(), player.getUsername());
            punishments.globalBan(player.getUniqueId())
                    .ifPresent(ban -> event.setResult(ResultedEvent.ComponentResult.denied(banMessage(ban))));
        });
    }

    @Subscribe
    public EventTask onPreConnect(ServerPreConnectEvent event) {
        return EventTask.async(() -> {
            String target = event.getOriginalServer().getServerInfo().getName();
            punishments.serverBan(event.getPlayer().getUniqueId(), target).ifPresent(ban -> {
                event.setResult(ServerPreConnectEvent.ServerResult.denied());
                event.getPlayer().sendMessage(Component.text(
                        "Du bist auf " + target + " gesperrt. Grund: " + ban.reason()));
            });
        });
    }

    @Subscribe
    public EventTask onPostLogin(PostLoginEvent event) {
        return EventTask.async(() -> presence.online(event.getPlayer(), null));
    }

    @Subscribe
    public EventTask onServer(ServerPostConnectEvent event) {
        return EventTask.async(() -> event.getPlayer().getCurrentServer().ifPresent(server -> {
            presence.server(event.getPlayer(), server.getServerInfo().getName());
            spectate.targetMoved(event.getPlayer());
        }));
    }

    @Subscribe
    public EventTask onDisconnect(DisconnectEvent event) {
        return EventTask.async(() -> {
            Player player = event.getPlayer();
            try {
                spectate.targetDisconnected(player.getUniqueId());
                repos.freezes.find(player.getUniqueId()).filter(freeze -> freeze.active()).ifPresent(freeze -> {
                    boolean created = transactions.freezeLeave(
                            player.getUniqueId(),
                            freeze.sessionId(),
                            freeze.lastServer(),
                            freeze.lastWorld(),
                            freeze.x(),
                            freeze.y(),
                            freeze.z(),
                            config.freezeLeaveTempban());
                    if (created) notifyFreezeLeave(player, freeze.lastServer(), freeze.sessionId());
                });
            } finally {
                presence.offline(player);
            }
        });
    }

    private void notifyFreezeLeave(Player target, String server, UUID freezeSession) {
        audit.log(null, "StaffCore System", target.getUniqueId(), server, "FREEZE_LEAVE", null,
                "{\"freezeSession\":\"" + freezeSession + "\",\"tempbanSeconds\":"
                        + config.freezeLeaveTempban().toSeconds() + "}");
        String body = target.getUsername() + " hat das Netzwerk während eines aktiven Freeze verlassen. "
                + "System-Tempban: " + DurationParser.format(config.freezeLeaveTempban()) + ". Freeze bleibt aktiv.";
        String dedupe = "freeze-leave:" + freezeSession;
        Instant now = Instant.now();
        for (Player staff : proxy.getAllPlayers()) {
            if (!staff.hasPermission(Permissions.FREEZE)) continue;
            staff.sendMessage(Component.text("[StaffCore] " + body));
            repos.notifications.create(new Notification(
                    UUID.randomUUID(), staff.getUniqueId(), "FREEZE_LEAVE", "Freeze-Leave", body, dedupe,
                    false, now, null));
        }
    }

    private Component banMessage(Punishment punishment) {
        String until = punishment.expiresAt() == null
                ? "permanent"
                : DurationParser.format(Duration.between(Instant.now(), punishment.expiresAt()));
        return Component.text("Global gebannt | Grund: " + punishment.reason() + " | Restzeit: " + until
                + " | ID: " + punishment.id());
    }
}
