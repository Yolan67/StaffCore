package de.yolan.staffcore.velocity.command;

import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.velocity.service.RankService;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;

public final class StaffListCommand implements SimpleCommand {
    private final ProxyServer proxy;
    private final RankService ranks;
    private final Repositories repositories;
    private final Executor executor;

    public StaffListCommand(ProxyServer proxy, RankService ranks, Repositories repositories, Executor executor) {
        this.proxy = proxy;
        this.ranks = ranks;
        this.repositories = repositories;
        this.executor = executor;
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        return invocation.source().hasPermission(Permissions.STAFFLIST);
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player viewer)) {
            invocation.source().sendMessage(Component.text(
                    "Staff online: " + proxy.getAllPlayers().stream()
                            .filter(ranks::staff)
                            .map(Player::getUsername)
                            .sorted()
                            .toList()));
            return;
        }
        executor.execute(() -> render(viewer));
    }

    private void render(Player viewer) {
        if (!viewer.hasPermission(Permissions.STAFFLIST)) {
            viewer.sendMessage(Component.text("StaffList-Permission ist nicht mehr vorhanden."));
            return;
        }
        var viewerRank = ranks.rank(viewer);
        if (viewerRank.isEmpty()) {
            viewer.sendMessage(Component.text("Kein Staff-Rang erkannt."));
            return;
        }

        List<String> output = new ArrayList<>();
        for (Player target : proxy.getAllPlayers()) {
            var targetRank = ranks.rank(target);
            if (targetRank.isEmpty() || targetRank.get().level() > viewerRank.get().level()) continue;
            boolean vanished = repositories.staffStates.find(target.getUniqueId())
                    .map(state -> state.vanished())
                    .orElse(false);
            if (vanished && !ranks.canSee(viewer, target)) continue;
            String server = target.getCurrentServer()
                    .map(connection -> connection.getServerInfo().getName())
                    .orElse("-");
            output.add(targetRank.get().displayName() + " " + target.getUsername() + " [" + server + "]");
        }
        viewer.sendMessage(Component.text(output.isEmpty()
                ? "Keine sichtbaren Staff online."
                : String.join(" | ", output)));
    }
}
