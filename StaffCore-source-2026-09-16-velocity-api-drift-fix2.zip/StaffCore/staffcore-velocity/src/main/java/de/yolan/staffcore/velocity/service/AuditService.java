package de.yolan.staffcore.velocity.service;

import de.yolan.staffcore.common.model.AuditEvent;
import de.yolan.staffcore.data.Repositories;
import java.time.Instant;
import java.util.UUID;

public final class AuditService {
    private final Repositories repos;
    public AuditService(Repositories repos){this.repos=repos;}
    public UUID log(UUID actor,String actorName,UUID target,String server,String action,String before,String after){
        UUID correlation=UUID.randomUUID();
        repos.audit.append(new AuditEvent(UUID.randomUUID(),correlation,actor,actorName,target,server,action,before,after,Instant.now()));
        if(actor!=null) repos.activity.append(actor,action,correlation.toString());
        return correlation;
    }
}
