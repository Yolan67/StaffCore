package de.yolan.staffcore.velocity;

import com.velocitypowered.api.proxy.Player;
import com.velocitypowered.api.proxy.ProxyServer;
import com.velocitypowered.api.scheduler.ScheduledTask;
import de.yolan.staffcore.data.DatabaseManager;
import de.yolan.staffcore.data.ModerationTransactions;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.velocity.config.ConfigLoader;
import de.yolan.staffcore.velocity.config.VelocityConfig;
import de.yolan.staffcore.velocity.service.AuditService;
import de.yolan.staffcore.velocity.service.BridgeHub;
import de.yolan.staffcore.velocity.service.FreezeRequestService;
import de.yolan.staffcore.velocity.service.GlobalStateService;
import de.yolan.staffcore.velocity.service.HealthService;
import de.yolan.staffcore.velocity.service.PlayerResolver;
import de.yolan.staffcore.velocity.service.PresenceService;
import de.yolan.staffcore.velocity.service.PunishmentRequestService;
import de.yolan.staffcore.velocity.service.PunishmentService;
import de.yolan.staffcore.velocity.service.RankService;
import de.yolan.staffcore.velocity.service.SpectateCoordinator;
import de.yolan.staffcore.velocity.service.StaffChatService;
import de.yolan.staffcore.velocity.service.TicketRoutingService;
import java.nio.file.Path;
import java.time.Instant;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import org.slf4j.Logger;

public final class VelocityRuntime implements AutoCloseable {
    public final VelocityConfig config;
    public final DatabaseManager db;
    public final Repositories repos;
    public final ModerationTransactions moderation;
    public final ExecutorService io;
    public final RankService ranks;
    public final GlobalStateService states;
    public final BridgeHub bridge;
    public final PunishmentService punishments;
    public final PunishmentRequestService punishmentRequests;
    public final FreezeRequestService freezeRequests;
    public final PresenceService presence;
    public final StaffChatService staffChat;
    public final PlayerResolver players;
    public final AuditService audit;
    public final TicketRoutingService routing;
    public final SpectateCoordinator spectate;
    public final HealthService health;

    private final ProxyServer proxy;
    private final Object plugin;
    private final Logger logger;
    private ScheduledTask routingTask;
    private ScheduledTask healthTask;
    private ScheduledTask expiryTask;
    private ScheduledTask presenceTask;

    public VelocityRuntime(ProxyServer proxy, Object plugin, Logger logger, Path directory) throws Exception {
        this.proxy = proxy;
        this.plugin = plugin;
        this.logger = logger;
        config = ConfigLoader.load(directory);
        db = new DatabaseManager(config.database());
        repos = new Repositories(db);
        moderation = new ModerationTransactions(db, repos.punishments);
        io = Executors.newVirtualThreadPerTaskExecutor();
        ranks = new RankService();
        states = new GlobalStateService(repos);
        bridge = new BridgeHub(proxy, config.bridgeSecret(), repos, "velocity:" + config.proxyInstance());
        punishments = new PunishmentService(repos, bridge);
        presence = new PresenceService(repos, ranks);
        staffChat = new StaffChatService(proxy, ranks);
        players = new PlayerResolver(proxy, repos);
        audit = new AuditService(repos);
        punishmentRequests = new PunishmentRequestService(proxy, repos, punishments, audit, bridge);
        freezeRequests = new FreezeRequestService(proxy, repos, bridge, audit);
        routing = new TicketRoutingService(proxy, repos, ranks, config.ticketCapacity());
        spectate = new SpectateCoordinator(proxy, repos, bridge);
        health = new HealthService(db);
    }

    public void startTasks() {
        routingTask = proxy.getScheduler().buildTask(plugin, () -> io.execute(routing::route))
                .repeat(config.routingInterval().toMillis(), TimeUnit.MILLISECONDS).schedule();
        healthTask = proxy.getScheduler().buildTask(plugin, () -> io.execute(health::probe))
                .repeat(config.healthInterval().toMillis(), TimeUnit.MILLISECONDS).schedule();
        expiryTask = proxy.getScheduler().buildTask(plugin,
                        () -> io.execute(() -> repos.punishments.expireDue(Instant.now())))
                .repeat(config.punishmentExpiryInterval().toMillis(), TimeUnit.MILLISECONDS).schedule();
        presenceTask = proxy.getScheduler().buildTask(plugin, this::schedulePresenceHeartbeat)
                .repeat(config.presenceHeartbeatInterval().toMillis(), TimeUnit.MILLISECONDS).schedule();
    }

    private void schedulePresenceHeartbeat() {
        List<PresenceService.Heartbeat> snapshot = proxy.getAllPlayers().stream()
                .map(this::presenceSnapshot)
                .toList();
        Instant staleCutoff = Instant.now().minus(config.presenceStaleAfter());
        io.execute(() -> {
            try {
                int removed = presence.heartbeat(snapshot, staleCutoff);
                if (removed > 0) {
                    logger.warn("StaffCore cleaned {} stale presence session(s) older than {}", removed, staleCutoff);
                }
            } catch (RuntimeException exception) {
                logger.error("StaffCore presence heartbeat/stale cleanup failed", exception);
            }
        });
    }

    private PresenceService.Heartbeat presenceSnapshot(Player player) {
        String server = player.getCurrentServer()
                .map(connection -> connection.getServerInfo().getName())
                .orElse(null);
        return new PresenceService.Heartbeat(
                player.getUniqueId(),
                player.getUsername(),
                server,
                ranks.staff(player),
                ranks.rank(player).map(Enum::name).orElse(null));
    }

    @Override
    public void close() {
        if (routingTask != null) routingTask.cancel();
        if (healthTask != null) healthTask.cancel();
        if (expiryTask != null) expiryTask.cancel();
        if (presenceTask != null) presenceTask.cancel();
        io.shutdown();
        try {
            io.awaitTermination(5, TimeUnit.SECONDS);
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
        }
        db.close();
    }
}
