package de.yolan.staffcore.velocity.command;

import com.velocitypowered.api.command.SimpleCommand;
import com.velocitypowered.api.proxy.Player;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.StatePayload;
import de.yolan.staffcore.velocity.service.AuditService;
import de.yolan.staffcore.velocity.service.BridgeHub;
import de.yolan.staffcore.velocity.service.GlobalStateService;
import de.yolan.staffcore.velocity.service.StaffChatService;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;

public final class ScCommand implements SimpleCommand {
    private final GlobalStateService states;
    private final StaffChatService chat;
    private final BridgeHub bridge;
    private final AuditService audit;
    private final Executor executor;

    public ScCommand(
            GlobalStateService states,
            StaffChatService chat,
            BridgeHub bridge,
            AuditService audit,
            Executor executor) {
        this.states = states;
        this.chat = chat;
        this.bridge = bridge;
        this.audit = audit;
        this.executor = executor;
    }

    @Override
    public boolean hasPermission(Invocation invocation) {
        return invocation.source().hasPermission(Permissions.STAFFCHAT_USE);
    }

    @Override
    public void execute(Invocation invocation) {
        if (!(invocation.source() instanceof Player player)) {
            invocation.source().sendMessage(Component.text("Nur Spieler."));
            return;
        }
        if (!player.hasPermission(Permissions.STAFFCHAT_USE)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }

        String server = player.getCurrentServer()
                .map(connection -> connection.getServerInfo().getName())
                .orElse("proxy");
        String[] arguments = invocation.arguments();
        if (arguments.length > 0) {
            String message = String.join(" ", arguments);
            chat.send(player, message);
            executor.execute(() -> audit.log(
                    player.getUniqueId(),
                    player.getUsername(),
                    null,
                    server,
                    "STAFFCHAT_MESSAGE",
                    null,
                    "{\"length\":" + message.length() + "}"));
            return;
        }

        executor.execute(() -> toggle(player, server));
    }

    private void toggle(Player player, String server) {
        if (!player.hasPermission(Permissions.STAFFCHAT_USE)) {
            player.sendMessage(Component.text("StaffChat-Permission ist nicht mehr vorhanden."));
            return;
        }

        for (int attempt = 0; attempt < 3; attempt++) {
            var before = states.state(player.getUniqueId());
            boolean desired = !before.staffChat();
            var changed = states.setStaffChat(player.getUniqueId(), desired, before.revision());
            if (changed.isEmpty()) continue;

            var after = changed.get();
            audit.log(
                    player.getUniqueId(),
                    player.getUsername(),
                    player.getUniqueId(),
                    server,
                    "STAFFCHAT_TOGGLE",
                    "{\"enabled\":" + before.staffChat() + ",\"revision\":" + before.revision() + "}",
                    "{\"enabled\":" + after.staffChat() + ",\"revision\":" + after.revision() + "}");

            bridge.broadcast(
                    MessageType.STAFFCHAT_CHANGED,
                    player.getUniqueId(),
                    after.revision(),
                    new StatePayload(
                            player.getUniqueId(),
                            after.vanished(),
                            after.staffChat(),
                            false,
                            null,
                            false,
                            server));
            player.sendMessage(Component.text("StaffChat: " + (after.staffChat() ? "AN" : "AUS")));
            return;
        }
        player.sendMessage(Component.text("StaffChat konnte wegen paralleler Änderung nicht umgeschaltet werden."));
    }
}
