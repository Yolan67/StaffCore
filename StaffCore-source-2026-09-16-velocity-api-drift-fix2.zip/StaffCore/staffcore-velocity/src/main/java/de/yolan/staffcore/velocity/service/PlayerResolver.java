package de.yolan.staffcore.velocity.service;
import com.velocitypowered.api.proxy.ProxyServer;import de.yolan.staffcore.data.Repositories;import java.util.*;
public final class PlayerResolver{private final ProxyServer proxy;private final Repositories repos;public PlayerResolver(ProxyServer proxy,Repositories repos){this.proxy=proxy;this.repos=repos;}public Optional<UUID> uuid(String name){return proxy.getPlayer(name).map(x->x.getUniqueId()).or(()->repos.players.findUuidByName(name));}}
