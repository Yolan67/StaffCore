package de.yolan.staffcore.paper.command;

import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.paper.service.PaperRankService;
import de.yolan.staffcore.paper.service.ServerStateCache;
import de.yolan.staffcore.paper.service.SpectateService;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class SpectateCommand implements CommandExecutor, TabCompleter {
    private final JavaPlugin plugin;
    private final Repositories repos;
    private final Executor io;
    private final SpectateService service;
    private final PaperRankService ranks;
    private final ServerStateCache cache;

    public SpectateCommand(JavaPlugin plugin, Repositories repos, Executor io, SpectateService service,
                           PaperRankService ranks, ServerStateCache cache) {
        this.plugin = plugin;
        this.repos = repos;
        this.io = io;
        this.service = service;
        this.ranks = ranks;
        this.cache = cache;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur Spieler.");
            return true;
        }
        if (args.length == 1 && args[0].equalsIgnoreCase("stop")) {
            if (!player.hasPermission(Permissions.SPECTATE) && !player.hasPermission(Permissions.SPECTATE_SUPER)) {
                player.sendMessage(Component.text("Keine Berechtigung."));
                return true;
            }
            service.stop(player);
            return true;
        }
        boolean superMode = args.length == 2 && args[0].equalsIgnoreCase("super");
        String name = superMode ? args[1] : (args.length == 1 ? args[0] : null);
        if (name == null) {
            player.sendMessage(Component.text("/spectate <spieler> | /spectate super <spieler> | /spectate stop"));
            return true;
        }
        String required = superMode ? Permissions.SPECTATE_SUPER : Permissions.SPECTATE;
        if (!player.hasPermission(required)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return true;
        }
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            if (!visibleTo(player, online)) {
                player.sendMessage(Component.text("Spieler nicht gefunden."));
                return true;
            }
            service.start(player, online.getUniqueId(), superMode);
            return true;
        }
        io.execute(() -> {
            Optional<UUID> id = repos.players.findUuidByName(name);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id.isEmpty()) player.sendMessage(Component.text("Spieler nicht gefunden."));
                else service.start(player, id.get(), superMode);
            });
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player viewer)) return List.of();
        if (args.length == 1) {
            List<String> values = new ArrayList<>();
            if (viewer.hasPermission(Permissions.SPECTATE) || viewer.hasPermission(Permissions.SPECTATE_SUPER)) values.add("stop");
            if (viewer.hasPermission(Permissions.SPECTATE_SUPER)) values.add("super");
            if (viewer.hasPermission(Permissions.SPECTATE)) {
                Bukkit.getOnlinePlayers().stream().filter(target -> visibleTo(viewer, target))
                        .map(Player::getName).forEach(values::add);
            }
            String query = args[0].toLowerCase(Locale.ROOT);
            return values.stream().filter(value -> value.toLowerCase(Locale.ROOT).startsWith(query)).limit(30).toList();
        }
        if (args.length == 2 && args[0].equalsIgnoreCase("super") && viewer.hasPermission(Permissions.SPECTATE_SUPER)) {
            String query = args[1].toLowerCase(Locale.ROOT);
            return Bukkit.getOnlinePlayers().stream().filter(target -> visibleTo(viewer, target))
                    .map(Player::getName).filter(value -> value.toLowerCase(Locale.ROOT).startsWith(query))
                    .limit(30).toList();
        }
        return List.of();
    }

    private boolean visibleTo(Player viewer, Player target) {
        boolean vanished = cache.staff(target.getUniqueId()).map(StaffPersistentState::vanished).orElse(false);
        return !vanished || ranks.canSeeVanished(viewer, target);
    }
}
