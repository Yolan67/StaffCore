package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.model.AuditEvent;
import de.yolan.staffcore.data.Repositories;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class PaperAuditService {
    private final JavaPlugin plugin;
    private final Repositories repositories;
    private final Executor io;
    private final int maxPayloadChars;

    public PaperAuditService(JavaPlugin plugin, Repositories repositories, Executor io, int maxPayloadChars) {
        this.plugin = plugin;
        this.repositories = repositories;
        this.io = io;
        this.maxPayloadChars = maxPayloadChars;
    }

    public UUID append(UUID actor, String actorName, UUID target, String server, String type, String before, String after) {
        UUID correlation = UUID.randomUUID();
        AuditEvent event = new AuditEvent(
                UUID.randomUUID(), correlation, actor, bounded(actorName), target, bounded(server), bounded(type),
                bounded(before), bounded(after), Instant.now());
        Runnable write = () -> {
            try {
                repositories.audit.append(event);
                if (actor != null) repositories.activity.append(actor, type, correlation.toString());
            } catch (RuntimeException exception) {
                plugin.getLogger().severe("CRITICAL: StaffCore audit write failed for " + type
                        + " correlation=" + correlation + ": " + safe(exception));
            }
        };
        if (Bukkit.isPrimaryThread()) io.execute(write);
        else write.run();
        return correlation;
    }

    private String bounded(String value) {
        if (value == null || value.length() <= maxPayloadChars) return value;
        return value.substring(0, maxPayloadChars);
    }

    private static String safe(Throwable throwable) {
        Throwable root = throwable;
        while (root.getCause() != null) root = root.getCause();
        String message = root.getMessage();
        if (message == null || message.isBlank()) return root.getClass().getSimpleName();
        return message.substring(0, Math.min(message.length(), 240));
    }
}
