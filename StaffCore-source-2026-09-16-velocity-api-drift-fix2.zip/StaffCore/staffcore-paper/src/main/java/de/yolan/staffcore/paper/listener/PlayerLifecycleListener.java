package de.yolan.staffcore.paper.listener;

import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.StateRequestPayload;
import de.yolan.staffcore.paper.service.BridgeClient;
import de.yolan.staffcore.paper.service.ServerStateCache;
import de.yolan.staffcore.paper.service.StaffModeService;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class PlayerLifecycleListener implements Listener {
    private final JavaPlugin plugin;
    private final BridgeClient bridge;
    private final StaffModeService staffMode;
    private final ServerStateCache cache;

    public PlayerLifecycleListener(
            JavaPlugin plugin,
            BridgeClient bridge,
            StaffModeService staffMode,
            ServerStateCache cache) {
        this.plugin = plugin;
        this.bridge = bridge;
        this.staffMode = staffMode;
        this.cache = cache;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void join(PlayerJoinEvent event) {
        bridge.flush(event.getPlayer());
        bridge.send(
                MessageType.STATE_RESYNC_REQUEST,
                event.getPlayer().getUniqueId(),
                0,
                new StateRequestPayload(event.getPlayer().getUniqueId(), bridge.serverName()));
        staffMode.onJoin(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void quit(PlayerQuitEvent event) {
        staffMode.onQuit(event.getPlayer());
        var playerId = event.getPlayer().getUniqueId();
        Bukkit.getScheduler().runTaskLaterAsynchronously(plugin, () -> cache.clear(playerId), 20L);
    }
}
