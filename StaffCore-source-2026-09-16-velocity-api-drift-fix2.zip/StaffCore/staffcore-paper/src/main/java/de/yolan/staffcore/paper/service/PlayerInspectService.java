package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.model.FreezeRecord;
import de.yolan.staffcore.common.model.PresenceRecord;
import de.yolan.staffcore.common.model.Punishment;
import de.yolan.staffcore.common.model.StaffModeSnapshotRecord;
import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.model.Ticket;
import de.yolan.staffcore.data.PlayerRepository;
import de.yolan.staffcore.data.PlayerSessionRepository;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.data.StaffNoteRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public final class PlayerInspectService {
    public record View(
            PlayerRepository.PlayerInfo player,
            Optional<PresenceRecord> presence,
            long totalSeconds,
            List<PlayerSessionRepository.ServerTime> byServer,
            List<Punishment> punishments,
            List<Ticket> tickets,
            List<StaffNoteRepository.Note> notes,
            Optional<FreezeRecord> freeze,
            Optional<StaffPersistentState> staffState,
            Optional<String> staffRank,
            Optional<StaffModeSnapshotRecord> staffMode
    ) {}

    private final Repositories repositories;
    private final Executor io;

    public PlayerInspectService(Repositories repositories, Executor io) {
        this.repositories = repositories;
        this.io = io;
    }

    public CompletableFuture<Optional<View>> load(UUID playerId) {
        return CompletableFuture.supplyAsync(() -> repositories.players.find(playerId).map(player -> new View(
                player,
                repositories.presence.find(playerId),
                repositories.playerSessions.totalSeconds(playerId),
                repositories.playerSessions.byServer(playerId),
                repositories.punishments.historyFor(playerId, 0, 50),
                repositories.tickets.listByTarget(playerId, 0, 50),
                repositories.notes.list(playerId, false, 0, 50),
                repositories.freezes.find(playerId).filter(FreezeRecord::active),
                repositories.staffStates.find(playerId),
                repositories.presence.staffRank(playerId),
                repositories.staffMode.findActive(playerId)
        )), io);
    }
}
