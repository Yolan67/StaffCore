package de.yolan.staffcore.paper.command;

import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.paper.gui.StaffMainGui;
import net.kyori.adventure.text.Component;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

public final class StaffCommand implements CommandExecutor {
    private final StaffMainGui gui;
    public StaffCommand(StaffMainGui gui){this.gui=gui;}
    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args){
        if(!(sender instanceof Player player)){sender.sendMessage("Nur Spieler.");return true;}
        if(!player.hasPermission(Permissions.MENU)){player.sendMessage(Component.text("Keine Berechtigung."));return true;}
        gui.open(player);return true;
    }
}
