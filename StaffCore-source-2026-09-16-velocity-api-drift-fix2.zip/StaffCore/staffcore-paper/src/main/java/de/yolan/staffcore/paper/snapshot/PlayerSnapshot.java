package de.yolan.staffcore.paper.snapshot;
import org.bukkit.*;import org.bukkit.inventory.ItemStack;import org.bukkit.potion.PotionEffect;import java.util.List;
public record PlayerSnapshot(ItemStack[] storage,ItemStack[] armor,ItemStack offhand,ItemStack cursor,int level,float exp,int totalExp,GameMode gameMode,double health,int food,float saturation,boolean allowFlight,boolean flying,String world,double x,double y,double z,float yaw,float pitch,List<PotionEffect> effects){}
