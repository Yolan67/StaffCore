package de.yolan.staffcore.paper.gui;

import de.yolan.staffcore.common.model.AuditEvent;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.data.AuditRepository;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.paper.service.ChatPromptService;
import de.yolan.staffcore.paper.service.PaperRankService;
import de.yolan.staffcore.paper.service.StaffVisibilityPolicy;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class LogsGui {
    private final JavaPlugin plugin;
    private final GuiManager gui;
    private final ChatPromptService prompts;
    private final Repositories repos;
    private final Executor io;
    private final PaperRankService ranks;
    private final StaffVisibilityPolicy visibility;

    public LogsGui(JavaPlugin plugin, GuiManager gui, ChatPromptService prompts, Repositories repos, Executor io,
                   PaperRankService ranks, StaffVisibilityPolicy visibility) {
        this.plugin = plugin;
        this.gui = gui;
        this.prompts = prompts;
        this.repos = repos;
        this.io = io;
        this.ranks = ranks;
        this.visibility = visibility;
    }

    public void open(Player player, int page, AuditRepository.Query query) {
        if (!player.hasPermission(Permissions.LOGS_VIEW)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        StaffRank viewerRank = ranks.rank(player).orElse(null);
        UUID viewerId = player.getUniqueId();
        io.execute(() -> {
            if (!visibleQuery(query, viewerRank)) {
                sync(() -> hidden(player));
                return;
            }
            List<AuditEvent> list = repos.audit.search(query, page * 45, 45).stream()
                    .filter(event -> visibleEvent(event, viewerRank))
                    .toList();
            sync(() -> {
                Player current = Bukkit.getPlayer(viewerId);
                if (current != null) render(current, page, query, list);
            });
        });
    }

    private boolean visibleQuery(AuditRepository.Query query, StaffRank viewerRank) {
        return (query.actor() == null || visibility.canSeePersisted(query.actor(), viewerRank))
                && (query.target() == null || visibility.canSeePersisted(query.target(), viewerRank));
    }

    private boolean visibleEvent(AuditEvent event, StaffRank viewerRank) {
        return (event.actorUuid() == null || visibility.canSeePersisted(event.actorUuid(), viewerRank))
                && (event.targetUuid() == null || visibility.canSeePersisted(event.targetUuid(), viewerRank));
    }

    private void render(Player player, int page, AuditRepository.Query query, List<AuditEvent> list) {
        if (!player.hasPermission(Permissions.LOGS_VIEW)) return;
        SecureGuiHolder holder = gui.create(player, 54, "Audit Logs");
        int slot = 0;
        for (AuditEvent event : list) {
            if (slot >= 45) break;
            String target = event.targetUuid() == null ? "-" : event.targetUuid().toString().substring(0, 8);
            String actor = event.actorName() == null ? Objects.toString(event.actorUuid(), "SYSTEM") : event.actorName();
            holder.getInventory().setItem(slot++, gui.item(Material.PAPER, event.actionType(),
                    "Actor: " + actor,
                    "Target: " + target,
                    "Server: " + Objects.toString(event.serverName(), "-"),
                    "Zeit: " + event.createdAt(),
                    "Correlation: " + event.correlationId()));
        }
        if (page > 0) gui.button(holder, 45, gui.item(Material.ARROW, "Zurück"), null,
                "prev", event -> open(player, page - 1, query));
        gui.button(holder, 46, gui.item(Material.PLAYER_HEAD, "Target filtern"), Permissions.LOGS_VIEW,
                "target", event -> promptPlayer(player, false, query));
        gui.button(holder, 47, gui.item(Material.NAME_TAG, "Actor filtern"), Permissions.LOGS_VIEW,
                "actor", event -> promptPlayer(player, true, query));
        gui.button(holder, 48, gui.item(Material.COMPARATOR, "Action filtern"), Permissions.LOGS_VIEW,
                "action", event -> prompts.ask(player, "Exakten Action-Type eingeben",
                        action -> open(player, 0, copy(query, query.actor(), query.target(), action, query.server(), query.from(), query.to()))));
        gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null,
                "close", event -> player.closeInventory());
        gui.button(holder, 50, gui.item(Material.REPEATER, "Server filtern"), Permissions.LOGS_VIEW,
                "server", event -> prompts.ask(player, "Servername eingeben",
                        server -> open(player, 0, copy(query, query.actor(), query.target(), query.action(), server, query.from(), query.to()))));
        gui.button(holder, 51, gui.item(Material.CLOCK, "Zeitraum", "Klick: letzte 24 Stunden"), Permissions.LOGS_VIEW,
                "time", event -> open(player, 0, copy(query, query.actor(), query.target(), query.action(), query.server(),
                        Instant.now().minus(Duration.ofHours(24)), Instant.now())));
        gui.button(holder, 52, gui.item(Material.BUCKET, "Filter löschen"), Permissions.LOGS_VIEW,
                "clear", event -> open(player, 0, empty()));
        if (list.size() == 45) gui.button(holder, 53, gui.item(Material.ARROW, "Weiter"), null,
                "next", event -> open(player, page + 1, query));
        gui.open(player, holder);
    }

    private void promptPlayer(Player player, boolean actor, AuditRepository.Query query) {
        prompts.ask(player, actor ? "Staff-/Actorname für Log-Filter" : "Spielername für Target-Filter", name -> {
            StaffRank viewerRank = ranks.rank(player).orElse(null);
            UUID viewerId = player.getUniqueId();
            io.execute(() -> {
                Optional<UUID> id = repos.players.findUuidByName(name);
                boolean visible = id.isPresent() && visibility.canSeePersisted(id.get(), viewerRank);
                sync(() -> {
                    Player current = Bukkit.getPlayer(viewerId);
                    if (current == null) return;
                    if (!visible) {
                        current.sendMessage(Component.text("Spieler nicht gefunden."));
                    } else if (actor) {
                        open(current, 0, copy(query, id.get(), query.target(), query.action(), query.server(), query.from(), query.to()));
                    } else {
                        open(current, 0, copy(query, query.actor(), id.get(), query.action(), query.server(), query.from(), query.to()));
                    }
                });
            });
        });
    }

    public void openForTarget(Player player, UUID target) {
        open(player, 0, new AuditRepository.Query(null, target, null, null, null, null));
    }

    private void hidden(Player player) {
        if (player.isOnline()) player.sendMessage(Component.text("Keine sichtbaren Log-Einträge für diesen Filter."));
    }

    private static AuditRepository.Query empty() {
        return new AuditRepository.Query(null, null, null, null, null, null);
    }

    private static AuditRepository.Query copy(AuditRepository.Query ignored, UUID actor, UUID target, String action,
                                              String server, Instant from, Instant to) {
        return new AuditRepository.Query(actor, target, action, server, from, to);
    }

    private void sync(Runnable task) {
        Bukkit.getScheduler().runTask(plugin, task);
    }
}
