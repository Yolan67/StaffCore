package de.yolan.staffcore.paper.service;
import de.yolan.staffcore.data.Repositories;import java.time.Instant;import java.util.UUID;
public final class StateLoader{private final Repositories r;private final ServerStateCache c;public StateLoader(Repositories r,ServerStateCache c){this.r=r;this.c=c;}public void load(UUID u){c.putStaff(u,r.staffStates.find(u).orElse(null));c.putFreeze(u,r.freezes.find(u).orElse(null));c.putStaffMode(u,r.staffMode.findActive(u).orElse(null));c.putPunishments(u,r.punishments.activeFor(u,Instant.now()));c.putBackendSnapshots(u,r.staffModeBackends.unresolved(u));}}
