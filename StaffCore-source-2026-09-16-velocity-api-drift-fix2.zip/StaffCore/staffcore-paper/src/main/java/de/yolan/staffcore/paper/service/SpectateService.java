package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.SpectatePayload;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.data.SpectateRepository;
import de.yolan.staffcore.paper.config.PaperConfig;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class SpectateService {
    private final JavaPlugin plugin;
    private final PaperConfig config;
    private final Repositories repositories;
    private final Executor io;
    private final ServerStateCache cache;
    private final BridgeClient bridge;
    private final LocalStaffStateService state;
    private final PaperAuditService audit;

    public SpectateService(
            JavaPlugin plugin,
            PaperConfig config,
            Repositories repositories,
            Executor io,
            ServerStateCache cache,
            BridgeClient bridge,
            LocalStaffStateService state,
            PaperAuditService audit) {
        this.plugin = plugin;
        this.config = config;
        this.repositories = repositories;
        this.io = io;
        this.cache = cache;
        this.bridge = bridge;
        this.state = state;
        this.audit = audit;
        bridge.on(MessageType.SPECTATE_ROUTE, envelope -> handleRoute(bridge.payload(envelope, SpectatePayload.class)));
    }

    public void start(Player staff, UUID targetUuid, boolean superMode) {
        String permission = superMode ? Permissions.SPECTATE_SUPER : Permissions.SPECTATE;
        if (!staff.hasPermission(permission)) {
            staff.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        UUID staffId = staff.getUniqueId();
        String staffName = staff.getName();
        if (staffId.equals(targetUuid)) {
            staff.sendMessage(Component.text("Du kannst dich nicht selbst spectaten."));
            return;
        }
        Location origin = staff.getLocation().clone();
        GameMode gameMode = staff.getGameMode();
        boolean originalVanish = cache.staff(staffId).map(StaffPersistentState::vanished).orElse(false);
        String originWorld = origin.getWorld().getName();

        io.execute(() -> {
            try {
                if (repositories.spectate.activeFor(staffId).isPresent()) {
                    throw new IllegalStateException("Es läuft bereits eine Spectate-Session.");
                }
                SpectateRepository.Session session = new SpectateRepository.Session(
                        UUID.randomUUID(), staffId, targetUuid, superMode ? "SUPER" : "NORMAL",
                        config.serverName(), originWorld, origin.getX(), origin.getY(), origin.getZ(),
                        origin.getYaw(), origin.getPitch(), gameMode.name(), originalVanish, "ACTIVE", 0);
                SpectateRepository.Session created = repositories.spectate.create(session);
                sync(() -> afterCreate(staffId, staffName, created, superMode, originalVanish));
            } catch (Exception exception) {
                message(staffId, "Spectate konnte nicht gestartet werden: " + root(exception));
            }
        });
    }

    private void afterCreate(
            UUID staffId,
            String staffName,
            SpectateRepository.Session session,
            boolean superMode,
            boolean originalVanish) {
        Player staff = Bukkit.getPlayer(staffId);
        if (staff == null) {
            io.execute(() -> repositories.spectate.end(session.id(), session.revision()));
            return;
        }
        String permission = superMode ? Permissions.SPECTATE_SUPER : Permissions.SPECTATE;
        if (!staff.hasPermission(permission)) {
            io.execute(() -> repositories.spectate.end(session.id(), session.revision()));
            staff.sendMessage(Component.text("Spectate abgebrochen: Permission wurde entzogen."));
            return;
        }
        if (superMode && !originalVanish) {
            state.setVanish(staff, true).whenComplete((ignored, error) -> {
                if (error != null) {
                    io.execute(() -> repositories.spectate.end(session.id(), session.revision()));
                    message(staffId, "Super-Spectate abgebrochen: Vanish konnte nicht sicher aktiviert werden.");
                } else {
                    sync(() -> routeStartMain(staffId, session));
                }
            });
        } else {
            routeStartMain(staffId, session);
        }
    }

    private void routeStartMain(UUID staffId, SpectateRepository.Session session) {
        Player staff = Bukkit.getPlayer(staffId);
        if (staff == null) return;
        Player target = Bukkit.getPlayer(session.target());
        if (target != null) {
            enterLocal(staff, target, session);
            return;
        }
        bridge.send(MessageType.SPECTATE_ROUTE, staffId, session.revision(),
                new SpectatePayload(staffId, session.target(), session.id(), "START", null));
    }

    public void stop(Player staff) {
        UUID staffId = staff.getUniqueId();
        io.execute(() -> {
            try {
                SpectateRepository.Session session = repositories.spectate.activeFor(staffId)
                        .orElseThrow(() -> new IllegalStateException("Keine aktive Spectate-Session."));
                if (config.serverName().equalsIgnoreCase(session.originServer())) {
                    sync(() -> {
                        Player online = Bukkit.getPlayer(staffId);
                        if (online != null) finishLocal(online, session);
                    });
                } else {
                    bridge.send(MessageType.SPECTATE_ROUTE, staffId, session.revision(),
                            new SpectatePayload(staffId, session.target(), session.id(), "STOP", session.originServer()));
                }
            } catch (Exception exception) {
                message(staffId, root(exception));
            }
        });
    }

    private void handleRoute(SpectatePayload payload) {
        if (payload.destinationServer() != null
                && !config.serverName().equalsIgnoreCase(payload.destinationServer())) return;
        io.execute(() -> repositories.spectate.find(payload.sessionId()).ifPresent(session -> sync(() -> {
            Player staff = Bukkit.getPlayer(payload.staffUuid());
            if (staff == null) return;
            if ("STOP".equalsIgnoreCase(payload.action())) {
                finishLocal(staff, session);
                return;
            }
            Player target = Bukkit.getPlayer(payload.targetUuid());
            if (target == null) {
                staff.sendMessage(Component.text("Spectate-Ziel ist nicht mehr auf diesem Server."));
                return;
            }
            enterLocal(staff, target, session);
        })));
    }

    private void enterLocal(Player staff, Player target, SpectateRepository.Session session) {
        String required = "SUPER".equalsIgnoreCase(session.mode()) ? Permissions.SPECTATE_SUPER : Permissions.SPECTATE;
        if (!staff.hasPermission(required)) {
            staff.sendMessage(Component.text("Spectate-Permission nicht mehr vorhanden."));
            return;
        }
        staff.setGameMode(GameMode.SPECTATOR);
        staff.teleport(target);
        try {
            staff.setSpectatorTarget(target);
        } catch (Exception ignored) {
            // Spectator target is best effort; teleport + spectator mode remain authoritative.
        }
        audit.append(staff.getUniqueId(), staff.getName(), target.getUniqueId(), config.serverName(),
                "SPECTATE_START", null,
                "{\"mode\":\"" + session.mode() + "\",\"session\":\"" + session.id() + "\"}");
        staff.sendMessage(Component.text("Spectate aktiv. /spectate stop zum Beenden."));
    }

    private void finishLocal(Player staff, SpectateRepository.Session session) {
        World world = Bukkit.getWorld(session.originWorld());
        if (world == null) {
            staff.sendMessage(Component.text("Origin-Welt ist nicht geladen. Spectate bleibt zur Recovery aktiv."));
            return;
        }
        UUID staffId = staff.getUniqueId();
        String staffName = staff.getName();
        try {
            staff.setSpectatorTarget(null);
        } catch (Exception ignored) {
        }
        staff.setGameMode(GameMode.valueOf(session.gamemode()));
        staff.teleport(new Location(world, session.x(), session.y(), session.z(), session.yaw(), session.pitch()));
        io.execute(() -> {
            if (!repositories.spectate.end(session.id(), session.revision())) {
                message(staffId, "Spectate lokal beendet, DB-Abschluss hatte einen Konflikt. Admin-Log prüfen.");
                return;
            }
            if ("SUPER".equals(session.mode()) && !session.originVanished()) {
                sync(() -> {
                    Player online = Bukkit.getPlayer(staffId);
                    if (online != null) state.setVanish(online, false);
                });
            }
            audit.append(staffId, staffName, session.target(), config.serverName(), "SPECTATE_STOP", null,
                    "{\"session\":\"" + session.id() + "\"}");
            message(staffId, "Spectate beendet und Ursprung wiederhergestellt.");
        });
    }

    public void recoverOnJoin(Player staff) {
        UUID staffId = staff.getUniqueId();
        io.execute(() -> repositories.spectate.activeFor(staffId).ifPresent(session -> {
            if (!"ACTIVE".equals(session.state())) return;
            sync(() -> routeStartMain(staffId, session));
        }));
    }

    private void message(UUID playerId, String text) {
        sync(() -> {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) player.sendMessage(Component.text(text));
        });
    }

    private void sync(Runnable runnable) {
        Bukkit.getScheduler().runTask(plugin, runnable);
    }

    private static String root(Throwable throwable) {
        Throwable root = throwable;
        while (root.getCause() != null) root = root.getCause();
        return Optional.ofNullable(root.getMessage()).orElse(root.getClass().getSimpleName());
    }
}
