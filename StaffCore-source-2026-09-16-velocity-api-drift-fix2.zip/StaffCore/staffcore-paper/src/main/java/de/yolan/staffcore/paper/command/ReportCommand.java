package de.yolan.staffcore.paper.command;
import de.yolan.staffcore.paper.gui.ReportGui;import org.bukkit.command.*;import org.bukkit.entity.Player;
public final class ReportCommand implements CommandExecutor{private final ReportGui gui;public ReportCommand(ReportGui gui){this.gui=gui;}@Override public boolean onCommand(CommandSender s,Command c,String l,String[] a){if(s instanceof Player p)gui.open(p);else s.sendMessage("Nur Spieler.");return true;}}
