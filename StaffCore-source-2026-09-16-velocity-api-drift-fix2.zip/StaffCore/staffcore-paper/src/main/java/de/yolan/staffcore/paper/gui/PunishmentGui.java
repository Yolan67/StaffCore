package de.yolan.staffcore.paper.gui;

import de.yolan.staffcore.common.model.Punishment;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.PunishmentRequestPayload;
import de.yolan.staffcore.common.punishment.PunishmentType;
import de.yolan.staffcore.common.util.DurationParser;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.paper.config.PaperConfig;
import de.yolan.staffcore.paper.service.BridgeClient;
import de.yolan.staffcore.paper.service.ChatPromptService;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class PunishmentGui {
    private final JavaPlugin plugin;
    private final GuiManager gui;
    private final ChatPromptService prompts;
    private final Repositories repos;
    private final Executor io;
    private final BridgeClient bridge;
    private final PaperConfig config;

    public PunishmentGui(
            JavaPlugin plugin,
            GuiManager gui,
            ChatPromptService prompts,
            Repositories repos,
            Executor io,
            BridgeClient bridge,
            PaperConfig config) {
        this.plugin = plugin;
        this.gui = gui;
        this.prompts = prompts;
        this.repos = repos;
        this.io = io;
        this.bridge = bridge;
        this.config = config;
    }

    public void promptTarget(Player player) {
        if (!hasAnyPermission(player)) {
            player.sendMessage(Component.text("Keine Punishment-Berechtigung."));
            return;
        }
        prompts.ask(player, "Spielername für Punishment", name -> resolve(name, id -> open(player, id, name)));
    }

    public void open(Player player, UUID target, String display) {
        if (!hasAnyPermission(player)) return;
        SecureGuiHolder holder = gui.create(player, 36, "Punishment: " + display);
        add(holder, player, 10, Material.PAPER, "Warn", PunishmentType.WARN, Permissions.PUNISH_WARN, target, display);
        add(holder, player, 11, Material.BARRIER, "Kick", PunishmentType.KICK, Permissions.PUNISH_KICK, target, display);
        add(holder, player, 13, Material.BOOK, "Mute / TempMute", PunishmentType.MUTE, Permissions.PUNISH_MUTE, target, display);
        add(holder, player, 15, Material.IRON_DOOR, "ServerBan / TempServerBan", PunishmentType.SERVER_BAN,
                Permissions.PUNISH_SERVERBAN, target, display);
        add(holder, player, 16, Material.BEDROCK, "GlobalBan / TempGlobalBan", PunishmentType.GLOBAL_BAN,
                Permissions.PUNISH_GLOBALBAN, target, display);
        gui.button(holder, 31, gui.item(Material.WRITABLE_BOOK, "Historie / Aufheben"), null,
                "history", event -> history(player, target, display, 0));
        gui.button(holder, 35, gui.item(Material.BARRIER, "Schließen"), null,
                "close", event -> player.closeInventory());
        gui.open(player, holder);
    }

    private void add(
            SecureGuiHolder holder,
            Player player,
            int slot,
            Material material,
            String name,
            PunishmentType type,
            String permission,
            UUID target,
            String display) {
        if (!player.hasPermission(permission)) return;
        gui.button(holder, slot, gui.item(material, name), permission, "punish-" + type,
                event -> {
                    if (type == PunishmentType.WARN || type == PunishmentType.KICK) {
                        askReason(player, target, display, type, null, null);
                    } else if (type == PunishmentType.SERVER_BAN) {
                        chooseServer(player, target, display);
                    } else {
                        chooseDuration(player, target, display, type, null);
                    }
                });
    }

    private void chooseServer(Player player, UUID target, String display) {
        if (!player.hasPermission(Permissions.PUNISH_SERVERBAN)) return;
        SecureGuiHolder holder = gui.create(player, 27, "ServerBan: Server wählen");
        gui.button(holder, 11, gui.item(Material.COMPASS, "Dieser Backendserver", config.serverName()),
                Permissions.PUNISH_SERVERBAN, "current-server",
                event -> chooseDuration(player, target, display, PunishmentType.SERVER_BAN, config.serverName()));
        gui.button(holder, 15, gui.item(Material.NAME_TAG, "Servername eingeben",
                        "Velocity validiert den Namen vor dem DB-Commit."),
                Permissions.PUNISH_SERVERBAN, "custom-server",
                event -> prompts.ask(player, "Velocity-Servername eingeben",
                        server -> chooseDuration(player, target, display, PunishmentType.SERVER_BAN, server.strip())));
        gui.button(holder, 22, gui.item(Material.ARROW, "Zurück"), null,
                "back", event -> open(player, target, display));
        gui.open(player, holder);
    }

    private void chooseDuration(Player player, UUID target, String display, PunishmentType type, String server) {
        String permission = permission(type);
        if (!player.hasPermission(permission)) return;
        SecureGuiHolder holder = gui.create(player, 36, "Dauer: " + type.name());
        durationButton(holder, player, 10, "30 Minuten", Duration.ofMinutes(30), target, display, type, server);
        durationButton(holder, player, 11, "2 Stunden", Duration.ofHours(2), target, display, type, server);
        durationButton(holder, player, 12, "1 Tag", Duration.ofDays(1), target, display, type, server);
        durationButton(holder, player, 13, "7 Tage", Duration.ofDays(7), target, display, type, server);
        durationButton(holder, player, 14, "30 Tage", Duration.ofDays(30), target, display, type, server);
        gui.button(holder, 15, gui.item(Material.CLOCK, "Eigene Dauer", "z. B. 45m, 12h, 14d"), permission,
                "custom-duration", event -> prompts.ask(player, "Dauer eingeben (z. B. 45m, 12h, 14d)", value -> {
                    Optional<Duration> parsed = DurationParser.parse(value);
                    if (parsed.isEmpty() || parsed.get().isZero() || parsed.get().isNegative()) {
                        player.sendMessage(Component.text("Ungültige temporäre Dauer."));
                        return;
                    }
                    askReason(player, target, display, type, server, parsed.get());
                }));
        gui.button(holder, 16, gui.item(Material.BEDROCK, "Permanent"), permission,
                "permanent", event -> askReason(player, target, display, type, server, null));
        gui.button(holder, 31, gui.item(Material.ARROW, "Zurück"), null,
                "back", event -> open(player, target, display));
        gui.open(player, holder);
    }

    private void durationButton(
            SecureGuiHolder holder,
            Player player,
            int slot,
            String label,
            Duration duration,
            UUID target,
            String display,
            PunishmentType type,
            String server) {
        gui.button(holder, slot, gui.item(Material.CLOCK, label), permission(type), "duration-" + duration.toSeconds(),
                event -> askReason(player, target, display, type, server, duration));
    }

    private void askReason(
            Player player,
            UUID target,
            String display,
            PunishmentType type,
            String server,
            Duration duration) {
        if (!player.hasPermission(permission(type))) return;
        prompts.ask(player, "Grund eingeben", reason -> prompts.ask(player,
                "Interne Beschreibung eingeben ('-' für keine)", description -> confirm(
                        player,
                        target,
                        display,
                        type,
                        server,
                        duration,
                        reason,
                        description.equals("-") ? null : description)));
    }

    private void confirm(
            Player player,
            UUID target,
            String display,
            PunishmentType type,
            String server,
            Duration duration,
            String reason,
            String description) {
        String permission = permission(type);
        if (!player.hasPermission(permission)) return;
        SecureGuiHolder holder = gui.create(player, 27, "Punishment bestätigen");
        holder.getInventory().setItem(13, gui.item(Material.PAPER, type.name(),
                "Ziel: " + display,
                "Scope: " + (type == PunishmentType.SERVER_BAN ? "SERVER " + server : "NETWORK"),
                "Dauer: " + (duration == null ? "permanent/einmalig" : DurationParser.format(duration)),
                "Grund: " + reason));
        gui.button(holder, 11, gui.item(Material.LIME_DYE, "Bestätigen"), permission, "confirm",
                event -> sendCreate(player, target, type, server, duration, reason, description));
        gui.button(holder, 15, gui.item(Material.RED_DYE, "Abbrechen"), null, "cancel",
                event -> open(player, target, display));
        gui.open(player, holder);
    }

    private void sendCreate(
            Player player,
            UUID target,
            PunishmentType type,
            String server,
            Duration duration,
            String reason,
            String description) {
        if (!player.hasPermission(permission(type))) return;
        UUID requestId = UUID.randomUUID();
        PunishmentRequestPayload request = new PunishmentRequestPayload(
                player.getUniqueId(), target, "CREATE", type.name(), null, server,
                duration == null ? null : duration.toSeconds(), reason, description, requestId);
        bridge.send(MessageType.PUNISHMENT_REQUEST, target, 0, request);
        player.closeInventory();
        player.sendMessage(Component.text("Punishment-Anfrage wurde an Velocity gesendet. Erfolg wird erst nach DB-Commit bestätigt."));
    }

    public void history(Player player, UUID target, String display, int page) {
        if (!hasAnyPermission(player)) return;
        io.execute(() -> {
            List<Punishment> list = repos.punishments.historyFor(target, page * 45, 45);
            sync(() -> renderHistory(player, target, display, page, list));
        });
    }

    private void renderHistory(Player player, UUID target, String display, int page, List<Punishment> list) {
        if (!hasAnyPermission(player)) return;
        SecureGuiHolder holder = gui.create(player, 54, "Punishments: " + display);
        int slot = 0;
        Instant now = Instant.now();
        for (Punishment punishment : list) {
            if (slot >= 45) break;
            boolean active = punishment.isActiveAt(now);
            String permission = permission(punishment.type());
            var item = gui.item(active ? Material.ENCHANTED_BOOK : Material.BOOK,
                    punishment.type() + " " + punishment.status(),
                    "ID: " + punishment.id(),
                    "Grund: " + punishment.reason(),
                    "Scope: " + punishment.scope() + Objects.toString(punishment.serverName(), ""),
                    "Erstellt: " + punishment.createdAt(),
                    "Ablauf: " + Objects.toString(punishment.expiresAt(), "permanent"),
                    active && player.hasPermission(permission) ? "Klick: aufheben" : "");
            if (active && player.hasPermission(permission) && punishment.type() != PunishmentType.WARN
                    && punishment.type() != PunishmentType.KICK) {
                Punishment selected = punishment;
                gui.button(holder, slot, item, permission, "revoke-" + selected.id(),
                        event -> prompts.ask(player, "Grund für Aufhebung", reason -> revoke(player, selected, reason)));
            } else {
                holder.getInventory().setItem(slot, item);
            }
            slot++;
        }
        if (page > 0) {
            gui.button(holder, 45, gui.item(Material.ARROW, "Zurück"), null,
                    "prev", event -> history(player, target, display, page - 1));
        }
        gui.button(holder, 49, gui.item(Material.COMPASS, "Aktionsmenü"), null,
                "actions", event -> open(player, target, display));
        if (list.size() == 45) {
            gui.button(holder, 53, gui.item(Material.ARROW, "Weiter"), null,
                    "next", event -> history(player, target, display, page + 1));
        }
        gui.open(player, holder);
    }

    private void revoke(Player player, Punishment punishment, String reason) {
        String permission = permission(punishment.type());
        if (!player.hasPermission(permission)) return;
        UUID requestId = UUID.randomUUID();
        PunishmentRequestPayload request = new PunishmentRequestPayload(
                player.getUniqueId(), punishment.targetUuid(), "REVOKE", punishment.type().name(),
                punishment.id(), punishment.serverName(), null, reason, null, requestId);
        bridge.send(MessageType.PUNISHMENT_REQUEST, punishment.targetUuid(), 0, request);
        player.closeInventory();
        player.sendMessage(Component.text("Aufhebungs-Anfrage wurde an Velocity gesendet."));
    }

    private void resolve(String name, java.util.function.Consumer<UUID> success) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            success.accept(online.getUniqueId());
            return;
        }
        io.execute(() -> {
            Optional<UUID> id = repos.players.findUuidByName(name);
            sync(() -> {
                if (id.isEmpty()) Bukkit.getConsoleSender().sendMessage(Component.text("StaffCore: Spieler nicht gefunden: " + name));
                else success.accept(id.get());
            });
        });
    }

    private static String permission(PunishmentType type) {
        return switch (type) {
            case WARN -> Permissions.PUNISH_WARN;
            case KICK -> Permissions.PUNISH_KICK;
            case MUTE -> Permissions.PUNISH_MUTE;
            case SERVER_BAN -> Permissions.PUNISH_SERVERBAN;
            case GLOBAL_BAN -> Permissions.PUNISH_GLOBALBAN;
        };
    }

    private static boolean hasAnyPermission(Player player) {
        return player.hasPermission(Permissions.PUNISH_WARN)
                || player.hasPermission(Permissions.PUNISH_KICK)
                || player.hasPermission(Permissions.PUNISH_MUTE)
                || player.hasPermission(Permissions.PUNISH_SERVERBAN)
                || player.hasPermission(Permissions.PUNISH_GLOBALBAN);
    }

    private void sync(Runnable task) {
        Bukkit.getScheduler().runTask(plugin, task);
    }
}
