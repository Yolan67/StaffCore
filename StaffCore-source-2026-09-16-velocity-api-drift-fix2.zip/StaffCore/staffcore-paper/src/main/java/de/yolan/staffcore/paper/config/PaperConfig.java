package de.yolan.staffcore.paper.config;

import de.yolan.staffcore.common.ticket.PriorityConfig;
import de.yolan.staffcore.data.DatabaseConfig;

import java.time.Duration;
import java.util.Set;

public record PaperConfig(
        int configVersion,
        DatabaseConfig database,
        String bridgeSecret,
        String serverName,
        String messageLocale,
        String systemPrefix,
        int guiPageSize,
        boolean dangerousActionsRequireConfirmation,
        String staffModeGameMode,
        boolean staffModeFlight,
        boolean staffModeRecoveryOnJoin,
        boolean vanishFakeJoinLeave,
        boolean vanishRefreshAfterWorldChange,
        Set<String> freezeAllowedCommands,
        boolean freezeFakeBodyEnabled,
        Set<String> muteBlockedCommands,
        PriorityConfig priority,
        Duration ticketCreateCooldown,
        int ticketMaxOpen,
        Duration ticketDuplicateWindow,
        int ticketMaxDescriptionLength,
        int ticketMaxMessageLength,
        boolean staffJoinOverview,
        int maxInboxPage,
        boolean showIpOnlyWithPermission,
        boolean persistIpAddresses,
        boolean auditSensitiveIpViews,
        int maxAuditPayloadChars,
        boolean maintenanceEnabled,
        boolean maintenanceRequired,
        boolean degradedMode,
        boolean failClosedCriticalMutations) {

    public PaperConfig {
        if (configVersion != 1) {
            throw new IllegalArgumentException("Unsupported config-version: " + configVersion);
        }
        if (bridgeSecret == null || bridgeSecret.length() < 32) {
            throw new IllegalArgumentException("bridge.secret must be at least 32 characters");
        }
        if (serverName == null || serverName.isBlank() || serverName.equalsIgnoreCase("change-me")) {
            throw new IllegalArgumentException("server-name must be configured uniquely for this backend");
        }
        if (messageLocale == null || messageLocale.isBlank()) {
            throw new IllegalArgumentException("messages.locale must not be blank");
        }
        if (systemPrefix == null) {
            throw new IllegalArgumentException("messages.system-prefix must not be null");
        }
        if (guiPageSize < 1 || guiPageSize > 45) {
            throw new IllegalArgumentException("gui.page-size must be between 1 and 45");
        }
        if (!dangerousActionsRequireConfirmation) {
            throw new IllegalArgumentException("gui.dangerous-actions-require-confirmation must remain true");
        }
        if (staffModeGameMode == null || !Set.of("SURVIVAL", "CREATIVE", "ADVENTURE", "SPECTATOR")
                .contains(staffModeGameMode.trim().toUpperCase(java.util.Locale.ROOT))) {
            throw new IllegalArgumentException("staffmode.gamemode must be SURVIVAL, CREATIVE, ADVENTURE or SPECTATOR");
        }
        if (!showIpOnlyWithPermission) {
            throw new IllegalArgumentException("privacy.show-ip-only-with-permission must remain true");
        }
        if (freezeFakeBodyEnabled) {
            throw new IllegalArgumentException("freeze.fake-body.enabled=true is not available in the public-API-only build; leave it false");
        }
        if (ticketCreateCooldown == null || ticketCreateCooldown.isNegative()) {
            throw new IllegalArgumentException("tickets.create-cooldown must be >= 0");
        }
        if (ticketMaxOpen < 1 || ticketMaxOpen > 100) {
            throw new IllegalArgumentException("tickets.max-open-per-player must be between 1 and 100");
        }
        if (ticketDuplicateWindow == null || ticketDuplicateWindow.isNegative()) {
            throw new IllegalArgumentException("tickets.duplicate-window must be >= 0");
        }
        if (ticketMaxDescriptionLength < 32 || ticketMaxDescriptionLength > 32_768) {
            throw new IllegalArgumentException("tickets.max-description-length must be between 32 and 32768");
        }
        if (ticketMaxMessageLength < 16 || ticketMaxMessageLength > 32_768) {
            throw new IllegalArgumentException("tickets.max-message-length must be between 16 and 32768");
        }
        if (maxInboxPage < 1 || maxInboxPage > 500) {
            throw new IllegalArgumentException("notifications.max-inbox-page must be between 1 and 500");
        }
        if (maxAuditPayloadChars < 256 || maxAuditPayloadChars > 65_535) {
            throw new IllegalArgumentException("logging.max-payload-chars must be between 256 and 65535");
        }
        if (persistIpAddresses) {
            throw new IllegalArgumentException("privacy.persist-ip-addresses=true is unsupported; StaffCore intentionally does not persist player IP addresses");
        }
        if (maintenanceRequired) {
            throw new IllegalArgumentException("integrations.maintenancecore.required=true is unsupported until a MaintenanceCore public ServiceManager API is installed");
        }
        if (!degradedMode) {
            throw new IllegalArgumentException("runtime.degraded-mode must remain true; fail-safe DB degradation cannot be disabled");
        }
        if (!failClosedCriticalMutations) {
            throw new IllegalArgumentException("recovery.fail-closed-for-critical-mutations must remain true");
        }
        freezeAllowedCommands = Set.copyOf(freezeAllowedCommands);
        muteBlockedCommands = Set.copyOf(muteBlockedCommands);
    }
}
