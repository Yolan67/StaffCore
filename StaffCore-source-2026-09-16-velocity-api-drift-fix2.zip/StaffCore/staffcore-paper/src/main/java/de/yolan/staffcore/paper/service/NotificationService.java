package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.model.Notification;
import de.yolan.staffcore.data.DatabaseManager;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.paper.config.PaperConfig;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.logging.Level;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class NotificationService {
    private final JavaPlugin plugin;
    private final DatabaseManager database;
    private final Repositories repositories;
    private final Executor io;
    private final int maxInboxPage;

    public NotificationService(JavaPlugin plugin, DatabaseManager database, Repositories repositories,
                               Executor io, PaperConfig config) {
        this.plugin = plugin;
        this.database = database;
        this.repositories = repositories;
        this.io = io;
        this.maxInboxPage = config.maxInboxPage();
    }

    public void onStaffJoin(Player player) {
        UUID playerId = player.getUniqueId();
        io.execute(() -> {
            try {
                var preferences = repositories.preferences.get(playerId);
                List<Notification> unread = preferences.notifications()
                        ? repositories.notifications.unread(playerId, Math.min(10, maxInboxPage))
                        : List.of();
                int open = preferences.joinSummary() ? repositories.tickets.countQueue() : 0;
                int critical = preferences.joinSummary() ? repositories.tickets.countCritical() : 0;
                int mine = preferences.joinSummary() ? repositories.tickets.countAssigned(playerId) : 0;
                int escalated = preferences.joinSummary() ? repositories.tickets.countEscalated() : 0;
                int frozen = preferences.joinSummary() ? repositories.freezes.active(100).size() : 0;
                int staff = preferences.joinSummary() ? repositories.presence.staffOnline().size() : 0;
                boolean databaseHealthy = database.isHealthy();
                Bukkit.getScheduler().runTask(plugin, () -> {
                    Player online = Bukkit.getPlayer(playerId);
                    if (online == null) return;
                    if (preferences.joinSummary()) {
                        online.sendMessage(Component.text("StaffCore: offen=" + open + ", kritisch=" + critical
                                + ", mir=" + mine + ", eskaliert=" + escalated + ", frozen=" + frozen
                                + ", Staff online=" + staff + ", DB=" + (databaseHealthy ? "HEALTHY" : "DEGRADED")));
                    }
                    for (Notification notification : unread) {
                        online.sendMessage(Component.text("[Inbox] " + notification.title() + ": " + notification.body()));
                    }
                });
            } catch (Exception ex) {
                plugin.getLogger().log(Level.WARNING, "StaffCore Join-Übersicht/Inbox konnte nicht geladen werden: " + ex.getMessage());
            }
        });
    }

    public CompletableFuture<Integer> unread(UUID playerId) {
        return CompletableFuture.supplyAsync(() -> repositories.notifications.unreadCount(playerId), io);
    }

    public CompletableFuture<List<Notification>> list(UUID playerId) {
        return CompletableFuture.supplyAsync(() -> repositories.notifications.unread(playerId, maxInboxPage), io);
    }

    public void markAll(UUID playerId) {
        io.execute(() -> repositories.notifications.markAllRead(playerId));
    }
}
