package de.yolan.staffcore.paper.listener;

import de.yolan.staffcore.paper.config.PaperConfig;
import de.yolan.staffcore.paper.service.VanishService;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityTargetLivingEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class VanishListener implements Listener {
    private final VanishService vanish;
    private final JavaPlugin plugin;
    private final boolean refreshAfterWorldChange;

    public VanishListener(JavaPlugin plugin, VanishService vanish, PaperConfig config) {
        this.plugin = plugin;
        this.vanish = vanish;
        this.refreshAfterWorldChange = config.vanishRefreshAfterWorldChange();
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void join(PlayerJoinEvent event) {
        if (vanish.vanished(event.getPlayer().getUniqueId())) event.joinMessage(null);
        vanish.refreshViewer(event.getPlayer());
        vanish.refreshTarget(event.getPlayer(), false);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void quit(PlayerQuitEvent event) {
        if (vanish.vanished(event.getPlayer().getUniqueId())) event.quitMessage(null);
    }

    @EventHandler
    public void world(PlayerChangedWorldEvent event) {
        if (refreshAfterWorldChange) refreshNextTick(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void teleport(PlayerTeleportEvent event) {
        refreshNextTick(event.getPlayer());
    }

    @EventHandler
    public void respawn(PlayerRespawnEvent event) {
        refreshNextTick(event.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void target(EntityTargetLivingEntityEvent event) {
        if (event.getTarget() instanceof Player player && vanish.vanished(player.getUniqueId())) {
            event.setCancelled(true);
        }
    }

    @EventHandler
    public void death(PlayerDeathEvent event) {
        if (vanish.vanished(event.getPlayer().getUniqueId())) event.deathMessage(null);
    }

    private void refreshNextTick(Player player) {
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            if (!player.isOnline()) return;
            vanish.refreshViewer(player);
            vanish.refreshTarget(player, false);
        }, 1L);
    }
}
