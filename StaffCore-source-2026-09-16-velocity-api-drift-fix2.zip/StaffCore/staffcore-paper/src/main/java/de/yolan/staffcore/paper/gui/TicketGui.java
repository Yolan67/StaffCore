package de.yolan.staffcore.paper.gui;

import de.yolan.staffcore.common.model.PresenceRecord;
import de.yolan.staffcore.common.model.Ticket;
import de.yolan.staffcore.common.model.TicketMessage;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.common.ticket.TicketPriority;
import de.yolan.staffcore.common.ticket.TicketQueueFilter;
import de.yolan.staffcore.common.ticket.TicketStatus;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.data.TicketRepository;
import de.yolan.staffcore.paper.service.ChatPromptService;
import de.yolan.staffcore.paper.service.PaperRankService;
import de.yolan.staffcore.paper.service.TicketService;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;

public final class TicketGui {
    private record ReassignCandidate(PresenceRecord presence, StaffRank rank, boolean vanished) {}
    private record DetailData(Optional<Ticket> ticket, List<TicketMessage> messages,
                              List<TicketRepository.InternalNote> internalNotes) {}

    private final GuiManager gui;
    private final TicketService service;
    private final ChatPromptService prompts;
    private final PaperRankService ranks;
    private final Repositories repos;
    private final Executor io;

    public TicketGui(GuiManager gui, TicketService service, ChatPromptService prompts, PaperRankService ranks,
                     Repositories repos, Executor io) {
        this.gui = gui;
        this.service = service;
        this.prompts = prompts;
        this.ranks = ranks;
        this.repos = repos;
        this.io = io;
    }

    public void openOwn(Player player, int page, boolean closed) {
        UUID viewerId = player.getUniqueId();
        loading(player, "Tickets werden geladen …");
        service.own(viewerId, closed, page).whenComplete((list, error) -> sync(() -> {
            if (!player.isOnline()) return;
            if (error != null) {
                player.sendMessage(Component.text("Tickets konnten nicht geladen werden: " + root(error)));
                return;
            }
            SecureGuiHolder holder = gui.create(player, 54, closed ? "Geschlossene Tickets" : "Meine Tickets");
            renderTickets(player, holder, list, false);
            if (page > 0) gui.button(holder, 45, gui.item(Material.ARROW, "Zurück"), null, "prev",
                    event -> openOwn(player, page - 1, closed));
            gui.button(holder, 47, gui.item(Material.CHEST, closed ? "Offene Tickets" : "Geschlossene Tickets"),
                    null, "toggle", event -> openOwn(player, 0, !closed));
            gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null, "close", event -> player.closeInventory());
            if (list.size() == 45) gui.button(holder, 53, gui.item(Material.ARROW, "Weiter"), null, "next",
                    event -> openOwn(player, page + 1, closed));
            gui.open(player, holder);
        }));
    }

    public void openStaffHome(Player player) {
        if (!player.hasPermission(Permissions.TICKET_VIEW)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        SecureGuiHolder holder = gui.create(player, 54, "Staff Tickets");
        queueButton(holder, player, 10, Material.CHEST, "Offen", TicketQueueFilter.OPEN);
        queueButton(holder, player, 11, Material.NAME_TAG, "Mir zugewiesen", TicketQueueFilter.ASSIGNED_TO_ME);
        queueButton(holder, player, 12, Material.HOPPER, "Unzugewiesen", TicketQueueFilter.UNASSIGNED);
        queueButton(holder, player, 13, Material.ORANGE_DYE, "Hohe Priorität", TicketQueueFilter.HIGH);
        queueButton(holder, player, 14, Material.REDSTONE_BLOCK, "Kritisch", TicketQueueFilter.CRITICAL);
        queueButton(holder, player, 15, Material.GOLD_INGOT, "Eskaliert", TicketQueueFilter.ESCALATED);
        queueButton(holder, player, 16, Material.CLOCK, "Warte auf Spieler", TicketQueueFilter.WAITING_FOR_PLAYER);
        queueButton(holder, player, 28, Material.EMERALD, "Gelöst", TicketQueueFilter.RESOLVED);
        queueButton(holder, player, 29, Material.GRAY_DYE, "Geschlossen", TicketQueueFilter.CLOSED);
        queueButton(holder, player, 30, Material.RED_DYE, "Abgelehnt", TicketQueueFilter.REJECTED);
        queueButton(holder, player, 31, Material.BOOK, "Verlauf", TicketQueueFilter.HISTORY);
        gui.button(holder, 32, gui.item(Material.COMPASS, "Ticket-ID suchen"), Permissions.TICKET_VIEW,
                "search", event -> prompts.ask(player, "Ticket-ID eingeben", input -> {
                    try {
                        long id = Long.parseLong(input.trim());
                        if (id <= 0) throw new NumberFormatException();
                        openDetail(player, id, true);
                    } catch (NumberFormatException ex) {
                        player.sendMessage(Component.text("Ungültige Ticket-ID."));
                    }
                }));
        gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null, "close", event -> player.closeInventory());
        gui.open(player, holder);
    }

    public void openStaff(Player player, int page) {
        openStaff(player, TicketQueueFilter.OPEN, page);
    }

    public void openCritical(Player player) {
        openStaff(player, TicketQueueFilter.CRITICAL, 0);
    }

    public void openAssigned(Player player) {
        openStaff(player, TicketQueueFilter.ASSIGNED_TO_ME, 0);
    }

    public void openStaff(Player player, TicketQueueFilter filter, int page) {
        if (!player.hasPermission(Permissions.TICKET_VIEW)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        UUID viewerId = player.getUniqueId();
        StaffRank viewerRank = ranks.rank(player).orElse(null);
        if (viewerRank == null) {
            player.sendMessage(Component.text("Für Staff-Tickets ist eine Staff-Rank-Permission erforderlich."));
            return;
        }
        loading(player, "Staff-Tickets werden geladen …");
        service.staff(viewerId, filter, page).whenComplete((list, error) -> sync(() -> {
            if (!player.isOnline()) return;
            if (error != null) {
                player.sendMessage(Component.text("Tickets konnten nicht geladen werden: " + root(error)));
                return;
            }
            if (!player.hasPermission(Permissions.TICKET_VIEW)) {
                player.closeInventory();
                return;
            }
            StaffRank currentRank = ranks.rank(player).orElse(null);
            if (currentRank == null) {
                player.closeInventory();
                return;
            }
            List<Ticket> visible = list.stream()
                    .filter(ticket -> currentRank.level() >= ticket.minimumRank().level())
                    .toList();
            SecureGuiHolder holder = gui.create(player, 54, "Tickets: " + display(filter));
            renderTickets(player, holder, visible, true);
            if (page > 0) gui.button(holder, 45, gui.item(Material.ARROW, "Zurück"), Permissions.TICKET_VIEW,
                    "prev", event -> openStaff(player, filter, page - 1));
            gui.button(holder, 47, gui.item(Material.CHEST, "Queues"), Permissions.TICKET_VIEW,
                    "queues", event -> openStaffHome(player));
            gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null,
                    "close", event -> player.closeInventory());
            if (list.size() == 45) gui.button(holder, 53, gui.item(Material.ARROW, "Weiter"), Permissions.TICKET_VIEW,
                    "next", event -> openStaff(player, filter, page + 1));
            gui.open(player, holder);
        }));
    }

    private void queueButton(SecureGuiHolder holder, Player player, int slot, Material material, String name,
                             TicketQueueFilter filter) {
        gui.button(holder, slot, gui.item(material, name), Permissions.TICKET_VIEW,
                "queue-" + filter.name().toLowerCase(Locale.ROOT), event -> openStaff(player, filter, 0));
    }

    private void renderTickets(Player player, SecureGuiHolder holder, List<Ticket> tickets, boolean staff) {
        int slot = 0;
        for (Ticket ticket : tickets) {
            if (slot >= 45) break;
            String target = ticket.targetUuid() == null ? "-" : shortUuid(ticket.targetUuid());
            var item = gui.item(material(ticket.priority()), "#" + ticket.id() + " " + ticket.category(),
                    "Status: " + ticket.status(),
                    "Priorität: " + ticket.priority() + " (" + ticket.priorityScore() + ")",
                    "Min-Rang: " + ticket.minimumRank(),
                    "Bearbeiter: " + (ticket.assigneeUuid() == null ? "-" : shortUuid(ticket.assigneeUuid())),
                    "Ziel: " + target,
                    "Revision: " + ticket.revision());
            gui.button(holder, slot++, item, staff ? Permissions.TICKET_VIEW : null,
                    "ticket-" + ticket.id(), event -> openDetail(player, ticket.id(), staff));
        }
    }


    public void openForTarget(Player player, UUID target, String displayName, int page) {
        if (!player.hasPermission(Permissions.TICKET_VIEW)) return;
        StaffRank viewerRank = ranks.rank(player).orElse(null);
        if (viewerRank == null) return;
        loading(player, "Tickets gegen Spieler werden geladen …");
        io.execute(() -> {
            List<Ticket> found = repos.tickets.listByTarget(target, page * 45, 45);
            sync(() -> {
                if (!player.isOnline() || !player.hasPermission(Permissions.TICKET_VIEW)) return;
                StaffRank current = ranks.rank(player).orElse(null);
                if (current == null) return;
                List<Ticket> visible = found.stream()
                        .filter(ticket -> current.level() >= ticket.minimumRank().level())
                        .toList();
                SecureGuiHolder holder = gui.create(player, 54, "Tickets: " + displayName);
                renderTickets(player, holder, visible, true);
                if (page > 0) gui.button(holder, 45, gui.item(Material.ARROW, "Zurück"), Permissions.TICKET_VIEW,
                        "prev", event -> openForTarget(player, target, displayName, page - 1));
                gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null, "close", event -> player.closeInventory());
                if (found.size() == 45) gui.button(holder, 53, gui.item(Material.ARROW, "Weiter"), Permissions.TICKET_VIEW,
                        "next", event -> openForTarget(player, target, displayName, page + 1));
                gui.open(player, holder);
            });
        });
    }

    public void openDetail(Player player, long id, boolean staffView) {
        loading(player, "Ticket wird geladen …");
        CompletableFuture<Optional<Ticket>> ticketFuture = service.find(id);
        CompletableFuture<List<TicketMessage>> messageFuture = service.messages(id);
        CompletableFuture<List<TicketRepository.InternalNote>> noteFuture = staffView
                ? service.internalNotes(id) : CompletableFuture.completedFuture(List.of());
        ticketFuture.thenCombine(messageFuture, Pair::new)
                .thenCombine(noteFuture, (pair, notes) -> new DetailData(pair.ticket(), pair.messages(), notes))
                .whenComplete((data, error) -> sync(() -> renderDetail(player, id, staffView, data, error)));
    }

    private record Pair(Optional<Ticket> ticket, List<TicketMessage> messages) {}

    private void renderDetail(Player player, long id, boolean staffView, DetailData data, Throwable error) {
        if (!player.isOnline()) return;
        if (error != null || data == null || data.ticket().isEmpty()) {
            player.sendMessage(Component.text("Ticket wurde geändert oder existiert nicht."));
            return;
        }
        Ticket ticket = data.ticket().get();
        if (!staffView && !ticket.creatorUuid().equals(player.getUniqueId())) {
            player.sendMessage(Component.text("Kein Zugriff auf dieses Ticket."));
            return;
        }
        if (staffView) {
            if (!player.hasPermission(Permissions.TICKET_VIEW)) {
                player.sendMessage(Component.text("Keine Berechtigung."));
                return;
            }
            StaffRank viewer = ranks.rank(player).orElse(null);
            if (viewer == null || viewer.level() < ticket.minimumRank().level()) {
                player.sendMessage(Component.text("Dieses Ticket benötigt einen höheren Staff-Rang."));
                return;
            }
        }

        SecureGuiHolder holder = gui.create(player, 54, "Ticket #" + ticket.id());
        holder.getInventory().setItem(4, gui.item(material(ticket.priority()), "#" + ticket.id() + " " + ticket.category(),
                "Status: " + ticket.status(),
                "Priorität: " + ticket.priority() + " / " + ticket.priorityScore(),
                "Warum: " + clip(ticket.priorityExplanation(), 140),
                "Min-Rang: " + ticket.minimumRank(),
                "Bearbeiter: " + (ticket.assigneeUuid() == null ? "-" : shortUuid(ticket.assigneeUuid())),
                "Beschreibung: " + clip(ticket.description(), 120)));

        int slot = 9;
        List<TicketMessage> messages = data.messages();
        for (TicketMessage message : messages.stream().skip(Math.max(0, messages.size() - 18L)).toList()) {
            if (slot > 26) break;
            holder.getInventory().setItem(slot++, gui.item(message.staff() ? Material.WRITABLE_BOOK : Material.PAPER,
                    (message.staff() ? "Staff " : "Spieler ") + message.authorName(), clip(message.message(), 110),
                    message.createdAt().toString()));
        }
        if (staffView) {
            int noteSlot = 27;
            List<TicketRepository.InternalNote> internal = data.internalNotes();
            for (TicketRepository.InternalNote note : internal.stream().skip(Math.max(0, internal.size() - 5L)).toList()) {
                if (noteSlot > 31) break;
                holder.getInventory().setItem(noteSlot++, gui.item(Material.LECTERN, "Interne Notiz",
                        "Autor: " + shortUuid(note.authorUuid()), clip(note.note(), 100), note.createdAt().toString()));
            }
            staffActions(player, holder, ticket);
        } else {
            playerActions(player, holder, ticket);
        }
        gui.button(holder, 49, gui.item(Material.ARROW, "Zurück"), null, "back",
                event -> { if (staffView) openStaffHome(player); else openOwn(player, 0, false); });
        gui.open(player, holder);
    }

    private void playerActions(Player player, SecureGuiHolder holder, Ticket ticket) {
        if (ticket.status() == TicketStatus.CLOSED || ticket.status() == TicketStatus.REJECTED) return;
        gui.button(holder, 45, gui.item(Material.FEATHER, "Antworten"), null, "reply",
                event -> prompts.ask(player, "Antwort eingeben", text -> {
                    UUID actorId = player.getUniqueId();
                    String actorName = player.getName();
                    service.playerReply(ticket, actorId, actorName, text)
                            .whenComplete((ignored, error) -> sync(() -> {
                                if (error != null) player.sendMessage(Component.text("Antwort fehlgeschlagen: " + root(error)));
                                openDetail(player, ticket.id(), false);
                            }));
                }));
    }

    private void staffActions(Player player, SecureGuiHolder holder, Ticket ticket) {
        if (ticket.assigneeUuid() == null) {
            gui.button(holder, 45, gui.item(Material.LIME_DYE, "Übernehmen"), Permissions.TICKET_CLAIM, "claim", event -> {
                StaffRank rank = ranks.rank(player).orElse(null);
                if (rank == null) return;
                UUID actorId = player.getUniqueId();
                service.claim(ticket.id(), actorId, rank, ticket.revision())
                        .whenComplete((ignored, error) -> sync(() -> finish(player, ticket.id(), error)));
            });
        } else if (ticket.assigneeUuid().equals(player.getUniqueId())) {
            gui.button(holder, 45, gui.item(Material.GRAY_DYE, "Freigeben"), Permissions.TICKET_CLAIM, "release",
                    event -> {
                        UUID actorId = player.getUniqueId();
                        service.release(ticket.id(), actorId, ticket.revision())
                                .whenComplete((ignored, error) -> sync(() -> finish(player, ticket.id(), error)));
                    });
        }

        gui.button(holder, 46, gui.item(Material.FEATHER, "Antworten"), Permissions.TICKET_REPLY, "reply",
                event -> prompts.ask(player, "Staff-Antwort eingeben", text -> {
                    UUID actorId = player.getUniqueId();
                    String actorName = player.getName();
                    service.staffReply(ticket, actorId, actorName, text)
                            .whenComplete((ignored, error) -> sync(() -> finish(player, ticket.id(), error)));
                }));

        gui.button(holder, 47, gui.item(Material.WRITABLE_BOOK, "Interne Notiz"), Permissions.TICKET_REPLY, "note",
                event -> prompts.ask(player, "Interne Notiz eingeben", text -> {
                    UUID actorId = player.getUniqueId();
                    String actorName = player.getName();
                    service.internalNote(ticket.id(), actorId, actorName, text)
                            .whenComplete((ignored, error) -> sync(() -> finish(player, ticket.id(), error)));
                }));

        gui.button(holder, 48, gui.item(Material.GOLD_INGOT, "Eskalieren"), Permissions.TICKET_ESCALATE, "escalate", event -> {
            StaffRank rank = ranks.rank(player).orElse(null);
            if (rank == null) return;
            UUID actorId = player.getUniqueId();
            String actorName = player.getName();
            service.escalate(ticket, actorId, actorName, rank)
                    .whenComplete((ignored, error) -> sync(() -> finish(player, ticket.id(), error)));
        });

        if (ticket.status() != TicketStatus.CLOSED && ticket.status() != TicketStatus.RESOLVED
                && ticket.status() != TicketStatus.REJECTED) {
            gui.button(holder, 44, gui.item(Material.CLOCK, "Warte auf Spieler"), Permissions.TICKET_CLOSE,
                    "waiting", event -> changeStatus(player, ticket, TicketStatus.WAITING_FOR_PLAYER));
        }

        if (ticket.status() == TicketStatus.CLOSED || ticket.status() == TicketStatus.RESOLVED || ticket.status() == TicketStatus.REJECTED) {
            gui.button(holder, 50, gui.item(Material.ENDER_EYE, "Wieder öffnen"), Permissions.TICKET_REOPEN, "reopen",
                    event -> changeStatus(player, ticket, TicketStatus.OPEN));
        } else {
            gui.button(holder, 50, gui.item(Material.EMERALD, "Gelöst"), Permissions.TICKET_CLOSE, "resolve",
                    event -> changeStatus(player, ticket, TicketStatus.RESOLVED));
            gui.button(holder, 51, gui.item(Material.RED_DYE, "Ablehnen"), Permissions.TICKET_CLOSE, "reject",
                    event -> changeStatus(player, ticket, TicketStatus.REJECTED));
            gui.button(holder, 52, gui.item(Material.BARRIER, "Schließen"), Permissions.TICKET_CLOSE, "close",
                    event -> changeStatus(player, ticket, TicketStatus.CLOSED));
        }
        gui.button(holder, 53, gui.item(Material.PLAYER_HEAD, "Neu zuweisen"), Permissions.TICKET_REASSIGN,
                "reassign", event -> openReassign(player, ticket));
    }

    private void changeStatus(Player player, Ticket ticket, TicketStatus status) {
        UUID actorId = player.getUniqueId();
        String actorName = player.getName();
        StaffRank actorRank = ranks.rank(player).orElse(null);
        if (actorRank == null) return;
        boolean override = player.hasPermission(Permissions.TICKET_OVERRIDE);
        service.status(ticket, actorId, actorName, actorRank, override, status)
                .whenComplete((ignored, error) -> sync(() -> finish(player, ticket.id(), error)));
    }

    private void openReassign(Player player, Ticket ticket) {
        StaffRank actorRank = ranks.rank(player).orElse(null);
        if (actorRank == null) return;
        io.execute(() -> {
            List<ReassignCandidate> candidates = new ArrayList<>();
            for (PresenceRecord presence : repos.presence.staffOnline()) {
                StaffRank rank = repos.presence.staffRank(presence.playerUuid())
                        .map(value -> {
                            try { return StaffRank.parse(value); }
                            catch (Exception ignored) { return null; }
                        })
                        .orElse(null);
                if (rank == null) continue;
                boolean vanished = repos.staffStates.find(presence.playerUuid()).map(s -> s.vanished()).orElse(false);
                if (vanished && rank.level() > actorRank.level()) continue;
                candidates.add(new ReassignCandidate(presence, rank, vanished));
            }
            sync(() -> renderReassign(player, ticket, actorRank, candidates));
        });
    }

    private void renderReassign(Player player, Ticket ticket, StaffRank actorRank, List<ReassignCandidate> candidates) {
        if (!player.hasPermission(Permissions.TICKET_REASSIGN)) return;
        SecureGuiHolder holder = gui.create(player, 54, "Ticket neu zuweisen");
        int slot = 0;
        for (ReassignCandidate candidate : candidates) {
            if (slot >= 45) break;
            PresenceRecord presence = candidate.presence();
            StaffRank targetRank = candidate.rank();
            if (targetRank.level() < ticket.minimumRank().level()) continue;
            if (targetRank.level() > actorRank.level() && !player.hasPermission(Permissions.TICKET_OVERRIDE)) continue;
            gui.button(holder, slot++, gui.item(Material.PLAYER_HEAD, presence.playerName(),
                            "Server: " + presence.serverName(), "Rang: " + targetRank.displayName(),
                            candidate.vanished() ? "Vanish: AN" : "Vanish: AUS"),
                    Permissions.TICKET_REASSIGN, "assign-" + presence.playerUuid(),
                    event -> prompts.ask(player, "Grund für Neuzuweisung", reason -> {
                        UUID actorId = player.getUniqueId();
                        String actorName = player.getName();
                        boolean override = player.hasPermission(Permissions.TICKET_OVERRIDE);
                        service.reassign(ticket, actorId, actorName, actorRank,
                                        presence.playerUuid(), targetRank, override, reason)
                                .whenComplete((ignored, error) -> sync(() -> finish(player, ticket.id(), error)));
                    }));
        }
        gui.button(holder, 49, gui.item(Material.ARROW, "Zurück"), null, "back",
                event -> openDetail(player, ticket.id(), true));
        gui.open(player, holder);
    }

    private void finish(Player player, long id, Throwable error) {
        if (error != null) player.sendMessage(Component.text("Aktion fehlgeschlagen: " + root(error)));
        openDetail(player, id, true);
    }

    private void loading(Player player, String text) {
        SecureGuiHolder holder = gui.create(player, 27, "StaffCore");
        holder.getInventory().setItem(13, gui.item(Material.CLOCK, text));
        gui.open(player, holder);
    }

    private static void sync(Runnable runnable) {
        Bukkit.getScheduler().runTask(JavaPlugin.getProvidingPlugin(TicketGui.class), runnable);
    }

    private static Material material(TicketPriority priority) {
        return switch (priority) {
            case LOW -> Material.LIME_DYE;
            case NORMAL -> Material.PAPER;
            case HIGH -> Material.ORANGE_DYE;
            case CRITICAL -> Material.REDSTONE_BLOCK;
        };
    }

    private static String display(TicketQueueFilter filter) {
        return switch (filter) {
            case OPEN -> "Offen";
            case ASSIGNED_TO_ME -> "Mir zugewiesen";
            case UNASSIGNED -> "Unzugewiesen";
            case HIGH -> "Hohe Priorität";
            case CRITICAL -> "Kritisch";
            case ESCALATED -> "Eskaliert";
            case WAITING_FOR_PLAYER -> "Warte auf Spieler";
            case RESOLVED -> "Gelöst";
            case CLOSED -> "Geschlossen";
            case REJECTED -> "Abgelehnt";
            case HISTORY -> "Verlauf";
        };
    }

    private static String shortUuid(UUID uuid) { return uuid.toString().substring(0, 8); }
    private static String clip(String value, int length) {
        if (value == null) return "";
        return value.length() <= length ? value : value.substring(0, Math.max(0, length - 1)) + "…";
    }
    private static String root(Throwable error) {
        while (error.getCause() != null) error = error.getCause();
        return error.getMessage() == null ? error.getClass().getSimpleName() : error.getMessage();
    }
}
