package de.yolan.staffcore.paper.config;

import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.common.ticket.PriorityConfig;
import de.yolan.staffcore.common.ticket.TicketCategory;
import de.yolan.staffcore.common.ticket.TicketPriority;
import de.yolan.staffcore.common.util.DurationParser;
import de.yolan.staffcore.data.DatabaseConfig;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Collection;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import org.yaml.snakeyaml.Yaml;

public final class ConfigLoader {
    private ConfigLoader() {}

    @SuppressWarnings("unchecked")
    public static PaperConfig load(Path directory) throws IOException {
        Files.createDirectories(directory);
        Path file = directory.resolve("config.yml");
        if (Files.notExists(file)) {
            try (InputStream input = ConfigLoader.class.getResourceAsStream("/config.yml")) {
                if (input == null) throw new IOException("embedded config.yml missing");
                Files.copy(input, file);
            }
        }

        Map<String, Object> root;
        try (Reader reader = Files.newBufferedReader(file)) {
            root = new Yaml().load(reader);
        }
        if (root == null) throw new IllegalArgumentException("config.yml is empty");

        int version = integer(root, "config-version", 0);
        if (version != 1) throw new IllegalArgumentException("Unsupported config-version: " + version);

        Map<String, Object> database = map(root, "database");
        Map<String, Object> bridge = map(root, "bridge");
        Map<String, Object> messages = map(root, "messages");
        Map<String, Object> gui = map(root, "gui");
        Map<String, Object> staffMode = map(root, "staffmode");
        Map<String, Object> vanish = map(root, "vanish");
        Map<String, Object> freeze = map(root, "freeze");
        Map<String, Object> freezeFakeBody = map(freeze, "fake-body");
        Map<String, Object> punishments = map(root, "punishments");
        Map<String, Object> tickets = map(root, "tickets");
        Map<String, Object> priority = map(root, "priority");
        Map<String, Object> routing = map(root, "routing");
        Map<String, Object> notifications = map(root, "notifications");
        Map<String, Object> privacy = map(root, "privacy");
        Map<String, Object> logging = map(root, "logging");
        Map<String, Object> integrations = map(root, "integrations");
        Map<String, Object> maintenance = map(integrations, "maintenancecore");
        Map<String, Object> runtime = map(root, "runtime");
        Map<String, Object> recovery = map(root, "recovery");

        requireValue(routing, "authority", "velocity");
        requireValue(runtime, "db-io-threading", "virtual");

        String password = envOr(str(database, "password", ""), "STAFFCORE_DB_PASSWORD");
        String secret = envOr(str(bridge, "secret", ""), "STAFFCORE_BRIDGE_SECRET");
        String server = envOr(str(root, "server-name", null), "STAFFCORE_SERVER_NAME");

        DatabaseConfig databaseConfig = new DatabaseConfig(
                str(database, "jdbc-url", null),
                str(database, "username", null),
                password,
                integer(database, "pool-size", 6),
                integer(database, "connection-timeout-ms", 5000));

        return new PaperConfig(
                version,
                databaseConfig,
                secret,
                server,
                str(messages, "locale", "de_DE"),
                str(messages, "system-prefix", "<dark_gray>[<gold>StaffCore</gold>]</dark_gray> "),
                integer(gui, "page-size", 45),
                bool(gui, "dangerous-actions-require-confirmation", true),
                str(staffMode, "gamemode", "SPECTATOR"),
                bool(staffMode, "flight", true),
                bool(staffMode, "recovery-on-join", true),
                bool(vanish, "fake-join-leave", true),
                bool(vanish, "refresh-after-world-change", true),
                stringSet(freeze.get("allowed-commands")),
                bool(freezeFakeBody, "enabled", false),
                stringSet(punishments.get("muted-command-aliases")),
                priorityConfig(priority),
                duration(tickets, "create-cooldown", "30s"),
                integer(tickets, "max-open-per-player", 5),
                duration(tickets, "duplicate-window", "5m"),
                integer(tickets, "max-description-length", 4096),
                integer(tickets, "max-message-length", 4096),
                bool(notifications, "staff-join-overview", true),
                integer(notifications, "max-inbox-page", 100),
                bool(privacy, "show-ip-only-with-permission", true),
                bool(privacy, "persist-ip-addresses", false),
                bool(logging, "audit-sensitive-ip-views", true),
                integer(logging, "max-payload-chars", 8192),
                bool(maintenance, "enabled", false),
                bool(maintenance, "required", false),
                bool(runtime, "degraded-mode", true),
                bool(recovery, "fail-closed-for-critical-mutations", true));
    }

    private static PriorityConfig priorityConfig(Map<String, Object> configured) {
        PriorityConfig defaults = PriorityConfig.defaults();
        Map<TicketCategory, Integer> categoryWeights = new EnumMap<>(TicketCategory.class);
        categoryWeights.putAll(defaults.categoryWeights());
        readEnumIntMap(map(configured, "category-weights"), TicketCategory.class, categoryWeights);

        Map<String, Integer> subcategoryWeights = new LinkedHashMap<>(defaults.subcategoryWeights());
        for (Map.Entry<String, Object> entry : map(configured, "subcategory-weights").entrySet()) {
            int value = Integer.parseInt(String.valueOf(entry.getValue()));
            if (value < 0 || value > 1000) throw new IllegalArgumentException("invalid priority weight: " + entry.getKey());
            subcategoryWeights.put(entry.getKey().toLowerCase(Locale.ROOT), value);
        }

        Map<TicketCategory, StaffRank> categoryMin = new EnumMap<>(TicketCategory.class);
        categoryMin.putAll(defaults.categoryMinRank());
        for (Map.Entry<String, Object> entry : map(configured, "category-min-rank").entrySet()) {
            categoryMin.put(TicketCategory.valueOf(normalizeEnum(entry.getKey())), StaffRank.parse(String.valueOf(entry.getValue())));
        }

        Map<TicketPriority, StaffRank> priorityMin = new EnumMap<>(TicketPriority.class);
        priorityMin.putAll(defaults.priorityMinRank());
        for (Map.Entry<String, Object> entry : map(configured, "priority-min-rank").entrySet()) {
            priorityMin.put(TicketPriority.valueOf(normalizeEnum(entry.getKey())), StaffRank.parse(String.valueOf(entry.getValue())));
        }

        Map<String, Object> age = map(configured, "age-escalation");
        Map<String, Object> thresholds = map(configured, "thresholds");
        Map<String, Object> factors = map(configured, "factors");
        return new PriorityConfig(
                Map.copyOf(categoryWeights),
                Map.copyOf(subcategoryWeights),
                integer(factors, "similar-report-weight", defaults.similarReportWeight()),
                integer(factors, "target-report-weight", defaults.targetReportWeight()),
                integer(factors, "server-wide-weight", defaults.serverWideWeight()),
                integer(factors, "staff-escalation-weight", defaults.staffEscalationWeight()),
                integer(factors, "reopen-weight", defaults.reopenWeight()),
                integer(factors, "freeze-weight", defaults.freezeWeight()),
                integer(factors, "known-outage-weight", defaults.knownOutageWeight()),
                integer(age, "every-minutes", defaults.ageEveryMinutes()),
                integer(age, "add-score", defaults.ageAddScore()),
                integer(thresholds, "high", defaults.highThreshold()),
                integer(thresholds, "critical", defaults.criticalThreshold()),
                Map.copyOf(categoryMin),
                Map.copyOf(priorityMin));
    }

    private static <E extends Enum<E>> void readEnumIntMap(
            Map<String, Object> source, Class<E> type, Map<E, Integer> target) {
        for (Map.Entry<String, Object> entry : source.entrySet()) {
            int value = Integer.parseInt(String.valueOf(entry.getValue()));
            if (value < 0 || value > 1000) throw new IllegalArgumentException("invalid priority weight: " + entry.getKey());
            target.put(Enum.valueOf(type, normalizeEnum(entry.getKey())), value);
        }
    }

    private static String normalizeEnum(String value) {
        return value.trim().replace('-', '_').replace(' ', '_').toUpperCase(Locale.ROOT);
    }

    private static Duration duration(Map<String, Object> map, String key, String fallback) {
        return DurationParser.parse(str(map, key, fallback))
                .orElseThrow(() -> new IllegalArgumentException(key + " cannot be permanent"));
    }

    @SuppressWarnings("unchecked")
    private static Map<String, Object> map(Map<String, Object> source, String key) {
        Object value = source == null ? null : source.get(key);
        return value instanceof Map<?, ?> raw ? (Map<String, Object>) raw : new LinkedHashMap<>();
    }

    private static String str(Map<String, Object> source, String key, String fallback) {
        Object value = source == null ? null : source.get(key);
        return value == null ? fallback : String.valueOf(value);
    }

    private static int integer(Map<String, Object> source, String key, int fallback) {
        Object value = source == null ? null : source.get(key);
        return value == null ? fallback : Integer.parseInt(String.valueOf(value));
    }

    private static boolean bool(Map<String, Object> source, String key, boolean fallback) {
        Object value = source == null ? null : source.get(key);
        return value == null ? fallback : Boolean.parseBoolean(String.valueOf(value));
    }

    private static Set<String> stringSet(Object raw) {
        Set<String> values = new LinkedHashSet<>();
        if (raw instanceof Collection<?> collection) {
            for (Object value : collection) {
                String normalized = String.valueOf(value).trim().toLowerCase(Locale.ROOT);
                if (!normalized.isEmpty()) values.add(normalized);
            }
        }
        return values;
    }

    private static void requireValue(Map<String, Object> source, String key, String expected) {
        String actual = str(source, key, expected);
        if (!expected.equalsIgnoreCase(actual)) {
            throw new IllegalArgumentException(key + " must be '" + expected + "' but was '" + actual + "'");
        }
    }

    private static String envOr(String configured, String key) {
        String environment = System.getenv(key);
        return environment != null && !environment.isBlank() ? environment : configured;
    }
}
