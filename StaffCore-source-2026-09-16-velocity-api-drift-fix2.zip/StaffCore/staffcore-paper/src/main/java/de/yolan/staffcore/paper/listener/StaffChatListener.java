package de.yolan.staffcore.paper.listener;

import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.StaffChatPayload;
import de.yolan.staffcore.paper.config.PaperConfig;
import de.yolan.staffcore.paper.service.BridgeClient;
import de.yolan.staffcore.paper.service.PaperRankService;
import de.yolan.staffcore.paper.service.ServerStateCache;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;

public final class StaffChatListener implements Listener {
    private final JavaPlugin plugin;
    private final ServerStateCache cache;
    private final PaperRankService ranks;
    private final PaperConfig config;
    private final BridgeClient bridge;

    public StaffChatListener(
            JavaPlugin plugin,
            ServerStateCache cache,
            PaperRankService ranks,
            PaperConfig config,
            BridgeClient bridge) {
        this.plugin = plugin;
        this.cache = cache;
        this.ranks = ranks;
        this.config = config;
        this.bridge = bridge;
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void chat(AsyncChatEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        boolean toggled = cache.staff(playerId).map(state -> state.staffChat()).orElse(false);
        if (!toggled) return;

        // The event may be asynchronous. Cancel there, then do all Bukkit/permission work on the main thread.
        event.setCancelled(true);
        String text = PlainTextComponentSerializer.plainText().serialize(event.message());
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player player = Bukkit.getPlayer(playerId);
            if (player == null) return;
            if (!player.hasPermission(Permissions.STAFFCHAT_USE)) {
                player.sendMessage(Component.text("StaffChat nicht gesendet: Permission fehlt."));
                return;
            }
            String rank = ranks.rank(player).map(StaffRank::displayName).orElse("Staff");
            bridge.send(
                    MessageType.STAFFCHAT_MESSAGE,
                    playerId,
                    0,
                    new StaffChatPayload(playerId, player.getName(), rank, config.serverName(), text));
        });
    }
}
