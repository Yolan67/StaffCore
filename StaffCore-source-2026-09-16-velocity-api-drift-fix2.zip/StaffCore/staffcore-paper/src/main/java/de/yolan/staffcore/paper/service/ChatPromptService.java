package de.yolan.staffcore.paper.service;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Consumer;

public final class ChatPromptService implements Listener {
    private record Prompt(String label, Instant expires, Consumer<String> callback) {}

    private final JavaPlugin plugin;
    private final Map<UUID, Prompt> prompts = new ConcurrentHashMap<>();

    public ChatPromptService(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void ask(Player player, String label, Consumer<String> callback) {
        UUID playerId = player.getUniqueId();
        prompts.put(playerId, new Prompt(label, Instant.now().plusSeconds(120), callback));
        player.closeInventory();
        player.sendMessage(Component.text(label + " (zum Abbrechen: cancel)"));
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            Prompt prompt = prompts.get(playerId);
            if (prompt != null && prompt.expires().isBefore(Instant.now()) && prompts.remove(playerId, prompt)) {
                if (player.isOnline()) player.sendMessage(Component.text("Eingabe abgelaufen."));
            }
        }, 20L * 121);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void chat(AsyncChatEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        Prompt prompt = prompts.remove(playerId);
        if (prompt == null) return;
        event.setCancelled(true);

        String text = PlainTextComponentSerializer.plainText().serialize(event.message()).strip();
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player player = Bukkit.getPlayer(playerId);
            if (player == null) return;
            if (text.equalsIgnoreCase("cancel")) {
                player.sendMessage(Component.text("Eingabe abgebrochen."));
                return;
            }
            if (prompt.expires().isBefore(Instant.now())) {
                player.sendMessage(Component.text("Eingabe abgelaufen."));
                return;
            }
            try {
                prompt.callback().accept(text);
            } catch (Exception ex) {
                plugin.getLogger().warning("StaffCore prompt callback failed for " + playerId + ": " + ex);
                player.sendMessage(Component.text("Eingabe konnte nicht verarbeitet werden."));
            }
        });
    }

    public void cancel(UUID playerId) {
        prompts.remove(playerId);
    }
}
