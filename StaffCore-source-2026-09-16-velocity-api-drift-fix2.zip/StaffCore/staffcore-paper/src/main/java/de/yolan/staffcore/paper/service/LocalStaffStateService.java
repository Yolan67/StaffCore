package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.model.FreezeRecord;
import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.StatePayload;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.paper.config.PaperConfig;
import java.util.ConcurrentModificationException;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class LocalStaffStateService {
    private final JavaPlugin plugin;
    private final Repositories repositories;
    private final Executor io;
    private final ServerStateCache cache;
    private final BridgeClient bridge;
    private final PaperConfig config;
    private final PaperAuditService audit;

    public LocalStaffStateService(
            JavaPlugin plugin,
            Repositories repositories,
            Executor io,
            ServerStateCache cache,
            BridgeClient bridge,
            PaperConfig config,
            PaperAuditService audit) {
        this.plugin = plugin;
        this.repositories = repositories;
        this.io = io;
        this.cache = cache;
        this.bridge = bridge;
        this.config = config;
        this.audit = audit;
    }

    public void toggleVanish(Player player) {
        if (!player.hasPermission(Permissions.VANISH)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        boolean current = cache.staff(player.getUniqueId()).map(StaffPersistentState::vanished).orElse(false);
        setVanish(player, !current).exceptionally(error -> {
            notifyFailure(player.getUniqueId(), "Vanish", error);
            return null;
        });
    }

    public void toggleStaffChat(Player player) {
        if (!player.hasPermission(Permissions.STAFFCHAT_USE)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        boolean current = cache.staff(player.getUniqueId()).map(StaffPersistentState::staffChat).orElse(false);
        setStaffChat(player, !current).exceptionally(error -> {
            notifyFailure(player.getUniqueId(), "StaffChat", error);
            return null;
        });
    }

    public CompletableFuture<StaffPersistentState> setVanish(Player player, boolean enabled) {
        return setSafely(player, true, enabled);
    }

    public CompletableFuture<StaffPersistentState> setStaffChat(Player player, boolean enabled) {
        return setSafely(player, false, enabled);
    }

    private CompletableFuture<StaffPersistentState> setSafely(Player player, boolean vanish, boolean enabled) {
        if (Bukkit.isPrimaryThread()) return setFromMain(player, vanish, enabled);
        CompletableFuture<StaffPersistentState> result = new CompletableFuture<>();
        Bukkit.getScheduler().runTask(plugin, () -> setFromMain(player, vanish, enabled)
                .whenComplete((value, error) -> {
                    if (error != null) result.completeExceptionally(error);
                    else result.complete(value);
                }));
        return result;
    }

    private CompletableFuture<StaffPersistentState> setFromMain(Player player, boolean vanish, boolean enabled) {
        UUID playerId = player.getUniqueId();
        String playerName = player.getName();
        String serverName = config.serverName();
        return CompletableFuture.supplyAsync(() -> {
            for (int attempt = 0; attempt < 3; attempt++) {
                StaffPersistentState current = repositories.staffStates.getOrCreate(playerId);
                Boolean vanishValue = vanish ? enabled : null;
                Boolean staffChatValue = vanish ? null : enabled;
                var updated = repositories.staffStates.compareAndSet(
                        playerId, current.revision(), vanishValue, staffChatValue);
                if (updated.isEmpty()) continue;

                StaffPersistentState state = updated.get();
                cache.putStaff(playerId, state);
                boolean frozen = cache.freeze(playerId).isPresent();
                String freezeReason = cache.freeze(playerId).map(FreezeRecord::reason).orElse(null);
                boolean staffMode = cache.staffMode(playerId).isPresent();

                audit.append(
                        playerId,
                        playerName,
                        playerId,
                        serverName,
                        vanish ? "VANISH_TOGGLE" : "STAFFCHAT_TOGGLE",
                        "{\"enabled\":" + (vanish ? current.vanished() : current.staffChat())
                                + ",\"revision\":" + current.revision() + "}",
                        "{\"enabled\":" + enabled + ",\"revision\":" + state.revision() + "}");

                bridge.send(
                        vanish ? MessageType.VANISH_CHANGED : MessageType.STAFFCHAT_CHANGED,
                        playerId,
                        state.revision(),
                        new StatePayload(
                                playerId,
                                state.vanished(),
                                state.staffChat(),
                                frozen,
                                freezeReason,
                                staffMode,
                                serverName));

                Bukkit.getScheduler().runTask(plugin, () -> {
                    Player online = Bukkit.getPlayer(playerId);
                    if (online != null) {
                        online.sendMessage(Component.text((vanish ? "Vanish: " : "StaffChat: ")
                                + (enabled ? "AN" : "AUS")));
                    }
                });
                return state;
            }
            throw new ConcurrentModificationException("State konnte wegen paralleler Änderung nicht aktualisiert werden.");
        }, io);
    }

    private void notifyFailure(UUID playerId, String feature, Throwable error) {
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player online = Bukkit.getPlayer(playerId);
            if (online == null) return;
            Throwable root = error;
            while (root.getCause() != null) root = root.getCause();
            String message = root.getMessage();
            if (message == null || message.isBlank()) message = root.getClass().getSimpleName();
            online.sendMessage(Component.text(feature + " konnte nicht sicher geändert werden: "
                    + message.substring(0, Math.min(160, message.length()))));
        });
    }
}
