package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.model.FreezeRecord;
import de.yolan.staffcore.common.model.StaffModeSnapshotRecord;
import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.StaffModeRoutePayload;
import de.yolan.staffcore.common.protocol.StatePayload;
import de.yolan.staffcore.common.state.StaffModeState;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.data.StaffModeBackendRepository;
import de.yolan.staffcore.paper.config.PaperConfig;
import de.yolan.staffcore.paper.snapshot.PlayerSnapshot;
import de.yolan.staffcore.paper.snapshot.SnapshotCodec;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.time.Instant;
import java.util.EnumSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;

public final class StaffModeService {
    private final JavaPlugin plugin;
    private final PaperConfig config;
    private final Repositories repositories;
    private final Executor executor;
    private final ServerStateCache cache;
    private final BridgeClient bridge;
    private final SnapshotCodec codec = new SnapshotCodec();
    private final FreezeService freeze;
    private final PaperAuditService audit;
    private final NamespacedKey actionKey;
    private final Map<UUID, StaffModeBackendRepository.BackendSnapshot> localForeign = new ConcurrentHashMap<>();
    private final Set<UUID> operations = ConcurrentHashMap.newKeySet();

    public StaffModeService(
            JavaPlugin plugin,
            PaperConfig config,
            Repositories repositories,
            Executor executor,
            ServerStateCache cache,
            BridgeClient bridge,
            FreezeService freeze,
            PaperAuditService audit) {
        this.plugin = plugin;
        this.config = config;
        this.repositories = repositories;
        this.executor = executor;
        this.cache = cache;
        this.bridge = bridge;
        this.freeze = freeze;
        this.audit = audit;
        this.actionKey = new NamespacedKey(plugin, "action");
    }

    public boolean active(UUID playerId) {
        return cache.staffMode(playerId).map(snapshot -> snapshot.state() != StaffModeState.RESTORED).orElse(false);
    }

    public void forceRestore(Player player) {
        UUID playerId = player.getUniqueId();
        if (!operations.add(playerId)) return;
        if (active(playerId)) disable(playerId);
        else operations.remove(playerId);
    }

    public void toggle(Player player) {
        if (!player.hasPermission(Permissions.STAFFMODE)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        UUID playerId = player.getUniqueId();
        if (!operations.add(playerId)) {
            player.sendMessage(Component.text("StaffMode-Aktion läuft bereits."));
            return;
        }
        if (active(playerId)) disable(playerId);
        else enable(player);
    }

    private void enable(Player player) {
        // Capture every Bukkit value before dispatching DB work.
        UUID playerId = player.getUniqueId();
        String playerName = player.getName();
        PlayerSnapshot snapshot = codec.capture(player);
        byte[] payload = codec.encode(snapshot);
        String checksum = SnapshotCodec.checksum(payload);
        Location location = player.getLocation();
        StaffModeSnapshotRecord record = new StaffModeSnapshotRecord(
                UUID.randomUUID(),
                playerId,
                SnapshotCodec.VERSION,
                StaffModeState.CAPTURED,
                config.serverName(),
                location.getWorld().getName(),
                location.getX(),
                location.getY(),
                location.getZ(),
                location.getYaw(),
                location.getPitch(),
                payload,
                checksum,
                0,
                Instant.now(),
                Instant.now());

        executor.execute(() -> {
            try {
                StaffModeSnapshotRecord saved = repositories.staffMode.create(record);
                sync(() -> {
                    Player online = Bukkit.getPlayer(playerId);
                    if (online == null) {
                        operations.remove(playerId);
                        return;
                    }
                    // Snapshot is committed before the first inventory/game-mode mutation.
                    try {
                        applyKit(online);
                        transitionCapturedToActive(playerId, playerName, saved);
                    } catch (RuntimeException mutationFailure) {
                        executor.execute(() -> recoverActivationConflict(playerId, saved));
                    }
                });
            } catch (Exception ex) {
                operations.remove(playerId);
                message(playerId, "StaffMode konnte nicht sicher aktiviert werden: " + safe(ex));
            }
        });
    }

    private void transitionCapturedToActive(UUID playerId, String playerName, StaffModeSnapshotRecord saved) {
        executor.execute(() -> {
            try {
                var active = repositories.staffMode.transition(
                        saved.sessionId(), saved.revision(), StaffModeState.CAPTURED, StaffModeState.ACTIVE);
                if (active.isPresent()) {
                    StaffModeSnapshotRecord state = active.get();
                    cache.putStaffMode(playerId, state);
                    audit.append(playerId, playerName, playerId, config.serverName(), "STAFFMODE_ENABLE", null,
                            "{\"session\":\"" + saved.sessionId() + "\"}");
                    bridge.send(MessageType.STAFFMODE_CHANGED, playerId, state.revision(), statePayload(playerId, true));
                    operations.remove(playerId);
                    message(playerId, "StaffMode aktiviert.");
                } else {
                    recoverActivationConflict(playerId, saved);
                }
            } catch (Exception ex) {
                recoverActivationConflict(playerId, saved);
            }
        });
    }

    private void recoverActivationConflict(UUID playerId, StaffModeSnapshotRecord saved) {
        try {
            StaffModeSnapshotRecord current = repositories.staffMode.findActive(playerId).orElse(saved);
            if (current.state() == StaffModeState.CAPTURED) {
                current = repositories.staffMode.transition(
                                current.sessionId(), current.revision(), StaffModeState.CAPTURED, StaffModeState.RECOVERY_REQUIRED)
                        .orElseThrow(() -> new IllegalStateException("recovery transition conflict"));
            } else if (current.state() == StaffModeState.ACTIVE) {
                current = repositories.staffMode.transition(
                                current.sessionId(), current.revision(), StaffModeState.ACTIVE, StaffModeState.RECOVERY_REQUIRED)
                        .orElseThrow(() -> new IllegalStateException("recovery transition conflict"));
            }
            cache.putStaffMode(playerId, current);
            StaffModeSnapshotRecord recovery = current;
            sync(() -> {
                Player online = Bukkit.getPlayer(playerId);
                if (online == null) {
                    operations.remove(playerId);
                    return;
                }
                beginRestore(playerId, recovery);
            });
        } catch (Exception ex) {
            operations.remove(playerId);
            message(playerId,
                    "StaffMode-Aktivierung konnte nicht abgeschlossen werden; Snapshot bleibt zur manuellen Recovery erhalten: "
                            + safe(ex));
        }
    }

    private void disable(UUID playerId) {
        StaffModeSnapshotRecord initial = cache.staffMode(playerId).orElse(null);
        if (initial == null) {
            operations.remove(playerId);
            return;
        }
        executor.execute(() -> {
            try {
                StaffModeSnapshotRecord current = initial;
                if (current.state() == StaffModeState.ACTIVE) {
                    current = repositories.staffMode.transition(
                                    current.sessionId(), current.revision(), StaffModeState.ACTIVE, StaffModeState.RESTORE_REQUESTED)
                            .orElseThrow(() -> new IllegalStateException("state conflict"));
                    cache.putStaffMode(playerId, current);
                }
                if (!config.serverName().equalsIgnoreCase(current.originServer())) {
                    if (current.state() == StaffModeState.RESTORE_REQUESTED) {
                        current = repositories.staffMode.transition(
                                        current.sessionId(), current.revision(), StaffModeState.RESTORE_REQUESTED,
                                        StaffModeState.ROUTING_TO_ORIGIN)
                                .orElseThrow(() -> new IllegalStateException("routing state conflict"));
                    }
                    cache.putStaffMode(playerId, current);
                    bridge.send(MessageType.STAFFMODE_ROUTE, playerId, current.revision(),
                            new StaffModeRoutePayload(playerId, current.sessionId(), current.originServer()));
                    operations.remove(playerId);
                    message(playerId, "StaffMode wird auf dem Origin-Server sicher beendet.");
                    return;
                }
                StaffModeSnapshotRecord restore = current;
                sync(() -> beginRestore(playerId, restore));
            } catch (Exception ex) {
                operations.remove(playerId);
                message(playerId, "StaffMode-Restore konnte nicht gestartet werden: " + safe(ex));
            }
        });
    }

    private void beginRestore(UUID playerId, StaffModeSnapshotRecord snapshot) {
        executor.execute(() -> {
            try {
                StaffModeSnapshotRecord restoring = snapshot;
                if (snapshot.state() == StaffModeState.CAPTURED) {
                    restoring = repositories.staffMode.transition(snapshot.sessionId(), snapshot.revision(),
                                    StaffModeState.CAPTURED, StaffModeState.RECOVERY_REQUIRED)
                            .orElseThrow(() -> new IllegalStateException("capture recovery transition conflict"));
                    restoring = repositories.staffMode.transition(restoring.sessionId(), restoring.revision(),
                                    StaffModeState.RECOVERY_REQUIRED, StaffModeState.RESTORING)
                            .orElseThrow(() -> new IllegalStateException("capture restore transition conflict"));
                } else if (snapshot.state() == StaffModeState.RESTORE_REQUESTED) {
                    restoring = repositories.staffMode.transition(snapshot.sessionId(), snapshot.revision(),
                                    StaffModeState.RESTORE_REQUESTED, StaffModeState.RESTORING)
                            .orElseThrow(() -> new IllegalStateException("restore transition conflict"));
                } else if (snapshot.state() == StaffModeState.ROUTING_TO_ORIGIN) {
                    restoring = repositories.staffMode.transition(snapshot.sessionId(), snapshot.revision(),
                                    StaffModeState.ROUTING_TO_ORIGIN, StaffModeState.RESTORING)
                            .orElseThrow(() -> new IllegalStateException("restore transition conflict"));
                } else if (snapshot.state() == StaffModeState.RECOVERY_REQUIRED) {
                    restoring = repositories.staffMode.transition(snapshot.sessionId(), snapshot.revision(),
                                    StaffModeState.RECOVERY_REQUIRED, StaffModeState.RESTORING)
                            .orElseThrow(() -> new IllegalStateException("restore transition conflict"));
                }
                StaffModeSnapshotRecord ready = restoring;
                sync(() -> {
                    Player online = Bukkit.getPlayer(playerId);
                    if (online == null) {
                        operations.remove(playerId);
                        return;
                    }
                    safeRestore(online, ready, true);
                });
            } catch (Exception ex) {
                operations.remove(playerId);
                message(playerId, "Restore-State konnte nicht gesperrt werden: " + safe(ex));
            }
        });
    }

    private void safeRestore(Player player, StaffModeSnapshotRecord snapshot, boolean originTeleport) {
        UUID playerId = player.getUniqueId();
        String playerName = player.getName();
        try {
            if (!SnapshotCodec.checksum(snapshot.payload()).equalsIgnoreCase(snapshot.checksum())) {
                throw new SecurityException("snapshot checksum mismatch");
            }
            PlayerSnapshot decoded = codec.decode(snapshot.payload());
            // Deterministic SET restore; never additive. Controlled system teleport bypasses Freeze only for this call.
            freeze.withTeleportBypass(player, () -> codec.restore(player, decoded, originTeleport));
            executor.execute(() -> completeRestore(playerId, playerName, snapshot));
        } catch (Exception ex) {
            player.sendMessage(Component.text("StaffMode-Recovery erforderlich: " + safe(ex)));
            executor.execute(() -> markRecoveryRequired(
                    playerId, playerName, snapshot, "STAFFMODE_RESTORE_APPLY_FAILED", ex));
        }
    }

    private void completeRestore(UUID playerId, String playerName, StaffModeSnapshotRecord snapshot) {
        try {
            var done = repositories.staffMode.transition(
                    snapshot.sessionId(), snapshot.revision(), StaffModeState.RESTORING, StaffModeState.RESTORED);
            if (done.isEmpty()) throw new IllegalStateException("restore completion conflict");
        } catch (Exception ex) {
            markRecoveryRequired(playerId, playerName, snapshot, "STAFFMODE_RESTORE_COMMIT_FAILED", ex);
            message(playerId,
                    "Restore angewendet, DB-Abschluss aber fehlgeschlagen. Snapshot bleibt in Recovery.");
            return;
        }

        try {
            cache.putStaffMode(playerId, null);
            audit.append(playerId, playerName, playerId, config.serverName(), "STAFFMODE_RESTORE", null,
                    "{\"session\":\"" + snapshot.sessionId() + "\"}");
            bridge.send(MessageType.STAFFMODE_CHANGED, playerId, snapshot.revision() + 1, statePayload(playerId, false));
            message(playerId, "StaffMode sicher wiederhergestellt.");
        } catch (Exception ex) {
            // The DB state is already RESTORED. Do not regress it to RECOVERY_REQUIRED because a notification failed.
            plugin.getLogger().warning("StaffMode restore completed in DB but post-restore notification failed for "
                    + playerId + " session=" + snapshot.sessionId() + ": " + safe(ex));
            audit.append(null, "StaffCore System", playerId, config.serverName(),
                    "STAFFMODE_POST_RESTORE_NOTIFY_FAILED", null, recoveryJson(snapshot, ex));
        } finally {
            operations.remove(playerId);
        }
    }

    private void markRecoveryRequired(
            UUID playerId,
            String playerName,
            StaffModeSnapshotRecord snapshot,
            String action,
            Exception cause) {
        try {
            var recovery = repositories.staffMode.transition(
                    snapshot.sessionId(), snapshot.revision(), StaffModeState.RESTORING,
                    StaffModeState.RECOVERY_REQUIRED);
            if (recovery.isPresent()) {
                cache.putStaffMode(playerId, recovery.get());
                plugin.getLogger().warning("StaffMode moved to RECOVERY_REQUIRED for " + playerId
                        + " session=" + snapshot.sessionId() + " after " + action + ": " + safe(cause));
                audit.append(playerId, playerName, playerId, config.serverName(), action,
                        "{\"state\":\"RESTORING\"}", recoveryJson(snapshot, cause));
            } else {
                logRecoveryMarkFailure(playerId, playerName, snapshot, action,
                        new IllegalStateException("RESTORING -> RECOVERY_REQUIRED CAS conflict", cause));
            }
        } catch (Exception markFailure) {
            logRecoveryMarkFailure(playerId, playerName, snapshot, action, markFailure);
        } finally {
            operations.remove(playerId);
        }
    }

    private void logRecoveryMarkFailure(
            UUID playerId,
            String playerName,
            StaffModeSnapshotRecord snapshot,
            String sourceAction,
            Exception failure) {
        plugin.getLogger().severe("CRITICAL: StaffMode recovery marking failed for " + playerId
                + " session=" + snapshot.sessionId() + " source=" + sourceAction + ": " + safe(failure));
        audit.append(null, "StaffCore System", playerId, config.serverName(),
                "STAFFMODE_RECOVERY_MARK_FAILED",
                "{\"sourceAction\":\"" + sourceAction + "\"}", recoveryJson(snapshot, failure));
        message(playerId,
                "KRITISCH: StaffMode-Recovery konnte nicht in der Datenbank markiert werden. Keine weiteren StaffMode-Aktionen ausführen; Admin informieren.");
    }

    private String recoveryJson(StaffModeSnapshotRecord snapshot, Exception exception) {
        return "{\"session\":\"" + snapshot.sessionId() + "\",\"state\":\""
                + snapshot.state() + "\",\"error\":\"" + jsonSafe(safe(exception)) + "\"}";
    }

    private static String jsonSafe(String value) {
        return value.replace("\\", "\\\\").replace("\"", "\\\"")
                .replace("\n", " ").replace("\r", " ");
    }

    public void onJoin(Player player) {
        UUID playerId = player.getUniqueId();
        StaffModeSnapshotRecord snapshot = cache.staffMode(playerId).orElse(null);
        if (snapshot == null) {
            restoreOrphanBackend(player);
            return;
        }
        if (EnumSet.of(
                        StaffModeState.RESTORE_REQUESTED,
                        StaffModeState.ROUTING_TO_ORIGIN,
                        StaffModeState.RESTORING,
                        StaffModeState.RECOVERY_REQUIRED,
                        StaffModeState.CAPTURED)
                .contains(snapshot.state())) {
            if (!config.staffModeRecoveryOnJoin()) {
                player.sendMessage(Component.text("StaffMode-Recovery wartet auf manuelle Freigabe durch berechtigten Staff."));
                return;
            }
            if (config.serverName().equalsIgnoreCase(snapshot.originServer())) {
                if (operations.add(playerId)) beginRestore(playerId, snapshot);
            } else {
                bridge.send(MessageType.STAFFMODE_ROUTE, playerId, snapshot.revision(),
                        new StaffModeRoutePayload(playerId, snapshot.sessionId(), snapshot.originServer()));
            }
            return;
        }
        if (snapshot.state() == StaffModeState.ACTIVE) {
            if (config.serverName().equalsIgnoreCase(snapshot.originServer())) applyKit(player);
            else captureForeignThenKit(player, snapshot);
        }
    }

    private void captureForeignThenKit(Player player, StaffModeSnapshotRecord session) {
        UUID playerId = player.getUniqueId();
        PlayerSnapshot local = codec.capture(player);
        byte[] data = codec.encode(local);
        String checksum = SnapshotCodec.checksum(data);
        executor.execute(() -> {
            try {
                var backend = repositories.staffModeBackends.createIfAbsent(
                        session.sessionId(), playerId, config.serverName(), SnapshotCodec.VERSION, data, checksum);
                localForeign.put(playerId, backend);
                sync(() -> {
                    Player online = Bukkit.getPlayer(playerId);
                    if (online != null) applyKit(online);
                });
            } catch (Exception ex) {
                message(playerId,
                        "StaffMode wurde auf diesem Server NICHT angewendet, da der Sicherheitssnapshot fehlschlug.");
            }
        });
    }

    public void onQuit(Player player) {
        UUID playerId = player.getUniqueId();
        String playerName = player.getName();
        StaffModeBackendRepository.BackendSnapshot backend = localForeign.remove(playerId);
        if (backend == null) return;
        try {
            if (!SnapshotCodec.checksum(backend.payload()).equalsIgnoreCase(backend.checksum())) {
                throw new SecurityException("backend snapshot checksum mismatch");
            }
            // Quit event is still on the server thread: restore the foreign inventory before the player object disappears.
            codec.restore(player, codec.decode(backend.payload()), false);
            executor.execute(() -> markBackendRestored(playerId, playerName, backend, "QUIT_RESTORE"));
        } catch (Exception ex) {
            plugin.getLogger().severe("StaffMode backend restore failed during quit for " + playerId
                    + " session=" + backend.sessionId() + " server=" + backend.serverName() + ": " + safe(ex));
            audit.append(null, "StaffCore System", playerId, config.serverName(),
                    "STAFFMODE_BACKEND_RESTORE_FAILED", null, backendRecoveryJson(backend, ex));
            // Persisted non-RESTORED backend snapshot deliberately remains available for join recovery.
        }
    }

    private void markBackendRestored(
            UUID playerId,
            String playerName,
            StaffModeBackendRepository.BackendSnapshot backend,
            String source) {
        try {
            boolean updated = repositories.staffModeBackends.transition(
                    backend.sessionId(), backend.serverName(), backend.revision(), backend.state(), "RESTORED");
            if (!updated) {
                throw new IllegalStateException("backend snapshot RESTORED CAS conflict");
            }
            audit.append(playerId, playerName, playerId, config.serverName(),
                    "STAFFMODE_BACKEND_RESTORE", null,
                    "{\"session\":\"" + backend.sessionId() + "\",\"source\":\"" + source + "\"}");
        } catch (Exception ex) {
            plugin.getLogger().severe("CRITICAL: StaffMode backend snapshot was applied but could not be marked RESTORED for "
                    + playerId + " session=" + backend.sessionId() + " server=" + backend.serverName() + ": " + safe(ex));
            audit.append(null, "StaffCore System", playerId, config.serverName(),
                    "STAFFMODE_BACKEND_MARK_RESTORED_FAILED", null, backendRecoveryJson(backend, ex));
        }
    }

    private String backendRecoveryJson(StaffModeBackendRepository.BackendSnapshot backend, Exception exception) {
        return "{\"session\":\"" + backend.sessionId() + "\",\"backend\":\""
                + jsonSafe(backend.serverName()) + "\",\"state\":\"" + jsonSafe(backend.state())
                + "\",\"error\":\"" + jsonSafe(safe(exception)) + "\"}";
    }

    private void restoreOrphanBackend(Player player) {
        UUID playerId = player.getUniqueId();
        cache.backendSnapshots(playerId).stream()
                .filter(value -> value.serverName().equalsIgnoreCase(config.serverName()))
                .findFirst()
                .ifPresent(backend -> {
                    try {
                        if (!SnapshotCodec.checksum(backend.payload()).equalsIgnoreCase(backend.checksum())) {
                            throw new SecurityException("checksum");
                        }
                        codec.restore(player, codec.decode(backend.payload()), false);
                        executor.execute(() -> markBackendRestored(playerId, player.getName(), backend, "JOIN_RECOVERY"));
                        player.sendMessage(Component.text("Ein offener StaffMode-Backend-Snapshot wurde wiederhergestellt."));
                    } catch (Exception ex) {
                        plugin.getLogger().severe("StaffMode backend join-recovery failed for " + playerId
                                + " session=" + backend.sessionId() + " server=" + backend.serverName() + ": " + safe(ex));
                        audit.append(null, "StaffCore System", playerId, config.serverName(),
                                "STAFFMODE_BACKEND_RECOVERY_FAILED", null, backendRecoveryJson(backend, ex));
                        player.sendMessage(Component.text("Backend-Inventar-Recovery erforderlich; Staff informieren."));
                    }
                });
    }

    public void applyKit(Player player) {
        PlayerInventory inventory = player.getInventory();
        inventory.clear();
        inventory.setArmorContents(new ItemStack[4]);
        inventory.setItemInOffHand(null);
        player.setItemOnCursor(null);
        ItemStack menu = new ItemStack(Material.NETHER_STAR);
        ItemMeta meta = menu.getItemMeta();
        meta.displayName(Component.text("Staff-Menü"));
        meta.getPersistentDataContainer().set(actionKey, PersistentDataType.STRING, "main-menu");
        menu.setItemMeta(meta);
        inventory.setItem(4, menu);
        GameMode gameMode = GameMode.valueOf(config.staffModeGameMode().toUpperCase(Locale.ROOT));
        player.setGameMode(gameMode);
        player.setAllowFlight(config.staffModeFlight() || gameMode == GameMode.CREATIVE || gameMode == GameMode.SPECTATOR);
        if (player.getAllowFlight()) player.setFlying(true);
    }

    public void startReconciler() {
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Player player : Bukkit.getOnlinePlayers()) {
                UUID playerId = player.getUniqueId();
                if (!active(playerId) || player.hasPermission(Permissions.STAFFMODE)) continue;
                if (operations.add(playerId)) {
                    player.sendMessage(Component.text("StaffMode-Permission verloren; sichere Wiederherstellung wird gestartet."));
                    disable(playerId);
                }
            }
        }, 40L, 40L);
    }

    public NamespacedKey actionKey() {
        return actionKey;
    }

    private StatePayload statePayload(UUID playerId, boolean staffMode) {
        StaffPersistentState persistent = cache.staff(playerId)
                .orElse(new StaffPersistentState(playerId, false, false, 0, Instant.EPOCH));
        FreezeRecord freeze = cache.freeze(playerId).orElse(null);
        return new StatePayload(
                playerId,
                persistent.vanished(),
                persistent.staffChat(),
                freeze != null,
                freeze == null ? null : freeze.reason(),
                staffMode,
                config.serverName());
    }

    private void message(UUID playerId, String text) {
        sync(() -> {
            Player online = Bukkit.getPlayer(playerId);
            if (online != null) online.sendMessage(Component.text(text));
        });
    }

    private void sync(Runnable task) {
        Bukkit.getScheduler().runTask(plugin, task);
    }

    private static String safe(Exception exception) {
        String message = exception.getMessage();
        if (message == null) return exception.getClass().getSimpleName();
        return message.substring(0, Math.min(160, message.length()));
    }
}
