package de.yolan.staffcore.paper.gui;

import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.data.StaffActivityRepository;
import de.yolan.staffcore.paper.service.ChatPromptService;
import de.yolan.staffcore.paper.service.PaperRankService;
import de.yolan.staffcore.paper.service.StaffVisibilityPolicy;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class ActivityGui {
    private final JavaPlugin plugin;
    private final GuiManager gui;
    private final ChatPromptService prompts;
    private final Repositories repos;
    private final Executor io;
    private final PaperRankService ranks;
    private final StaffVisibilityPolicy visibility;

    public ActivityGui(JavaPlugin plugin, GuiManager gui, ChatPromptService prompts, Repositories repos, Executor io,
                       PaperRankService ranks, StaffVisibilityPolicy visibility) {
        this.plugin = plugin;
        this.gui = gui;
        this.prompts = prompts;
        this.repos = repos;
        this.io = io;
        this.ranks = ranks;
        this.visibility = visibility;
    }

    public void promptStaff(Player player) {
        if (!player.hasPermission(Permissions.ACTIVITY_VIEW)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        prompts.ask(player, "Staffname für Activity", name -> {
            StaffRank viewerRank = ranks.rank(player).orElse(null);
            UUID viewerId = player.getUniqueId();
            io.execute(() -> {
                Optional<UUID> id = repos.players.findUuidByName(name);
                boolean visible = id.isPresent() && visibility.canSeePersisted(id.get(), viewerRank);
                sync(() -> {
                    Player current = Bukkit.getPlayer(viewerId);
                    if (current == null) return;
                    if (!visible) current.sendMessage(Component.text("Staff nicht gefunden."));
                    else open(current, id.get(), name, 0);
                });
            });
        });
    }

    public void open(Player player, UUID staff, String display, int page) {
        if (!player.hasPermission(Permissions.ACTIVITY_VIEW)) return;
        boolean details = player.hasPermission(Permissions.ACTIVITY_DETAILS);
        StaffRank viewerRank = ranks.rank(player).orElse(null);
        UUID viewerId = player.getUniqueId();
        io.execute(() -> {
            if (!visibility.canSeePersisted(staff, viewerRank)) {
                sync(() -> {
                    Player current = Bukkit.getPlayer(viewerId);
                    if (current != null) current.sendMessage(Component.text("Staff nicht gefunden."));
                });
                return;
            }
            var counts = repos.activity.counts(staff, Instant.now().minus(30, ChronoUnit.DAYS));
            List<StaffActivityRepository.Entry> recent = details
                    ? repos.activity.recent(staff, page * 36, 36)
                    : List.of();
            sync(() -> {
                Player current = Bukkit.getPlayer(viewerId);
                if (current != null) render(current, staff, display, page, details, counts, recent);
            });
        });
    }

    private void render(Player player, UUID staff, String display, int page, boolean details,
                        List<StaffActivityRepository.Count> counts,
                        List<StaffActivityRepository.Entry> recent) {
        if (!player.hasPermission(Permissions.ACTIVITY_VIEW)) {
            player.closeInventory();
            return;
        }
        boolean stillDetails = details && player.hasPermission(Permissions.ACTIVITY_DETAILS);
        SecureGuiHolder holder = gui.create(player, 54, "Activity: " + display);
        int slot = 0;
        for (var count : counts) {
            if (slot >= 9) break;
            holder.getInventory().setItem(slot++, gui.item(Material.PAPER, count.type(), "30 Tage: " + count.count()));
        }
        if (stillDetails) {
            slot = 9;
            for (var entry : recent) {
                if (slot >= 45) break;
                holder.getInventory().setItem(slot++, gui.item(Material.CLOCK, entry.type(),
                        "Ref: " + Objects.toString(entry.referenceId(), "-"),
                        "Zeit: " + entry.createdAt()));
            }
        } else {
            holder.getInventory().setItem(22, gui.item(Material.BARRIER, "Details verborgen",
                    "Permission: " + Permissions.ACTIVITY_DETAILS));
        }
        if (page > 0) {
            gui.button(holder, 45, gui.item(Material.ARROW, "Zurück"), Permissions.ACTIVITY_VIEW,
                    "prev", event -> open(player, staff, display, page - 1));
        }
        gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null,
                "close", event -> player.closeInventory());
        if (stillDetails && recent.size() == 36) {
            gui.button(holder, 53, gui.item(Material.ARROW, "Weiter"), Permissions.ACTIVITY_DETAILS,
                    "next", event -> open(player, staff, display, page + 1));
        }
        gui.open(player, holder);
    }

    private void sync(Runnable task) {
        Bukkit.getScheduler().runTask(plugin, task);
    }
}
