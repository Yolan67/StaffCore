package de.yolan.staffcore.paper.gui;

import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.common.util.InputPolicy;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.data.StaffNoteRepository;
import de.yolan.staffcore.paper.config.PaperConfig;
import de.yolan.staffcore.paper.service.ChatPromptService;
import de.yolan.staffcore.paper.service.PaperAuditService;
import de.yolan.staffcore.paper.service.PaperRankService;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class NotesGui {
    private final JavaPlugin plugin;
    private final GuiManager gui;
    private final ChatPromptService prompts;
    private final Repositories repos;
    private final Executor io;
    private final PaperAuditService audit;
    private final PaperConfig config;
    private final PaperRankService ranks;

    public NotesGui(JavaPlugin plugin, GuiManager gui, ChatPromptService prompts, Repositories repos, Executor io,
                    PaperAuditService audit, PaperConfig config, PaperRankService ranks) {
        this.plugin = plugin;
        this.gui = gui;
        this.prompts = prompts;
        this.repos = repos;
        this.io = io;
        this.audit = audit;
        this.config = config;
        this.ranks = ranks;
    }

    public void promptTarget(Player player) {
        if (!player.hasPermission(Permissions.NOTES_VIEW)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        prompts.ask(player, "Spielername für Notes", name -> resolve(player, name,
                id -> open(player, id, name, 0, false)));
    }

    public void open(Player player, UUID target, String display, int page, boolean includeArchived) {
        if (!player.hasPermission(Permissions.NOTES_VIEW)) return;
        player.sendMessage(Component.text("Notes werden geladen …"));
        io.execute(() -> {
            var notes = repos.notes.list(target, includeArchived, page * 45, 45);
            Bukkit.getScheduler().runTask(plugin, () -> render(player, target, display, page, includeArchived, notes));
        });
    }

    private void render(Player player, UUID target, String display, int page, boolean includeArchived,
                        java.util.List<StaffNoteRepository.Note> notes) {
        SecureGuiHolder holder = gui.create(player, 54, "Notes: " + display);
        int slot = 0;
        for (StaffNoteRepository.Note note : notes) {
            if (slot >= 45) break;
            var item = gui.item(note.archived() ? Material.GRAY_DYE : Material.WRITABLE_BOOK,
                    "Note #" + note.id(),
                    "Kategorie: " + Objects.toString(note.category(), "-"),
                    "Autor: " + shortUuid(note.author()),
                    clip(note.text(), 90),
                    "Aktualisiert: " + note.updatedAt());
            gui.button(holder, slot++, item, Permissions.NOTES_VIEW, "note-" + note.id(),
                    event -> detailAsync(player, note, target, display));
        }
        if (player.hasPermission(Permissions.NOTES_EDIT)) {
            gui.button(holder, 46, gui.item(Material.LIME_DYE, "Neue Note"), Permissions.NOTES_EDIT,
                    "new", event -> create(player, target, display));
        }
        gui.button(holder, 48, gui.item(Material.COMPARATOR,
                        "Archivierte einschließen: " + includeArchived),
                Permissions.NOTES_VIEW, "archived",
                event -> open(player, target, display, 0, !includeArchived));
        gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null, "close", event -> player.closeInventory());
        if (page > 0) {
            gui.button(holder, 45, gui.item(Material.ARROW, "Zurück"), null, "prev",
                    event -> open(player, target, display, page - 1, includeArchived));
        }
        if (notes.size() == 45) {
            gui.button(holder, 53, gui.item(Material.ARROW, "Weiter"), null, "next",
                    event -> open(player, target, display, page + 1, includeArchived));
        }
        gui.open(player, holder);
    }

    private void detailAsync(Player player, StaffNoteRepository.Note note, UUID target, String display) {
        boolean mayEdit = player.hasPermission(Permissions.NOTES_EDIT);
        boolean override = player.hasPermission(Permissions.TICKET_OVERRIDE);
        UUID viewerId = player.getUniqueId();
        StaffRank viewerRank = ranks.rank(player).orElse(null);
        io.execute(() -> {
            boolean canModify = canModifyOffThread(viewerId, viewerRank, mayEdit, override, note);
            Bukkit.getScheduler().runTask(plugin, () -> detail(player, note, target, display, canModify));
        });
    }

    private void detail(Player player, StaffNoteRepository.Note note, UUID target, String display, boolean canModify) {
        SecureGuiHolder holder = gui.create(player, 27, "Note #" + note.id());
        holder.getInventory().setItem(13, gui.item(Material.BOOK, "Note #" + note.id(),
                "Kategorie: " + Objects.toString(note.category(), "-"),
                "Autor: " + shortUuid(note.author()),
                clip(note.text(), 160),
                "Archiviert: " + note.archived()));
        if (canModify) {
            gui.button(holder, 11, gui.item(Material.ANVIL, "Bearbeiten"), Permissions.NOTES_EDIT, "edit",
                    event -> prompts.ask(player, "Neuer Note-Text", text -> edit(player, note, target, display, text)));
            if (player.hasPermission(Permissions.NOTES_ARCHIVE)) {
                gui.button(holder, 15, gui.item(Material.CHEST, note.archived() ? "Wiederherstellen" : "Archivieren"),
                        Permissions.NOTES_ARCHIVE, "archive",
                        event -> archive(player, note, target, display, !note.archived()));
            }
        }
        gui.button(holder, 22, gui.item(Material.ARROW, "Zurück"), null, "back",
                event -> open(player, target, display, 0, false));
        gui.open(player, holder);
    }

    private boolean canModifyOffThread(UUID viewerId, StaffRank viewerRank, boolean mayEdit, boolean override,
                                       StaffNoteRepository.Note note) {
        if (!mayEdit) return false;
        if (note.author().equals(viewerId)) return true;
        if (viewerRank == null) return false;
        Optional<String> authorRank = repos.presence.staffRank(note.author());
        if (authorRank.isEmpty()) return override && viewerRank == StaffRank.OWNER;
        try {
            return viewerRank.level() > StaffRank.parse(authorRank.get()).level();
        } catch (IllegalArgumentException ignored) {
            return false;
        }
    }

    private void create(Player player, UUID target, String display) {
        UUID actorId = player.getUniqueId();
        String actorName = player.getName();
        prompts.ask(player, "Kategorie eingeben (z.B. behavior)", category ->
                prompts.ask(player, "Note-Text eingeben", text -> io.execute(() -> {
                    String safeCategory = InputPolicy.bounded(category, 64, "category");
                    String safeText = InputPolicy.bounded(text, 4096, "note");
                    long id = repos.notes.create(target, actorId, safeCategory, safeText);
                    audit.append(actorId, actorName, target, config.serverName(),
                            "STAFF_NOTE_CREATE", null, "{\"note\":" + id + "}");
                    Bukkit.getScheduler().runTask(plugin, () -> open(player, target, display, 0, false));
                })));
    }

    private void edit(Player player, StaffNoteRepository.Note note, UUID target, String display, String text) {
        UUID actorId = player.getUniqueId();
        String actorName = player.getName();
        io.execute(() -> {
            var updated = repos.notes.edit(note.id(), actorId, note.updatedAt(),
                    InputPolicy.bounded(text, 4096, "note"));
            if (updated.isPresent()) {
                audit.append(actorId, actorName, target, config.serverName(),
                        "STAFF_NOTE_EDIT", "{\"note\":" + note.id() + "}", "{\"note\":" + note.id() + "}");
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (updated.isEmpty()) player.sendMessage(Component.text("Note wurde parallel geändert; bitte neu laden."));
                open(player, target, display, 0, false);
            });
        });
    }

    private void archive(Player player, StaffNoteRepository.Note note, UUID target, String display, boolean archived) {
        UUID actorId = player.getUniqueId();
        String actorName = player.getName();
        io.execute(() -> {
            var updated = repos.notes.archive(note.id(), actorId, note.updatedAt(), archived);
            if (updated.isPresent()) {
                audit.append(actorId, actorName, target, config.serverName(),
                        archived ? "STAFF_NOTE_ARCHIVE" : "STAFF_NOTE_RESTORE", null,
                        "{\"note\":" + note.id() + "}");
            }
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (updated.isEmpty()) player.sendMessage(Component.text("Note wurde parallel geändert; bitte neu laden."));
                open(player, target, display, 0, false);
            });
        });
    }

    private void resolve(Player player, String name, java.util.function.Consumer<UUID> success) {
        io.execute(() -> {
            Optional<UUID> id = repos.players.findUuidByName(name);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id.isEmpty()) player.sendMessage(Component.text("Spieler nicht gefunden."));
                else success.accept(id.get());
            });
        });
    }

    private static String shortUuid(UUID uuid) { return uuid.toString().substring(0, 8); }
    private static String clip(String value, int max) {
        if (value == null) return "";
        return value.length() <= max ? value : value.substring(0, max - 1) + "…";
    }
}
