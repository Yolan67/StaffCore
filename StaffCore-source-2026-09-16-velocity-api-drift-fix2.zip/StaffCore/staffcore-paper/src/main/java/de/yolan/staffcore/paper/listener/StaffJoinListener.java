package de.yolan.staffcore.paper.listener;

import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.paper.service.NotificationService;
import de.yolan.staffcore.paper.service.SpectateService;
import de.yolan.staffcore.paper.service.VanishService;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public final class StaffJoinListener implements Listener {
    private final NotificationService notifications;
    private final SpectateService spectate;
    private final VanishService vanish;
    private final boolean joinOverview;

    public StaffJoinListener(
            NotificationService notifications,
            SpectateService spectate,
            VanishService vanish,
            boolean joinOverview) {
        this.notifications = notifications;
        this.spectate = spectate;
        this.vanish = vanish;
        this.joinOverview = joinOverview;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        if (StaffRank.resolve(event.getPlayer()::hasPermission).isPresent()) {
            if (joinOverview) notifications.onStaffJoin(event.getPlayer());
            spectate.recoverOnJoin(event.getPlayer());
        }
        vanish.refreshViewer(event.getPlayer());
    }
}
