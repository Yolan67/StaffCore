package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.data.Repositories;
import java.util.Optional;
import java.util.UUID;

/**
 * DB-backed visibility decision used by async GUI/search code. The policy is deliberately fail-closed:
 * a persisted vanished Staff identity whose current rank cannot be proven is only visible to Owner.
 */
public final class StaffVisibilityPolicy {
    private final Repositories repositories;

    public StaffVisibilityPolicy(Repositories repositories) {
        this.repositories = repositories;
    }

    public boolean canSeePersisted(UUID target, StaffRank viewerRank) {
        if (target == null) return true;
        boolean vanished = repositories.staffStates.find(target)
                .map(StaffPersistentState::vanished)
                .orElse(false);
        if (!vanished) return true;
        if (viewerRank == null) return false;
        Optional<StaffRank> targetRank = repositories.presence.staffRank(target).flatMap(StaffVisibilityPolicy::parseRank);
        if (targetRank.isEmpty()) return viewerRank == StaffRank.OWNER;
        return viewerRank.level() >= targetRank.get().level();
    }

    private static Optional<StaffRank> parseRank(String value) {
        try {
            return Optional.of(StaffRank.parse(value));
        } catch (IllegalArgumentException ignored) {
            return Optional.empty();
        }
    }
}
