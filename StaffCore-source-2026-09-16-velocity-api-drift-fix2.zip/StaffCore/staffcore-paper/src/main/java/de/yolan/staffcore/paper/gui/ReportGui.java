package de.yolan.staffcore.paper.gui;

import de.yolan.staffcore.common.ticket.TicketCategory;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.paper.service.ChatPromptService;
import de.yolan.staffcore.paper.service.TicketService;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class ReportGui {
    private final JavaPlugin plugin;
    private final GuiManager gui;
    private final ChatPromptService prompts;
    private final TicketService tickets;
    private final Repositories repos;
    private final Executor io;

    public ReportGui(
            JavaPlugin plugin,
            GuiManager gui,
            ChatPromptService prompts,
            TicketService tickets,
            Repositories repos,
            Executor io) {
        this.plugin = plugin;
        this.gui = gui;
        this.prompts = prompts;
        this.tickets = tickets;
        this.repos = repos;
        this.io = io;
    }

    public void open(Player player) {
        SecureGuiHolder holder = gui.create(player, 27, "Neues Ticket");
        category(holder, player, 10, Material.IRON_SWORD, "Spieler melden", TicketCategory.PLAYER_REPORT);
        category(holder, player, 11, Material.REDSTONE, "Bug melden", TicketCategory.BUG);
        category(holder, player, 12, Material.REPEATER, "Serverproblem", TicketCategory.SERVER_PROBLEM);
        category(holder, player, 14, Material.BOOK, "Frage / Hilfe", TicketCategory.HELP);
        category(holder, player, 15, Material.PLAYER_HEAD, "Staff melden", TicketCategory.STAFF_REPORT);
        category(holder, player, 16, Material.PAPER, "Sonstiges", TicketCategory.OTHER);
        gui.open(player, holder);
    }

    private void category(
            SecureGuiHolder holder,
            Player player,
            int slot,
            Material material,
            String name,
            TicketCategory category) {
        gui.button(holder, slot, gui.item(material, name), null, "cat-" + category,
                event -> chooseSubcategory(player, category));
    }

    private void chooseSubcategory(Player player, TicketCategory category) {
        if (category == TicketCategory.HELP || category == TicketCategory.OTHER) {
            askDescription(player, category, "general", null);
            return;
        }
        SecureGuiHolder holder = gui.create(player, 27, "Kategorie: " + category.name());
        List<String> values = switch (category) {
            case PLAYER_REPORT -> List.of("cheating", "harassment", "spam", "other");
            case BUG -> List.of("data-loss", "server-crash", "duplicate-exploit", "gameplay-blocker", "cosmetic-bug", "other");
            case SERVER_PROBLEM -> List.of("lag", "outage", "security", "other");
            case STAFF_REPORT -> List.of("conduct", "abuse", "other");
            default -> List.of("general");
        };
        int slot = 10;
        for (String value : values) {
            gui.button(holder, slot++, gui.item(Material.PAPER, value), null, "sub-" + value,
                    event -> {
                        if (category == TicketCategory.PLAYER_REPORT || category == TicketCategory.STAFF_REPORT) {
                            askTarget(player, category, value);
                        } else {
                            askDescription(player, category, value, null);
                        }
                    });
        }
        gui.button(holder, 22, gui.item(Material.ARROW, "Zurück"), null, "back", event -> open(player));
        gui.open(player, holder);
    }

    private void askTarget(Player player, TicketCategory category, String subcategory) {
        prompts.ask(player, "Spielername eingeben", name -> {
            Player online = Bukkit.getPlayerExact(name);
            if (online != null) {
                askDescription(player, category, subcategory, online.getUniqueId());
                return;
            }
            io.execute(() -> {
                Optional<UUID> id = repos.players.findUuidByName(name);
                sync(() -> {
                    if (id.isEmpty()) {
                        player.sendMessage(Component.text("Spieler nicht gefunden."));
                        open(player);
                    } else {
                        askDescription(player, category, subcategory, id.get());
                    }
                });
            });
        });
    }

    private void askDescription(Player player, TicketCategory category, String subcategory, UUID target) {
        prompts.ask(player, "Beschreibung eingeben", text -> {
            UUID creator = player.getUniqueId();
            tickets.create(creator, target, category, subcategory, text).whenComplete((ticket, error) -> sync(() -> {
                if (!player.isOnline()) return;
                if (error != null) {
                    player.sendMessage(Component.text("Ticket nicht erstellt: " + root(error)));
                } else {
                    player.sendMessage(Component.text("Ticket #" + ticket.id() + " erstellt (" + ticket.priority() + ")."));
                }
            }));
        });
    }

    private void sync(Runnable task) {
        Bukkit.getScheduler().runTask(plugin, task);
    }

    private static String root(Throwable error) {
        while (error.getCause() != null) error = error.getCause();
        String message = error.getMessage();
        return message == null ? error.getClass().getSimpleName() : message;
    }
}
