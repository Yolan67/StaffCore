package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.protocol.MessageType;
import de.yolan.staffcore.common.protocol.ProtocolCodec;
import de.yolan.staffcore.common.protocol.ProtocolConstants;
import de.yolan.staffcore.common.protocol.ProtocolEnvelope;
import java.time.Instant;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.Consumer;
import java.util.logging.Level;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

public final class BridgeClient implements PluginMessageListener, AutoCloseable {
    private static final int PENDING_LIMIT = 100;
    private static final long BAD_LOG_INTERVAL_MILLIS = 10_000L;

    private final JavaPlugin plugin;
    private final ProtocolCodec codec;
    private final String serverName;
    private final Map<MessageType, List<Consumer<ProtocolEnvelope>>> handlers = new EnumMap<>(MessageType.class);
    private final ConcurrentHashMap<UUID, Instant> seen = new ConcurrentHashMap<>();
    private final ArrayBlockingQueue<byte[]> pending = new ArrayBlockingQueue<>(PENDING_LIMIT);
    private final AtomicLong lastBadLog = new AtomicLong();
    private final AtomicLong lastQueueLog = new AtomicLong();

    public BridgeClient(JavaPlugin plugin, String secret, String serverName) {
        this.plugin = plugin;
        this.codec = new ProtocolCodec(secret);
        this.serverName = serverName;
        Bukkit.getMessenger().registerIncomingPluginChannel(plugin, ProtocolConstants.CHANNEL, this);
        Bukkit.getMessenger().registerOutgoingPluginChannel(plugin, ProtocolConstants.CHANNEL);
    }

    public void on(MessageType type, Consumer<ProtocolEnvelope> handler) {
        handlers.computeIfAbsent(type, ignored -> new CopyOnWriteArrayList<>()).add(handler);
    }

    public void send(MessageType type, UUID subject, long revision, Object payload) {
        byte[] data = codec.encode(type, subject, revision, payload);
        Runnable dispatch = () -> {
            Optional<Player> carrier = subject == null
                    ? Bukkit.getOnlinePlayers().stream().findFirst()
                    : Optional.ofNullable(Bukkit.getPlayer(subject))
                            .or(() -> Bukkit.getOnlinePlayers().stream().findFirst());
            if (carrier.isPresent()) {
                carrier.get().sendPluginMessage(plugin, ProtocolConstants.CHANNEL, data);
                flush(carrier.get());
                return;
            }
            if (!pending.offer(data)) {
                rateLimitedQueueWarning("Bridge-Ausgangsqueue ist voll; Nachricht " + type + " wurde verworfen.");
            }
        };
        if (Bukkit.isPrimaryThread()) dispatch.run();
        else Bukkit.getScheduler().runTask(plugin, dispatch);
    }

    public void flush(Player carrier) {
        if (!Bukkit.isPrimaryThread()) {
            Bukkit.getScheduler().runTask(plugin, () -> flush(carrier));
            return;
        }
        byte[] message;
        int sent = 0;
        while (sent++ < PENDING_LIMIT && (message = pending.poll()) != null) {
            carrier.sendPluginMessage(plugin, ProtocolConstants.CHANNEL, message);
        }
    }

    @Override
    public void onPluginMessageReceived(String channel, Player carrier, byte[] message) {
        if (!ProtocolConstants.CHANNEL.equals(channel)) return;
        try {
            ProtocolEnvelope envelope = codec.decodeAndVerify(message);
            Instant previous = seen.putIfAbsent(envelope.messageId(), Instant.now());
            if (previous != null) return;
            if (seen.size() > 4096) cleanup();
            for (Consumer<ProtocolEnvelope> handler : new ArrayList<>(handlers.getOrDefault(envelope.type(), List.of()))) {
                try {
                    handler.accept(envelope);
                } catch (RuntimeException ex) {
                    rateLimitedBadMessage("Bridge-Handler für " + envelope.type() + " hat Payload verworfen", ex);
                }
            }
        } catch (RuntimeException ex) {
            rateLimitedBadMessage("Ungültige StaffCore-Bridge-Nachricht verworfen", ex);
        }
    }

    private void cleanup() {
        Instant cutoff = Instant.now().minusSeconds(ProtocolConstants.MAX_CLOCK_SKEW_SECONDS * 2L);
        seen.entrySet().removeIf(entry -> entry.getValue().isBefore(cutoff));
    }

    private void rateLimitedBadMessage(String message, Throwable error) {
        long now = System.currentTimeMillis();
        long previous = lastBadLog.get();
        if (now - previous < BAD_LOG_INTERVAL_MILLIS || !lastBadLog.compareAndSet(previous, now)) return;
        plugin.getLogger().log(Level.WARNING, message + ": " + error.getMessage());
    }

    private void rateLimitedQueueWarning(String message) {
        long now = System.currentTimeMillis();
        long previous = lastQueueLog.get();
        if (now - previous < BAD_LOG_INTERVAL_MILLIS || !lastQueueLog.compareAndSet(previous, now)) return;
        plugin.getLogger().warning(message);
    }

    public <T> T payload(ProtocolEnvelope envelope, Class<T> type) {
        return codec.payload(envelope, type);
    }

    public String serverName() {
        return serverName;
    }

    @Override
    public void close() {
        Bukkit.getMessenger().unregisterIncomingPluginChannel(plugin, ProtocolConstants.CHANNEL, this);
        Bukkit.getMessenger().unregisterOutgoingPluginChannel(plugin, ProtocolConstants.CHANNEL);
        pending.clear();
        seen.clear();
        handlers.clear();
    }
}
