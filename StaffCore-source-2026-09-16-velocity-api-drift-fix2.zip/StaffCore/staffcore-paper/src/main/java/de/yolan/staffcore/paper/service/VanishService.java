package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.paper.config.PaperConfig;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;

public final class VanishService {
    private final JavaPlugin plugin;
    private final ServerStateCache cache;
    private final PaperRankService ranks;
    private final boolean fakeJoinLeave;

    public VanishService(JavaPlugin plugin, ServerStateCache cache, PaperRankService ranks, PaperConfig config) {
        this.plugin = plugin;
        this.cache = cache;
        this.ranks = ranks;
        this.fakeJoinLeave = config.vanishFakeJoinLeave();
    }

    public boolean vanished(UUID playerId) {
        return cache.staff(playerId).map(StaffPersistentState::vanished).orElse(false);
    }

    public void refreshAll() {
        for (Player target : Bukkit.getOnlinePlayers()) refreshTarget(target, false);
    }

    public void refreshViewer(Player viewer) {
        for (Player target : Bukkit.getOnlinePlayers()) apply(viewer, target);
    }

    public void refreshTarget(Player target, boolean requestFakeMessage) {
        boolean sendFakeMessage = requestFakeMessage && fakeJoinLeave;
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            boolean before = viewer.canSee(target);
            apply(viewer, target);
            boolean after = viewer.canSee(target);
            if (sendFakeMessage && before != after && !viewer.getUniqueId().equals(target.getUniqueId())) {
                viewer.sendMessage(Component.text((after ? "+ " : "- ") + target.getName()));
            }
        }
    }

    private void apply(Player viewer, Player target) {
        if (viewer.equals(target)) return;
        if (!vanished(target.getUniqueId())) {
            viewer.showPlayer(plugin, target);
            return;
        }
        if (ranks.canSeeVanished(viewer, target)) viewer.showPlayer(plugin, target);
        else viewer.hidePlayer(plugin, target);
    }

    public void startReconciler() {
        Bukkit.getScheduler().runTaskTimer(plugin, this::refreshAll, 40L, 40L);
    }
}
