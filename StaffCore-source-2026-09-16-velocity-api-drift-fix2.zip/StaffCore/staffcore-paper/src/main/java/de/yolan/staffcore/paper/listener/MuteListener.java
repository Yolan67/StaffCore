package de.yolan.staffcore.paper.listener;

import de.yolan.staffcore.paper.config.PaperConfig;
import de.yolan.staffcore.paper.service.ServerStateCache;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Locale;
import java.util.UUID;

public final class MuteListener implements Listener {
    private final JavaPlugin plugin;
    private final ServerStateCache cache;
    private final PaperConfig config;

    public MuteListener(JavaPlugin plugin, ServerStateCache cache, PaperConfig config) {
        this.plugin = plugin;
        this.cache = cache;
        this.config = config;
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void chat(AsyncChatEvent event) {
        UUID playerId = event.getPlayer().getUniqueId();
        if (!cache.muted(playerId)) return;
        event.setCancelled(true);
        Bukkit.getScheduler().runTask(plugin, () -> {
            Player player = Bukkit.getPlayer(playerId);
            if (player != null) player.sendMessage(Component.text("Du bist gemutet."));
        });
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void command(PlayerCommandPreprocessEvent event) {
        if (!cache.muted(event.getPlayer().getUniqueId())) return;
        String label = event.getMessage().substring(1).split(" ", 2)[0].toLowerCase(Locale.ROOT);
        if (config.muteBlockedCommands().contains(label)) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(Component.text("Dieser Kommunikationsbefehl ist während eines Mutes gesperrt."));
        }
    }
}
