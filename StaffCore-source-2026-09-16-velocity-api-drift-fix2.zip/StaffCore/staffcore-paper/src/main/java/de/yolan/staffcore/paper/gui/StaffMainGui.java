package de.yolan.staffcore.paper.gui;

import de.yolan.staffcore.common.model.PresenceRecord;
import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.common.permission.StaffRank;
import de.yolan.staffcore.paper.PaperRuntime;
import de.yolan.staffcore.paper.service.FreezeService;
import de.yolan.staffcore.paper.service.LocalStaffStateService;
import de.yolan.staffcore.paper.service.NotificationService;
import de.yolan.staffcore.paper.service.PaperRankService;
import de.yolan.staffcore.paper.service.SpectateService;
import de.yolan.staffcore.paper.service.StaffModeService;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class StaffMainGui {
    private record VisibleStaff(PresenceRecord presence, StaffRank rank, boolean vanished) {}

    private final JavaPlugin plugin;
    private final GuiManager gui;
    private final PaperRuntime runtime;
    private final LocalStaffStateService localState;
    private final StaffModeService staffMode;
    private final FreezeService freeze;
    private final SpectateService spectate;
    private final PaperRankService ranks;
    private final InspectGui inspect;
    private final TicketGui tickets;
    private final NotesGui notes;
    private final LogsGui logs;
    private final ActivityGui activity;
    private final PunishmentGui punishments;
    private final NotificationService notifications;

    public StaffMainGui(JavaPlugin plugin, GuiManager gui, PaperRuntime runtime, LocalStaffStateService localState,
                        StaffModeService staffMode, FreezeService freeze, SpectateService spectate,
                        PaperRankService ranks, InspectGui inspect, TicketGui tickets, NotesGui notes,
                        LogsGui logs, ActivityGui activity, PunishmentGui punishments,
                        NotificationService notifications) {
        this.plugin = plugin;
        this.gui = gui;
        this.runtime = runtime;
        this.localState = localState;
        this.staffMode = staffMode;
        this.freeze = freeze;
        this.spectate = spectate;
        this.ranks = ranks;
        this.inspect = inspect;
        this.tickets = tickets;
        this.notes = notes;
        this.logs = logs;
        this.activity = activity;
        this.punishments = punishments;
        this.notifications = notifications;
    }

    public void open(Player player) {
        if (!player.hasPermission(Permissions.MENU)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return;
        }
        SecureGuiHolder holder = gui.create(player, 54, "StaffCore");
        holder.getInventory().setItem(4, gui.item(Material.NETHER_STAR, "StaffCore",
                "Server: " + runtime.config.serverName(),
                "Rank: " + ranks.rank(player).map(StaffRank::displayName).orElse("kein Staff-Rank")));

        button(holder, player, 9, Material.COMPASS, "Spieler suchen", Permissions.INSPECT,
                "inspect", event -> inspect.promptAndOpen(player));
        button(holder, player, 10, Material.PLAYER_HEAD, "Online-Spieler", Permissions.INSPECT,
                "online", event -> inspect.openOnlineList(player, 0));
        button(holder, player, 11, Material.CHEST, "Reports / Tickets", Permissions.TICKET_VIEW,
                "tickets", event -> tickets.openStaffHome(player));
        button(holder, player, 12, Material.NAME_TAG, "Mir zugewiesen", Permissions.TICKET_VIEW,
                "assigned", event -> tickets.openAssigned(player));
        button(holder, player, 13, Material.REDSTONE_BLOCK, "Kritische Tickets", Permissions.TICKET_VIEW,
                "critical", event -> tickets.openCritical(player));
        if (hasAnyPunishmentPermission(player)) {
            gui.button(holder, 14, gui.item(Material.IRON_BARS, "Punishments"), null,
                    "punishments", event -> punishments.promptTarget(player));
        }
        button(holder, player, 15, Material.WRITABLE_BOOK, "Notes", Permissions.NOTES_VIEW,
                "notes", event -> notes.promptTarget(player));
        button(holder, player, 16, Material.PAPER, "Logs", Permissions.LOGS_VIEW,
                "logs", event -> logs.open(player, 0,
                        new de.yolan.staffcore.data.AuditRepository.Query(null, null, null, null, null, null)));
        button(holder, player, 18, Material.CLOCK, "Staff Activity", Permissions.ACTIVITY_VIEW,
                "activity", event -> activity.promptStaff(player));
        button(holder, player, 19, Material.ENDER_EYE, "Vanish", Permissions.VANISH,
                "vanish", event -> localState.toggleVanish(player));
        button(holder, player, 20, Material.SPYGLASS, "Spectate", Permissions.SPECTATE,
                "spectate", event -> inspect.promptSpectate(player, spectate));
        button(holder, player, 21, Material.ICE, "Freeze", Permissions.FREEZE,
                "freeze", event -> inspect.promptFreeze(player, runtime.bridge));
        button(holder, player, 22, Material.ENDER_CHEST, "StaffMode", Permissions.STAFFMODE,
                "staffmode", event -> staffMode.toggle(player));
        button(holder, player, 23, Material.NAME_TAG, "Staff online", Permissions.STAFFLIST,
                "staff-online", event -> openStaffOnline(player));
        button(holder, player, 24, Material.BELL, "Inbox", Permissions.MENU,
                "inbox", event -> openInbox(player));
        button(holder, player, 27, Material.REPEATER, "Serverstatus", Permissions.MENU,
                "server-status", event -> openServerStatus(player));
        button(holder, player, 28, Material.COMPARATOR, "Eigene Einstellungen", Permissions.MENU,
                "prefs", event -> openPreferences(player));
        button(holder, player, 29, Material.LEVER, "StaffChat Toggle", Permissions.STAFFCHAT_USE,
                "staffchat", event -> localState.toggleStaffChat(player));
        if (player.hasPermission(Permissions.SPECTATE) || player.hasPermission(Permissions.SPECTATE_SUPER)) {
            gui.button(holder, 30, gui.item(Material.BARRIER, "Spectate beenden"), null,
                    "spectate-stop", event -> {
                        if (player.hasPermission(Permissions.SPECTATE) || player.hasPermission(Permissions.SPECTATE_SUPER)) {
                            spectate.stop(player);
                        }
                    });
        }
        button(holder, player, 31, Material.RECOVERY_COMPASS, "StaffMode Recovery", Permissions.STAFFMODE_RECOVER,
                "staffmode-recover", event -> staffMode.forceRestore(player));
        holder.getInventory().setItem(34, gui.item(Material.OBSERVER, "MaintenanceCore",
                runtime.config.maintenanceEnabled()
                        ? "Integration konfiguriert, aber kein Provider verfügbar."
                        : "Integration deaktiviert.",
                "StaffCore funktioniert unabhängig davon."));
        gui.button(holder, 49, gui.item(Material.BARRIER, "Schließen"), null,
                "close", event -> player.closeInventory());
        gui.open(player, holder);
    }

    private void button(SecureGuiHolder holder, Player player, int slot, Material material, String name,
                        String permission, String id,
                        java.util.function.Consumer<org.bukkit.event.inventory.InventoryClickEvent> action) {
        if (permission == null || player.hasPermission(permission)) {
            gui.button(holder, slot, gui.item(material, name), permission, id, action);
        }
    }

    private boolean hasAnyPunishmentPermission(Player player) {
        return player.hasPermission(Permissions.PUNISH_WARN)
                || player.hasPermission(Permissions.PUNISH_KICK)
                || player.hasPermission(Permissions.PUNISH_MUTE)
                || player.hasPermission(Permissions.PUNISH_SERVERBAN)
                || player.hasPermission(Permissions.PUNISH_GLOBALBAN);
    }

    private void openServerStatus(Player player) {
        SecureGuiHolder holder = gui.create(player, 27, "Serverstatus");
        boolean databaseHealthy = runtime.db.isHealthy();
        holder.getInventory().setItem(11, gui.item(databaseHealthy ? Material.LIME_DYE : Material.RED_DYE,
                "Datenbank", databaseHealthy ? "HEALTHY" : "DEGRADED"));
        holder.getInventory().setItem(13, gui.item(Material.REPEATER, "Backend", runtime.config.serverName()));
        StaffPersistentState state = runtime.cache.staff(player.getUniqueId()).orElse(null);
        holder.getInventory().setItem(15, gui.item(Material.COMPARATOR, "Eigener State",
                "Vanish: " + (state != null && state.vanished()),
                "StaffChat: " + (state != null && state.staffChat()),
                "Freeze: " + freeze.frozen(player),
                "StaffMode: " + staffMode.active(player.getUniqueId())));
        gui.button(holder, 22, gui.item(Material.ARROW, "Zurück"), null, "back", event -> open(player));
        gui.open(player, holder);
    }

    private void openStaffOnline(Player player) {
        StaffRank viewerRank = ranks.rank(player).orElse(null);
        if (viewerRank == null || !player.hasPermission(Permissions.STAFFLIST)) return;
        player.sendMessage(Component.text("Staff-Online wird geladen …"));
        runtime.io.execute(() -> {
            List<VisibleStaff> visible = new ArrayList<>();
            for (PresenceRecord presence : runtime.repos.presence.staffOnline()) {
                StaffRank rank = runtime.repos.presence.staffRank(presence.playerUuid())
                        .flatMap(value -> {
                            try { return java.util.Optional.of(StaffRank.parse(value)); }
                            catch (IllegalArgumentException ignored) { return java.util.Optional.empty(); }
                        }).orElse(null);
                if (rank == null) continue;
                boolean vanished = runtime.repos.staffStates.find(presence.playerUuid()).map(StaffPersistentState::vanished).orElse(false);
                if (rank.level() > viewerRank.level()) continue;
                visible.add(new VisibleStaff(presence, rank, vanished));
            }
            sync(() -> {
                if (!player.isOnline() || !player.hasPermission(Permissions.STAFFLIST)) return;
                SecureGuiHolder holder = gui.create(player, 54, "Staff online");
                int slot = 0;
                for (VisibleStaff staff : visible) {
                    if (slot >= 45) break;
                    holder.getInventory().setItem(slot++, gui.item(Material.PLAYER_HEAD, staff.presence().playerName(),
                            "Rang: " + staff.rank().displayName(),
                            "Server: " + staff.presence().serverName(),
                            staff.vanished() ? "Vanish: AN" : "Vanish: AUS",
                            "Seit: " + staff.presence().connectedAt()));
                }
                gui.button(holder, 49, gui.item(Material.ARROW, "Zurück"), null, "back", event -> open(player));
                gui.open(player, holder);
            });
        });
    }

    private void openInbox(Player player) {
        UUID playerId = player.getUniqueId();
        notifications.list(playerId).whenComplete((list, error) -> sync(() -> {
            if (!player.isOnline()) return;
            if (error != null) {
                player.sendMessage(Component.text("Inbox konnte nicht geladen werden."));
                return;
            }
            SecureGuiHolder holder = gui.create(player, 54, "Inbox");
            int slot = 0;
            for (var notification : list) {
                if (slot >= 45) break;
                holder.getInventory().setItem(slot++, gui.item(Material.PAPER, notification.title(),
                        notification.body(), notification.createdAt().toString()));
            }
            gui.button(holder, 48, gui.item(Material.LIME_DYE, "Alle als gelesen"), null, "read",
                    event -> { notifications.markAll(playerId); open(player); });
            gui.button(holder, 49, gui.item(Material.ARROW, "Zurück"), null, "back", event -> open(player));
            gui.open(player, holder);
        }));
    }

    private void openPreferences(Player player) {
        UUID playerId = player.getUniqueId();
        runtime.io.execute(() -> {
            var preference = runtime.repos.preferences.get(playerId);
            sync(() -> {
                if (!player.isOnline()) return;
                SecureGuiHolder holder = gui.create(player, 27, "Staff-Einstellungen");
                gui.button(holder, 11, gui.item(preference.joinSummary() ? Material.LIME_DYE : Material.GRAY_DYE,
                                "Join-Übersicht: " + (preference.joinSummary() ? "AN" : "AUS")),
                        null, "join-summary", event -> runtime.io.execute(() -> {
                            runtime.repos.preferences.setJoinSummary(playerId, !preference.joinSummary());
                            sync(() -> openPreferences(player));
                        }));
                gui.button(holder, 15, gui.item(preference.notifications() ? Material.LIME_DYE : Material.GRAY_DYE,
                                "Notifications: " + (preference.notifications() ? "AN" : "AUS")),
                        null, "notifications", event -> runtime.io.execute(() -> {
                            runtime.repos.preferences.setNotifications(playerId, !preference.notifications());
                            sync(() -> openPreferences(player));
                        }));
                gui.button(holder, 22, gui.item(Material.ARROW, "Zurück"), null, "back", event -> open(player));
                gui.open(player, holder);
            });
        });
    }

    private void sync(Runnable task) {
        Bukkit.getScheduler().runTask(plugin, task);
    }
}
