package de.yolan.staffcore.paper;

import de.yolan.staffcore.paper.command.*;
import de.yolan.staffcore.paper.gui.*;
import de.yolan.staffcore.paper.listener.*;
import de.yolan.staffcore.paper.service.*;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Objects;

public final class StaffCorePaper extends JavaPlugin {
    private PaperRuntime runtime;

    @Override
    public void onEnable() {
        try {
            runtime = new PaperRuntime(this, getDataFolder().toPath());

            GuiManager gui = new GuiManager(this);
            ChatPromptService prompts = new ChatPromptService(this);
            PaperRankService ranks = new PaperRankService();
            PaperAuditService audit = new PaperAuditService(this, runtime.repos, runtime.io, runtime.config.maxAuditPayloadChars());
            LocalStaffStateService localState = new LocalStaffStateService(this, runtime.repos, runtime.io, runtime.cache, runtime.bridge, runtime.config, audit);
            VanishService vanish = new VanishService(this, runtime.cache, ranks, runtime.config);
            vanish.startReconciler();
            FreezeService freeze = new FreezeService(this, runtime.config, runtime.repos, runtime.io, runtime.cache);
            StaffModeService staffMode = new StaffModeService(this, runtime.config, runtime.repos, runtime.io, runtime.cache, runtime.bridge, freeze, audit);
            staffMode.startReconciler();
            SpectateService spectate = new SpectateService(this, runtime.config, runtime.repos, runtime.io, runtime.cache, runtime.bridge, localState, audit);
            TicketService tickets = new TicketService(runtime.repos, runtime.io, runtime.bridge, runtime.config, audit);
            PlayerInspectService inspect = new PlayerInspectService(runtime.repos, runtime.io);
            InventoryInspectService inventoryInspect = new InventoryInspectService(this, runtime.repos, runtime.io, audit, runtime.config);
            NotificationService notifications = new NotificationService(this, runtime.db, runtime.repos, runtime.io, runtime.config);
            StaffVisibilityPolicy visibility = new StaffVisibilityPolicy(runtime.repos);

            PunishmentGui punishmentGui = new PunishmentGui(this, gui, prompts, runtime.repos, runtime.io, runtime.bridge, runtime.config);
            NotesGui notesGui = new NotesGui(this, gui, prompts, runtime.repos, runtime.io, audit, runtime.config, ranks);
            LogsGui logsGui = new LogsGui(this, gui, prompts, runtime.repos, runtime.io, ranks, visibility);
            ActivityGui activityGui = new ActivityGui(this, gui, prompts, runtime.repos, runtime.io, ranks, visibility);
            TicketGui ticketGui = new TicketGui(gui, tickets, prompts, ranks, runtime.repos, runtime.io);
            InspectGui inspectGui = new InspectGui(this, gui, prompts, inspect, runtime.repos, runtime.io, inventoryInspect, notesGui, logsGui, ticketGui, punishmentGui, runtime.config, ranks, runtime.cache, runtime.bridge, spectate);
            ReportGui reportGui = new ReportGui(this, gui, prompts, tickets, runtime.repos, runtime.io);
            StaffMainGui staffGui = new StaffMainGui(this, gui, runtime, localState, staffMode, freeze, spectate, ranks, inspectGui, ticketGui, notesGui, logsGui, activityGui, punishmentGui, notifications);

            new BridgeStateCoordinator(this, runtime.config, runtime.bridge, runtime.loader, runtime.io, vanish, freeze, staffMode);

            register(gui);
            register(prompts);
            register(inventoryInspect);
            register(new PreloadListener(runtime.loader));
            register(new PlayerLifecycleListener(this, runtime.bridge, staffMode, runtime.cache));
            register(new VanishListener(this, vanish, runtime.config));
            register(new FreezeListener(freeze));
            register(new MuteListener(this, runtime.cache, runtime.config));
            register(new StaffChatListener(this, runtime.cache, ranks, runtime.config, runtime.bridge));
            register(new StaffModeProtectionListener(staffMode, staffGui::open));
            register(new StaffJoinListener(notifications, spectate, vanish, runtime.config.staffJoinOverview()));

            command("staff", new StaffCommand(staffGui));
            command("staffmode", new StaffModeCommand(staffMode));
            command("report", new ReportCommand(reportGui));
            command("tickets", new TicketsCommand(ticketGui));
            command("inspect", new InspectCommand(this, runtime.repos, runtime.io, inspectGui, ranks, runtime.cache));
            command("spectate", new SpectateCommand(this, runtime.repos, runtime.io, spectate, ranks, runtime.cache));

            getLogger().info("StaffCore Paper enabled for backend '" + runtime.config.serverName() + "'.");
        } catch (Exception ex) {
            getLogger().severe("StaffCore Paper initialization failed safely: " + ex.getMessage());
            ex.printStackTrace();
            Bukkit.getPluginManager().disablePlugin(this);
        }
    }

    private void register(Listener listener) {
        Bukkit.getPluginManager().registerEvents(listener, this);
    }

    private void command(String name, org.bukkit.command.CommandExecutor executor) {
        PluginCommand command = Objects.requireNonNull(getCommand(name), "Missing command in plugin.yml: " + name);
        command.setExecutor(executor);
        if (executor instanceof org.bukkit.command.TabCompleter completer) command.setTabCompleter(completer);
    }

    @Override
    public void onDisable() {
        if (runtime != null) {
            runtime.close();
            runtime = null;
        }
    }
}
