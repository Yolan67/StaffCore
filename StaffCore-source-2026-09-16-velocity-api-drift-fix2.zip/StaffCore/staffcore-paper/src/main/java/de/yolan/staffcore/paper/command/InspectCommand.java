package de.yolan.staffcore.paper.command;

import de.yolan.staffcore.common.model.StaffPersistentState;
import de.yolan.staffcore.common.permission.Permissions;
import de.yolan.staffcore.data.Repositories;
import de.yolan.staffcore.paper.gui.InspectGui;
import de.yolan.staffcore.paper.service.PaperRankService;
import de.yolan.staffcore.paper.service.ServerStateCache;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.Executor;

public final class InspectCommand implements CommandExecutor, TabCompleter {
    private final JavaPlugin plugin;
    private final Repositories repos;
    private final Executor io;
    private final InspectGui gui;
    private final PaperRankService ranks;
    private final ServerStateCache cache;

    public InspectCommand(JavaPlugin plugin, Repositories repos, Executor io, InspectGui gui,
                          PaperRankService ranks, ServerStateCache cache) {
        this.plugin = plugin;
        this.repos = repos;
        this.io = io;
        this.gui = gui;
        this.ranks = ranks;
        this.cache = cache;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Nur Spieler.");
            return true;
        }
        if (!player.hasPermission(Permissions.INSPECT)) {
            player.sendMessage(Component.text("Keine Berechtigung."));
            return true;
        }
        if (args.length != 1) {
            player.sendMessage(Component.text("/inspect <spieler>"));
            return true;
        }
        Player online = Bukkit.getPlayerExact(args[0]);
        if (online != null) {
            if (!visibleTo(player, online)) {
                player.sendMessage(Component.text("Spieler nicht gefunden."));
                return true;
            }
            gui.open(player, online.getUniqueId());
            return true;
        }
        String requestedName = args[0];
        io.execute(() -> {
            Optional<UUID> id = repos.players.findUuidByName(requestedName);
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (id.isEmpty()) player.sendMessage(Component.text("Spieler nicht gefunden."));
                else gui.open(player, id.get());
            });
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!(sender instanceof Player viewer) || args.length != 1 || !viewer.hasPermission(Permissions.INSPECT)) {
            return List.of();
        }
        String query = args[0].toLowerCase(Locale.ROOT);
        return Bukkit.getOnlinePlayers().stream()
                .filter(target -> visibleTo(viewer, target))
                .map(Player::getName)
                .filter(name -> name.toLowerCase(Locale.ROOT).startsWith(query))
                .limit(30)
                .toList();
    }

    private boolean visibleTo(Player viewer, Player target) {
        boolean vanished = cache.staff(target.getUniqueId()).map(StaffPersistentState::vanished).orElse(false);
        return !vanished || ranks.canSeeVanished(viewer, target);
    }
}
