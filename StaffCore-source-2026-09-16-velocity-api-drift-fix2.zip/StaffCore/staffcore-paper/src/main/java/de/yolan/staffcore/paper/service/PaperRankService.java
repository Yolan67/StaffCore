package de.yolan.staffcore.paper.service;

import de.yolan.staffcore.common.permission.StaffHierarchy;
import de.yolan.staffcore.common.permission.StaffRank;
import java.util.Optional;
import org.bukkit.entity.Player;

public final class PaperRankService {
    private final StaffHierarchy hierarchy = new StaffHierarchy();

    public Optional<StaffRank> rank(Player player) {
        return hierarchy.rankOf(player::hasPermission);
    }

    public boolean canSeeVanished(Player viewer, Player target) {
        return hierarchy.canSeeVanished(rank(viewer), rank(target));
    }
}
