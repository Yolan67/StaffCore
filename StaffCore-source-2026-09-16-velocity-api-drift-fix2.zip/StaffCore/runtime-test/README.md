# StaffCore Runtime-Testnetz

Dieses Verzeichnis bündelt bewusst **keine** fremden Velocity-/Paper-JARs. `docker-compose.yml` startet nur MariaDB.

## Zieltopologie

- Velocity 4.1.2
- Paper 26.1.2: `lobby`
- Paper 26.1.2: `survival`
- Paper 26.1.2: `events`
- MariaDB
- Testidentitäten: normaler Spieler, JrMod/Mod, Admin/Owner

## Vorbereitung

1. StaffCore mit JDK 25 erfolgreich bauen: `./mvnw clean verify`.
2. `docker compose up -d` in diesem Ordner.
3. Velocity/Paper-JARs aus den offiziellen Projektquellen beziehen.
4. Velocity Modern Forwarding und private Backend-Erreichbarkeit konfigurieren.
5. `STAFFCORE_DB_PASSWORD` und dasselbe `STAFFCORE_BRIDGE_SECRET` für alle Nodes setzen.
6. Paper `STAFFCORE_SERVER_NAME` jeweils auf `lobby`, `survival`, `events` setzen.
7. Velocity `staffcore-velocity-...-all.jar` installieren; Paper `staffcore-paper-...-all.jar` auf alle drei Backends.
8. Permissions für die Testidentitäten vergeben.

## Abnahme

Die vollständige Matrix steht in `../docs/RUNTIME_TEST_PLAN.md`. Besonders zwingend:

- StaffMode Crash-/Restore-/Origin-offline und kein Itemverlust/Dupe.
- Vanish Join/Serverwechsel/Respawn und Hierarchie.
- Freeze normaler Chat erlaubt; echter Disconnect erzeugt genau einen 5m System-Tempban, Freeze bleibt aktiv.
- Ticket Doppel-Claim/Reassign/Override/Waiting/Reply/Priority/Routing.
- ServerBan betrifft nur Zielserver; GlobalBan Netzwerklogin.
- DB für 30–60 Sekunden stoppen: kritische neue Mutationen dürfen keinen falschen Erfolg melden; Mainthread darf nicht blockieren.

Ergebnisse manuell protokollieren; nicht bestandene Runtime-Szenarien verhindern eine Production-Ready-Freigabe.
