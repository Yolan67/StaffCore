@echo off
setlocal
set "BASE_DIR=%~dp0"
set "PROP=%BASE_DIR%.mvn\wrapper\maven-wrapper.properties"
set "JAR=%BASE_DIR%.mvn\wrapper\maven-wrapper.jar"
if not exist "%PROP%" (
  echo Missing %PROP%
  exit /b 1
)
if not exist "%JAR%" (
  for /f "tokens=1,* delims==" %%A in ('findstr /b "wrapperUrl=" "%PROP%"') do set "WRAPPER_URL=%%B"
  if not defined WRAPPER_URL set "WRAPPER_URL=https://repo.maven.apache.org/maven2/org/apache/maven/wrapper/maven-wrapper/3.3.4/maven-wrapper-3.3.4.jar"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing -Uri '%WRAPPER_URL%' -OutFile '%JAR%'"
  if errorlevel 1 exit /b 1
)
if defined JAVA_HOME (
  set "JAVA_EXE=%JAVA_HOME%\bin\java.exe"
) else (
  set "JAVA_EXE=java.exe"
)
"%JAVA_EXE%" %MAVEN_OPTS% -classpath "%JAR%" -Dmaven.multiModuleProjectDirectory="%BASE_DIR%" org.apache.maven.wrapper.MavenWrapperMain %*
exit /b %ERRORLEVEL%
