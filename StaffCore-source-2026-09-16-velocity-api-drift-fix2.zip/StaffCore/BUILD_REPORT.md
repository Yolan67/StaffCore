# StaffCore Build Report

Datum: 2026-09-16

## Zielplattform

- Java 25
- Velocity API `4.1.2-SNAPSHOT`
- Paper API `26.1.2.build.74-stable`
- Maven Multi-Module
- MariaDB/Flyway

## Tatsächlich verifizierter GitHub-Actions-Stand

GitHub Actions wurde mit Eclipse Temurin Java **25.0.4** und Maven ausgeführt.

### staffcore-common

- kompiliert: **JA**
- Tests: **23/23 bestanden**

### staffcore-data

- kompiliert: **JA**
- MariaDB/Testcontainers: **JA**
- getestete MariaDB-Version: **11.8**
- Flyway `V1__initial.sql`: **erfolgreich angewendet**
- Flyway `V2__spectate_inventory_priority_sessions.sql`: **erfolgreich angewendet**
- `DatabaseIntegrationTests`: **5/5 bestanden**

### staffcore-velocity

Der neueste echte GitHub-Actions-Lauf bestätigt, dass die zuvor korrigierten `RegisteredServer`-Fehler behoben sind. Der Reactor erreichte anschließend zwei neue Compileprobleme:

1. `PunishmentService.java`: `MessageType` konnte nicht aufgelöst werden.
   - Ursache: der bestehende und weiterhin richtige Typ `de.yolan.staffcore.common.protocol.MessageType` wurde verwendet, aber nicht importiert.
   - Korrektur: expliziter Import von `de.yolan.staffcore.common.protocol.MessageType`.

2. `TicketRoutingService.java`: Aufruf `AssignmentEngine.choose(...)` existierte nicht.
   - Tatsächliche öffentliche Common-API: `RoutingDecision select(List<StaffCandidate> candidates, StaffRank minimumRank)`.
   - Korrektur: semantisch passender Aufruf `assignmentEngine.select(candidates, ticket.minimumRank())`; der ausgewählte `StaffCandidate` wird anschließend für den revisionssicheren Claim und dessen Rank verwendet.

Zusätzlich wurde das gesamte Source-Tree auf gleichartige API-Drifts geprüft:

- keine weiteren `.choose(...)`-Aufrufe auf `AssignmentEngine`;
- alle `MessageType.*`-Verwendungen im Velocity-Modul haben einen auflösbaren expliziten oder `protocol.*`-Import;
- der vorhandene `RegisteredServer`-Guard bleibt grün.

**Wichtig:** Für diesen erneut korrigierten Velocity-Stand liegt noch kein neuer grüner GitHub-Actions-Build vor. `staffcore-velocity` wird deshalb weiterhin **nicht** als erfolgreich gebaut bezeichnet.

### staffcore-paper

- im neuesten GitHub-Actions-Lauf nicht erreicht, da der Reactor vorher in `staffcore-velocity` abgebrochen ist;
- für den aktuellen korrigierten Source-Stand daher **nicht gebaut/verifiziert**.

## Velocity-4.1.2-API-Audit

Die zentralen im Velocity-Modul verwendeten API-Verträge wurden gegen die aktuelle offizielle PaperMC/Velocity-Dokumentation geprüft:

- `RegisteredServer` -> `com.velocitypowered.api.proxy.server.RegisteredServer`;
- `ProxyServer#getServer(String)` / `getAllServers()` -> `RegisteredServer`;
- `Player#createConnectionRequest(RegisteredServer)`;
- `ServerConnection#getServer()`;
- `CommandManager#register(CommandMeta, Command)` und `metaBuilder(String)`;
- `SimpleCommand` / `SimpleCommand.Invocation`;
- `EventTask#async(Runnable)`;
- `PluginMessageEvent.ForwardResult#handled()`;
- `ServerPreConnectEvent.ServerResult#allowed(RegisteredServer)` / `denied()`;
- `Scheduler.TaskBuilder#repeat(long, TimeUnit)` / `schedule()`;
- `MinecraftChannelIdentifier#from(String)`;
- `ChannelRegistrar#register(...)`;
- `ChannelMessageSink#sendPluginMessage(...)`.

Es wurde kein weiterer offensichtlicher Package-/Signaturfehler in den aktuell verwendeten Velocity-API-Aufrufen gefunden. Vollständige Typkompatibilität ist erst durch den nächsten echten Maven/GitHub-Actions-Lauf bestätigt.

## Statische Prüfung nach der Korrektur

`scripts/verify-static.py` wurde nach den Source-Änderungen erfolgreich ausgeführt.

Zusätzliche Guards:

- verbietet `com.velocitypowered.api.proxy.RegisteredServer`;
- verlangt für jede `RegisteredServer`-Verwendung den korrekten `proxy.server`-Import;
- prüft, dass jede `MessageType.*`-Verwendung im Velocity-Modul auflösbar importiert ist;
- verbietet den veralteten `AssignmentEngine.choose(...)`-Aufruf und prüft den aktuellen `select(List<StaffCandidate>, StaffRank)`-Vertrag.

Weiterhin erfolgreich geprüft:

- POM XML;
- keine dynamischen `LATEST`/`RELEASE`-Dependencies;
- keine Pflicht-Stubs/TODO-Marker;
- keine native Java-Object-Deserialisierung;
- interne StaffCore-Imports;
- Java-Dateinamen/Public-Types;
- Paper `plugin.yml` und Commands;
- Permission-Matrix;
- Paper-Listener-Registrierung;
- Velocity `@Plugin`-Metadaten;
- Bridge-MessageType-Matrix;
- Config-Leaf-Keys;
- Repository-SQL gegen Flyway-Migrationstabellen/-spalten;
- Java-Syntaxparserlauf.

## Lokale Arbeitsumgebung dieses Chats

Die lokale Tool-Umgebung dieses Chats besitzt weiterhin kein nutzbares Java-25/Maven-Setup mit externem Dependency-Download. Daher wurde hier **kein** neuer echter Maven-Build ausgeführt.

## Aktueller Buildstatus

- `staffcore-common`: **ECHT GEBAUT + 23/23 TESTS BESTANDEN**
- `staffcore-data`: **ECHT GEBAUT + 5/5 DB-INTEGRATIONSTESTS BESTANDEN**
- `staffcore-velocity`: **SOURCE ERNEUT KORRIGIERT, NEUER BUILD AUSSTEHEND**
- `staffcore-paper`: **NOCH NICHT GEBAUT**
- gesamter Reactor `mvn clean verify`: **NOCH NICHT GRÜN BESTÄTIGT**
- verifizierte Release-JARs: **NEIN**

Erst der nächste vollständig grüne GitHub-Actions-Lauf darf als erfolgreicher Gesamtbuild gelten.
