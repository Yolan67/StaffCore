# StaffCore

StaffCore ist ein netzwerkweites Staff-, Ticket- und Moderationssystem für ein Velocity-Netzwerk mit Paper-Backends und zentraler MariaDB-Persistenz.

**Zielplattform dieser Version**

- Java 25
- Velocity 4.1.2
- Paper 26.1.2
- MariaDB/MySQL-kompatibles Schema, produktiv mit MariaDB vorgesehen
- Maven Multi-Module

> Buildstatus beachten: GitHub Actions mit Temurin Java 25.0.4 hat `staffcore-common` (23/23 Tests) und `staffcore-data` (5/5 MariaDB/Testcontainers-Integrationstests, Flyway V1+V2) erfolgreich verifiziert. Der danach gemeldete Velocity-Compilefehler wurde im Source korrigiert, aber dieser neue Stand ist **noch nicht erneut grün gebaut**; Paper wurde deshalb weiterhin nicht erreicht. Siehe `BUILD_REPORT.md`.

## Module

- `staffcore-common`: plattformfreie Modelle, Permissions/Hierarchy, State-Machines, Ticket-Priority/Routing-Typen, Duration/Input-Helfer und signiertes Bridge-Protokoll.
- `staffcore-data`: HikariCP, Flyway, MariaDB-Repositories, Transaktionen, CAS-/Revision-Operationen und Idempotency.
- `staffcore-velocity`: globale Authority für Presence, Staff-State, StaffChat, Punishments, Global-/ServerBans, Freeze-Leave, Routing und Backend-Kommunikation.
- `staffcore-paper`: Welt-/Entity-/Inventar-/GUI-Funktionen, Vanish-Projektion, Freeze-Enforcement, StaffMode-Snapshots/Recovery, Spectate, Inspect, Notes, Logs, Activity und Ticket-GUIs.

Weitere Details: `docs/ARCHITECTURE.md`, `docs/DATABASE.md`, `docs/RECOVERY.md`, `docs/SECURITY.md`.

## Sicherheitsprinzipien

1. Kritische Moderationsaktionen werden erst nach erfolgreichem DB-Commit als erfolgreich bestätigt.
2. Paper macht keine GlobalBan-/ServerBan-Entscheidungen eigenständig. Solche Requests gehen signiert an Velocity und werden dort mit der aktuellen Permission des Actors erneut geprüft.
3. StaffMode persistiert den Snapshot vor der ersten Inventarmutation.
4. Restore setzt Inventar/Zustand deterministisch; Items werden nicht additiv zurückgegeben.
5. Ticket-Claim/Status/Reassign verwenden Revision/CAS und DB-Constraints statt Last-Write-Wins.
6. Freeze-Leave wird am echten Velocity-Netzwerk-Disconnect erkannt. Ein normaler Backendwechsel gilt nicht als Leave.
7. Bridge-Payloads sind versioniert, größenbegrenzt, HMAC-signiert und besitzen Message-ID/Timestamp/Revision.
8. Es wird keine Java-Native-ObjectInputStream-Deserialisierung für Netzwerk- oder Snapshotdaten verwendet.
9. Usertexte werden längenbegrenzt und nicht als ungefiltertes MiniMessage-Markup ausgeführt.
10. DB-Zugriffe werden nicht auf dem Paper-Mainthread ausgeführt.

## Backend-Sicherheit / Velocity Forwarding

StaffCore ersetzt **keine** Netzwerkabsicherung. Paper-Backends dürfen in Produktion nicht ungeschützt direkt aus dem Internet erreichbar sein.

Empfohlen:

1. Velocity Modern Forwarding aktivieren.
2. Dasselbe Forwarding-Secret auf Proxy und Backends konfigurieren.
3. Backends nur auf privaten Interfaces/VLANs oder per Firewall ausschließlich für den Proxy erreichbar machen.
4. Niemals den Minecraft-Backendport offen ins Internet stellen und erwarten, dass StaffCore das kompensiert.
5. Für StaffCore zusätzlich auf allen Nodes dasselbe lange `STAFFCORE_BRIDGE_SECRET` setzen. Dieses Secret ist **nicht** das Velocity-Forwarding-Secret.

## MariaDB einrichten

Beispiel:

```sql
CREATE DATABASE staffcore CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'staffcore'@'%' IDENTIFIED BY 'EIN_LANGES_ZUFALLSPASSWORT';
GRANT ALL PRIVILEGES ON staffcore.* TO 'staffcore'@'%';
FLUSH PRIVILEGES;
```

Danach in Velocity und jedem Paper-Backend dieselbe Datenbank konfigurieren. Passwörter möglichst nicht in `config.yml` speichern:

```text
STAFFCORE_DB_PASSWORD=...
STAFFCORE_BRIDGE_SECRET=...
STAFFCORE_SERVER_NAME=lobby
```

`STAFFCORE_SERVER_NAME` wird nur auf Paper benötigt und muss exakt dem bei Velocity registrierten Backendnamen entsprechen. Für `survival`, `events` und spätere Server jeweils einen eigenen Namen setzen. Servernamen werden im Code nicht fest verdrahtet.

Flyway führt beim Start ausschließlich forward-only Migrationen aus. Vor Upgrades wird ein DB-Backup empfohlen. Ein Migrationsfehler darf nicht als gesunder Zustand weiterlaufen.

## Installation

### Velocity

Nach erfolgreichem Build:

1. `staffcore-velocity/target/staffcore-velocity-0.1.0-SNAPSHOT-all.jar` in `velocity/plugins/` kopieren.
2. Velocity einmal starten, damit `plugins/staffcore/config.yml` erzeugt wird.
3. DB und `STAFFCORE_BRIDGE_SECRET` konfigurieren.
4. Proxy neu starten.
5. Prüfen, ob StaffCore ohne Migrations-/DB-Fehler startet.

Velocity-Metadaten werden aus `@Plugin` über den Velocity-Annotation-Processor erzeugt. Es gibt absichtlich keine zweite manuelle `velocity-plugin.json`, die mit generierten Metadaten kollidieren könnte.

### Lobby / Survival / Events

Für **jedes** Paper-Backend:

1. `staffcore-paper/target/staffcore-paper-0.1.0-SNAPSHOT-all.jar` in `plugins/` kopieren.
2. Server einmal starten.
3. dieselbe DB und dasselbe StaffCore-Bridge-Secret konfigurieren.
4. einen eindeutigen `server-name` setzen (`lobby`, `survival`, `events`, ...).
5. Paper neu starten.

Neue Paper-Server benötigen keine Codeänderung: gleiche Bridge-JAR installieren, eindeutigen Velocity-Servernamen konfigurieren und die Netzwerk-/Forwarding-Regeln einhalten.

## Commands

### Paper / GUI

| Command | Zweck |
|---|---|
| `/staff` / `/staffmenu` | zentrales Staff-Menü |
| `/staffmode` | sicherer StaffMode Toggle/Restore |
| `/report` | geführtes Ticket-/Report-GUI |
| `/tickets` | eigene Tickets; Staff-Workflow über Staff-Menü |
| `/inspect <spieler>` | Player-Inspect |
| `/spectate <spieler>` | normales Spectate |
| `/spectate super <spieler>` | Spectate mit temporärem Vanish |
| `/spectate stop` | Spectate beenden und Origin-Zustand wiederherstellen |

### Velocity / global

| Command | Permission |
|---|---|
| `/vanish` | `staffcore.vanish` |
| `/freeze <spieler> [grund]` | `staffcore.freeze` |
| `/unfreeze <spieler>` | `staffcore.freeze` |
| `/sc` / `/sc <nachricht>` | `staffcore.staffchat.use` |
| `/stafflist` | `staffcore.stafflist` |
| `/warn` | `staffcore.punishment.warn` |
| `/kick` | `staffcore.punishment.kick` |
| `/mute`, `/tempmute`, `/unmute` | `staffcore.punishment.mute` |
| `/serverban`, `/tempserverban`, `/serverunban` | `staffcore.punishment.serverban` |
| `/globalban`, `/tempglobalban`, `/globalunban` | `staffcore.punishment.globalban` |

## Staff-Hierarchie

StaffCore liest keine LuckPerms-Gruppennamen. Ausschließlich folgende Permissions bestimmen die Hierarchie:

| Rank | Level | Permission |
|---|---:|---|
| JrMod | 10 | `staffcore.rank.jrmod` |
| Mod | 20 | `staffcore.rank.mod` |
| SrMod | 30 | `staffcore.rank.srmod` |
| Admin | 40 | `staffcore.rank.admin` |
| Owner | 50 | `staffcore.rank.owner` |

Bei mehreren Rank-Permissions gewinnt die höchste. LuckPerms darf die Permissions vergeben, StaffCore erstellt oder verändert aber keine LuckPerms-Gruppen.

### Vanish-Sichtbarkeit

Ein Staff sieht vanished Staff **nur derselben oder einer niedrigeren Stufe**. Normale Spieler sehen vanished Staff nicht. Dieselbe Ranggrenze wird auch in StaffList, Inspect-Zielauswahl und Ticket-Assignee-Auswahl berücksichtigt.

Öffentliche Paper-Visibility-APIs können Entity-Sichtbarkeit zuverlässig steuern. Drittanbieter-Scoreboards, selbst geschriebene Tablisten, Placeholder-Plugins oder eigene Packet-Systeme können trotzdem Informationen leaken; siehe `docs/KNOWN_LIMITATIONS.md`.

## Permission-Tabelle

| Permission | Zweck |
|---|---|
| `staffcore.rank.jrmod` | Rank JrMod |
| `staffcore.rank.mod` | Rank Mod |
| `staffcore.rank.srmod` | Rank SrMod |
| `staffcore.rank.admin` | Rank Admin |
| `staffcore.rank.owner` | Rank Owner |
| `staffcore.menu` | Staff-Menü |
| `staffcore.staffmode` | StaffMode |
| `staffcore.staffmode.recover` | eigener StaffMode-Recovery |
| `staffcore.recovery.admin` | privilegierte Recovery-Funktionen |
| `staffcore.vanish` | Vanish Toggle |
| `staffcore.vanish.see` | Vanish-Statusdaten sehen; überschreibt **nicht** die Rang-Sichtbarkeit |
| `staffcore.freeze` | Freeze/Unfreeze |
| `staffcore.freeze.bypass` | kontrollierter Freeze-Systembypass |
| `staffcore.spectate` | Spectate |
| `staffcore.spectate.super` | Super-Spectate |
| `staffcore.teleport` | StaffCore Cross-Server-Teleport |
| `staffcore.staffchat.use` | StaffChat senden/togglen |
| `staffcore.staffchat.see` | StaffChat empfangen |
| `staffcore.stafflist` | StaffList |
| `staffcore.inspect` | Player Inspect |
| `staffcore.inspect.inventory` | Inventar ansehen |
| `staffcore.inspect.inventory.edit` | Inventar bearbeiten |
| `staffcore.inspect.ip` | aktuelle IP ansehen; Zugriff wird auditiert |
| `staffcore.ticket.view` | Staff-Tickets sehen |
| `staffcore.ticket.claim` | claim/release |
| `staffcore.ticket.reply` | antworten/interne Notiz |
| `staffcore.ticket.close` | Status schließen/lösen/ablehnen/warten |
| `staffcore.ticket.override` | expliziter Ticket-Override |
| `staffcore.ticket.escalate` | eskalieren |
| `staffcore.ticket.reassign` | neu zuweisen |
| `staffcore.ticket.reopen` | wieder öffnen |
| `staffcore.punishment.warn` | Warn |
| `staffcore.punishment.kick` | Kick |
| `staffcore.punishment.mute` | Mute/TempMute/Unmute |
| `staffcore.punishment.serverban` | ServerBan-Scope |
| `staffcore.punishment.globalban` | GlobalBan-Scope |
| `staffcore.notes.view` | Staff Notes lesen |
| `staffcore.notes.edit` | Staff Notes erstellen/bearbeiten |
| `staffcore.notes.archive` | Notes archivieren |
| `staffcore.logs.view` | Audit-Logs |
| `staffcore.logs.sensitive` | reserviert für sensible Auditdetails |
| `staffcore.activity.view` | Activity-Zusammenfassung |
| `staffcore.activity.view.details` | Activity-Einzelereignisse |
| `staffcore.routing.admin` | Routing-Administration |

### Empfohlene Matrix

Dies sind Empfehlungen, keine automatisch erzeugten LuckPerms-Gruppen.

| Feature | JrMod | Mod | SrMod | Admin | Owner |
|---|:---:|:---:|:---:|:---:|:---:|
| Staff-Menü/StaffChat/StaffList | ✓ | ✓ | ✓ | ✓ | ✓ |
| Inspect | ✓ | ✓ | ✓ | ✓ | ✓ |
| Inventory View | – | ✓ | ✓ | ✓ | ✓ |
| Inventory Edit | – | – | ✓ | ✓ | ✓ |
| Freeze/Spectate | ✓ | ✓ | ✓ | ✓ | ✓ |
| Super-Spectate | – | – | ✓ | ✓ | ✓ |
| Ticket claim/reply | ✓ | ✓ | ✓ | ✓ | ✓ |
| Ticket reassign/escalate | – | ✓ | ✓ | ✓ | ✓ |
| Ticket override/reopen | – | – | ✓ | ✓ | ✓ |
| Warn/Kick | ✓ | ✓ | ✓ | ✓ | ✓ |
| Mute | – | ✓ | ✓ | ✓ | ✓ |
| ServerBan | – | ✓ | ✓ | ✓ | ✓ |
| GlobalBan | – | – | – | ✓ | ✓ |
| Inventory/IP/Logs sensible | – | – | – | ✓ | ✓ |
| Activity Details | – | – | – | ✓ | ✓ |
| Recovery Admin | – | – | – | ✓ | ✓ |

## StaffMode

Aktivierung:

1. prüfen, dass keine konkurrierende aktive Session existiert;
2. vollständigen Snapshot erfassen;
3. Snapshot versioniert in MariaDB persistieren und committen;
4. **erst danach** StaffMode-Inventar/Zustand anwenden;
5. ACTIVE persistieren.

Restore sperrt/transitioniert die Session, routet bei Bedarf über Velocity zum Origin-Backend und setzt Zustand deterministisch zurück. Ein fehlendes Origin-Backend oder ein uneindeutiger Crashzustand führt zu Recovery statt zu einem additiven Item-Restore.

StaffMode aktiviert Vanish **nicht automatisch**.

## Spectate

Normales Spectate verändert Vanish nicht. Super-Spectate setzt Vanish nur dann temporär, wenn er vorher aus war. Beim Ende werden Origin-Server, Position, Gamemode und ursprünglicher Vanish-Status wiederhergestellt. Die Spectate-Session ist persistent und gegen Doppelstart geschützt.

## Freeze / Freeze-Leave

Freeze ist persistent und netzwerkweit. Während Freeze werden Bewegung, relevante Interaktionen, Inventarmanipulation und nicht erlaubte Commands blockiert. Normaler Chat bleibt erlaubt, sofern kein separater Mute aktiv ist.

Beim **echten Netzwerk-Disconnect** während Freeze:

- letzte bekannte Daten werden in derselben kritischen Verarbeitung erhalten;
- genau ein idempotenter System-TempGlobalBan wird erstellt;
- Standarddauer: `5m`, konfigurierbar unter `freeze.leave-tempban` auf Velocity;
- Freeze bleibt nach Ablauf des Tempbans aktiv;
- Audit + Staff-Alert + persistente Staff-Inbox werden erzeugt.

Ein Fake-NPC ist absichtlich optional und standardmäßig deaktiviert, weil die Kernlogik nicht von fragilen NMS-/Packet-Hacks abhängen soll.

## Tickets und Reports

Kategorien: Player Report, Bug, Serverproblem, Hilfe, Staff Report, Other. Spieler können eigene Tickets sehen und antworten.

Staff-Workflow unterstützt u. a.:

- offen / mir zugewiesen / unzugewiesen;
- High / Critical / Escalated / Waiting for Player;
- claim/release;
- Antwort und interne Notiz;
- resolve/close/reject/reopen;
- reassign mit Rangprüfung;
- Override mit Permission und Audit;
- Suche nach Ticket-ID.

Claim/Status/Reassign sind revisioniert. Stale GUIs erhalten keinen stillen Last-Write-Wins-Erfolg.

### Priority Engine

Keine externe KI. Der Score ist deterministisch und persistiert eine Erklärung aus Basisscore, Regeln und Mindest-Rank. Die Engine darf sortieren/routen/benachrichtigen, aber **niemals automatisch punishen**.

Konfigurierbare Inputs umfassen Kategorie/Subcategory, ähnliche Reports, Reports gegen dasselbe Ziel, serverweite Relevanz, Alter, Escalation/Reopen/Freeze/Outage-Faktoren.

### Assignment Engine

Velocity berücksichtigt Onlinezustand, Rank, Permission, Kapazität, aktive Ticketlast und Least-Recently-Assigned als stabilen Fairness-Tie-Breaker. Niedrigster ausreichender Rank wird bevorzugt. Assignment wird atomar in der DB committed und auditiert.

## Punishments

Unterstützt:

- Warn
- Kick
- Mute / TempMute / Unmute
- ServerBan / TempServerBan / ServerUnban
- GlobalBan / TempGlobalBan / GlobalUnban

`ServerBan` blockiert nur den gewählten Backendserver. Ist der Spieler dort bereits online, versucht Velocity einen erlaubten Fallback; andernfalls wird getrennt, statt in einer Connect-Schleife zu landen.

`GlobalBan` blockiert den kompletten Netzwerklogin und benötigt die separate Permission `staffcore.punishment.globalban`.

Jede Erstellung hat eine Idempotency-ID. Temporäre Strafen werden zusätzlich bei jedem Enforcement anhand UTC-Zeit bewertet; der Expiry-Task ist nur Cleanup und nicht die einzige Wahrheit.

### Mute-Grenzen

StaffCore blockiert normalen Chat und konfigurierte Alias-Commands wie `/msg`/`/reply`. Ein unbekanntes Drittanbieter-Plugin kann eigene PM-Kanäle oder ungewöhnliche Commands bereitstellen. Solche unbekannten Systeme kann StaffCore ohne explizite Integration nicht garantiert blockieren.

## Inspect / Datenschutz

Inspect zeigt ausschließlich Daten, die StaffCore/Paper tatsächlich besitzt. Dazu gehören je nach Onlinezustand Server, Ping, Protocol-Version, Client-Brand, Welt/Position, Gamemode, Health/Food/XP, bekannte Names, Sessions, Tickets, Punishments, Notes und State.

StaffCore behauptet **nicht**, alle Client-Mods erkennen zu können. Plugin-Channels und Client-Brand sind nur beobachtbare Signale.

IP-Adressen werden nicht als Langzeitprofil gespeichert. Die aktuelle Socket-IP wird nur online, nur mit `staffcore.inspect.ip` angezeigt; der Zugriff wird auditiert, ohne die IP selbst in den Audittext zu schreiben.

## Inventory Inspect/Edit

View und Edit sind getrennte Permissions. Edit verwendet einen DB-Lease und einen Baseline-Hash. Verändert sich das Zielinventar parallel, wird der Edit verworfen statt den neueren Zustand zu überschreiben. Der Staff-Cursor wird beim Edit separat gesichert. Slots werden deterministisch gesetzt; es werden keine Items als Restore-Mechanismus auf den Boden gedroppt.

## Notifications

Persistente Inbox für Ticketänderungen, Assignment, Override und Freeze-Leave. Read/Unread wird in MariaDB geführt. Delivery-Fehler dürfen einen bereits erfolgreich committed Moderationsvorgang nicht zurückrollen.

## MaintenanceCore

StaffCore besitzt eine optionale `MaintenanceStatusProvider`-Schnittstelle und startet ohne MaintenanceCore. Da in diesem Source-Stand keine öffentliche MaintenanceCore-API mitgeliefert wurde, ist keine harte Klassenkopplung eingebaut; das GUI zeigt die Integration als nicht verfügbar. Eine spätere Integration soll über Velocity ServiceManager erfolgen.

## Presence / Crash-Cleanup

Velocity hält `server_presence` über einen periodischen Heartbeat aktuell. Standard:

```yaml
runtime:
  presence-heartbeat-interval: 15s
  presence-stale-after: 90s
```

Die Stale-Schwelle muss größer als das Doppelte des Heartbeat-Intervalls sein. Beim Cleanup werden nicht nur veraltete Presence-Zeilen entfernt, sondern auch zugehörige noch offene `player_server_sessions` derselben Network-Session abgeschlossen. Normale Disconnects schließen die Session sofort.

## Degraded Mode

Bei DB-Ausfall:

- kritische neue Mutationen dürfen nicht als erfolgreich bestätigt werden;
- bereits sicher geladene lokale Enforcement-States können weiterwirken;
- StaffCore sperrt nicht pauschal alle Spieler aus, nur weil die DB kurz nicht erreichbar ist;
- DB-Health wird im Staff-GUI sichtbar;
- nach Rückkehr der DB werden normale Queries/State-Resyncs wieder verwendet;
- kritische Daten werden nicht still in unbounded In-Memory-Queues „vorgegaukelt“.

## Build

Benötigt JDK 25.

```bash
./mvnw clean verify
```

Erwartete Release-Artefakte nach erfolgreichem Build:

```text
staffcore-velocity/target/staffcore-velocity-0.1.0-SNAPSHOT-all.jar
staffcore-paper/target/staffcore-paper-0.1.0-SNAPSHOT-all.jar
```

Prüfsummen danach:

```bash
./scripts/sha256.sh
```

In diesem bereitgestellten Stand existieren bewusst keine behaupteten Release-JARs, solange `clean verify` nicht wirklich mit Java 25 erfolgreich gelaufen ist.

## Runtime-Testnetz

`runtime-test/docker-compose.yml` stellt nur MariaDB bereit. Server-JARs werden nicht gebündelt. Der vollständige Testablauf steht in:

- `runtime-test/README.md`
- `docs/RUNTIME_TEST_PLAN.md`

Minimal: 1 Velocity, 3 Paper (`lobby`, `survival`, `events`), MariaDB und mindestens normaler Spieler + niedriger Staff + höherer Staff.

## Upgrade / Backup

Vor jeder neuen StaffCore-Version:

1. MariaDB sichern.
2. alte Plugin-JARs sichern.
3. Changelog/Migrationen lesen.
4. zuerst in einem Testnetz starten.
5. Flyway-Migration erfolgreich prüfen.
6. StaffMode-/Freeze-/Punishment-/Ticket-Recovery-Szenarien testen.
7. erst danach Produktion aktualisieren.

Migrationen sind forward-only. Kein automatisches destruktives Downgrade.

## Troubleshooting

- **Plugin stoppt beim Start:** DB/Secret/server-name/config-version prüfen; Migrationsfehler nicht ignorieren.
- **Bridge funktioniert nicht:** identisches `STAFFCORE_BRIDGE_SECRET`, Plugin auf Proxy und Backend, mindestens ein Spieler als Plugin-Message-Carrier und Backend-Erreichbarkeit prüfen.
- **Paper ist direkt erreichbar:** Firewall/Modern Forwarding korrigieren; das ist ein Deploymentfehler, kein StaffCore-Feature.
- **StaffMode Recovery:** Session in Staff-GUI/DB prüfen, Origin-Server wieder online bringen; keine Snapshotzeilen manuell löschen.
- **Ticket Claim Konflikt:** GUI neu laden; das ist erwartete CAS-Konfliktbehandlung.
- **DB offline:** keine neue kritische Mutation als Erfolg behandeln; Health-Status prüfen.

## Bekannte Grenzen

Siehe `docs/KNOWN_LIMITATIONS.md`. Build-/Teststatus siehe `BUILD_REPORT.md`.
