package de.yolan.staffcore.common.permission;

import java.util.Optional;
import java.util.function.Predicate;

public final class StaffHierarchy {
    public Optional<StaffRank> rankOf(Predicate<String> permissionChecker) { return StaffRank.resolve(permissionChecker); }
    public boolean canSeeVanished(Optional<StaffRank> viewer, Optional<StaffRank> target) {
        if (viewer.isEmpty() || target.isEmpty()) return false;
        return viewer.get().level() >= target.get().level();
    }
    public boolean canOverride(StaffRank actor, StaffRank previousActor, boolean explicitOverride) {
        return explicitOverride || actor.level() > previousActor.level();
    }
}
