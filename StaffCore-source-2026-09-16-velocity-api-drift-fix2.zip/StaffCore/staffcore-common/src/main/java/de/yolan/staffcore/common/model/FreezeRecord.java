package de.yolan.staffcore.common.model;
import java.time.Instant;import java.util.UUID;
public record FreezeRecord(UUID playerUuid, boolean active, UUID sessionId, UUID actorUuid, String reason, String lastServer, String lastWorld, Double x, Double y, Double z, long revision, Instant createdAt, Instant updatedAt) {}
