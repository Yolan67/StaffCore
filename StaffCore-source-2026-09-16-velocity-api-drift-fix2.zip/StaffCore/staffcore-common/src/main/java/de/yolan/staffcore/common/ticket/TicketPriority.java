package de.yolan.staffcore.common.ticket;
public enum TicketPriority { LOW, NORMAL, HIGH, CRITICAL }
