package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record StateRequestPayload(UUID playerUuid,String serverName){}
