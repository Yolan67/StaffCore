package de.yolan.staffcore.common.ticket;
import java.time.Instant;
public record PriorityContext(TicketCategory category,String subcategory,int similarReports,int targetReports,boolean serverWide,boolean staffEscalated,int reopenCount,boolean freezeRelated,boolean knownOutage,Instant createdAt) {}
