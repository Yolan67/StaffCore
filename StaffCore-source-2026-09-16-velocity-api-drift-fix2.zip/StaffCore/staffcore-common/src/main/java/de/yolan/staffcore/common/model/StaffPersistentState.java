package de.yolan.staffcore.common.model;
import java.time.Instant;import java.util.UUID;
public record StaffPersistentState(UUID staffUuid,boolean vanished,boolean staffChat,long revision,Instant updatedAt){}
