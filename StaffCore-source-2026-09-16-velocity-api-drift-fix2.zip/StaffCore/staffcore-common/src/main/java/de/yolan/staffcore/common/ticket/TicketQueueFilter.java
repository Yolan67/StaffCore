package de.yolan.staffcore.common.ticket;

public enum TicketQueueFilter {
    OPEN,
    ASSIGNED_TO_ME,
    UNASSIGNED,
    HIGH,
    CRITICAL,
    ESCALATED,
    WAITING_FOR_PLAYER,
    RESOLVED,
    CLOSED,
    REJECTED,
    HISTORY
}
