package de.yolan.staffcore.common.state;
public enum SpectateLifecycle { INACTIVE, STARTING, ACTIVE_NORMAL, ACTIVE_SUPER, STOPPING, RECOVERY_REQUIRED;
 public boolean canTransitionTo(SpectateLifecycle n){return switch(this){case INACTIVE->n==STARTING;case STARTING->n==ACTIVE_NORMAL||n==ACTIVE_SUPER||n==RECOVERY_REQUIRED;case ACTIVE_NORMAL,ACTIVE_SUPER->n==STOPPING||n==RECOVERY_REQUIRED;case STOPPING->n==INACTIVE||n==RECOVERY_REQUIRED;case RECOVERY_REQUIRED->n==STOPPING||n==INACTIVE;};}
}
