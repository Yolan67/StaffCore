package de.yolan.staffcore.common.model;
import java.time.Instant;import java.util.UUID;
public record TicketMessage(long id,long ticketId,UUID authorUuid,String authorName,boolean staff,String message,Instant createdAt){}
