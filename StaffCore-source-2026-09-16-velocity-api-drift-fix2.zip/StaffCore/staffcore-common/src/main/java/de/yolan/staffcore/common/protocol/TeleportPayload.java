package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record TeleportPayload(UUID staffUuid,UUID targetUuid,String targetServer,UUID requestId){}
