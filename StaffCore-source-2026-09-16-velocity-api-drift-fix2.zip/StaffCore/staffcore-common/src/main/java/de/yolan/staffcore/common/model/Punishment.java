package de.yolan.staffcore.common.model;
import de.yolan.staffcore.common.punishment.*;import java.time.Instant;import java.util.UUID;
public record Punishment(UUID id, UUID targetUuid, UUID actorUuid, String actorName, PunishmentType type, PunishmentScope scope, String serverName, String reason, String description, Instant createdAt, Instant expiresAt, PunishmentStatus status, String idempotencyKey, boolean systemGenerated) {
 public boolean isActiveAt(Instant now){return status==PunishmentStatus.ACTIVE&&(expiresAt==null||expiresAt.isAfter(now));}
 public boolean appliesToServer(String server){return scope==PunishmentScope.NETWORK || (serverName!=null&&serverName.equalsIgnoreCase(server));}
}
