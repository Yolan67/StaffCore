package de.yolan.staffcore.common.state;
public enum VanishLifecycle { VISIBLE, ENABLING, VANISHED, DISABLING, RECOVERY_REQUIRED;
 public boolean canTransitionTo(VanishLifecycle n){return switch(this){case VISIBLE->n==ENABLING;case ENABLING->n==VANISHED||n==RECOVERY_REQUIRED;case VANISHED->n==DISABLING||n==RECOVERY_REQUIRED;case DISABLING->n==VISIBLE||n==RECOVERY_REQUIRED;case RECOVERY_REQUIRED->n==VISIBLE||n==VANISHED;};}
}
