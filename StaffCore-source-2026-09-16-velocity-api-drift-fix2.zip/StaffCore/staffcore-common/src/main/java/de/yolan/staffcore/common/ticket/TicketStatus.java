package de.yolan.staffcore.common.ticket;
public enum TicketStatus { OPEN, ASSIGNED, ESCALATED, WAITING_FOR_PLAYER, RESOLVED, CLOSED, REJECTED }
