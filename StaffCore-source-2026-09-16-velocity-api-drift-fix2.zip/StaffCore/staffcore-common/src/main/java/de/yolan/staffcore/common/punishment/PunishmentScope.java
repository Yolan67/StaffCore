package de.yolan.staffcore.common.punishment;
public enum PunishmentScope { NETWORK, SERVER }
