package de.yolan.staffcore.common.protocol;
public final class ProtocolConstants { private ProtocolConstants(){} public static final int VERSION=1; public static final String CHANNEL="staffcore:bridge"; public static final int MAX_BYTES=24*1024; public static final long MAX_CLOCK_SKEW_SECONDS=120; }
