package de.yolan.staffcore.common.punishment;
public enum PunishmentStatus { ACTIVE, EXPIRED, REVOKED }
