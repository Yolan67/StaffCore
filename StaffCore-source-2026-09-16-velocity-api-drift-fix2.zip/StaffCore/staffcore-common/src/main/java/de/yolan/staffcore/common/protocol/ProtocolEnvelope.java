package de.yolan.staffcore.common.protocol;
import com.fasterxml.jackson.databind.JsonNode;import java.time.Instant;import java.util.UUID;
public record ProtocolEnvelope(int protocolVersion,UUID messageId,MessageType type,UUID subjectUuid,long revision,Instant timestamp,JsonNode payload,String signature) {}
