package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record FreezeRequestPayload(UUID actorUuid,UUID targetUuid,String action,String reason,UUID requestId){}
