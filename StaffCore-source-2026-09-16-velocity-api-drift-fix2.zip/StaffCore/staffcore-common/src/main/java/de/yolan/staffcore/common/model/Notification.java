package de.yolan.staffcore.common.model;
import java.time.Instant;import java.util.UUID;
public record Notification(UUID id,UUID recipientUuid,String type,String title,String body,String dedupeKey,boolean read,Instant createdAt,Instant readAt){}
