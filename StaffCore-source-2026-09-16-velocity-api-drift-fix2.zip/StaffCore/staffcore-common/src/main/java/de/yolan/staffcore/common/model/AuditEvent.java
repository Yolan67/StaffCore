package de.yolan.staffcore.common.model;
import java.time.Instant;import java.util.UUID;
public record AuditEvent(UUID id, UUID correlationId, UUID actorUuid, String actorName, UUID targetUuid, String serverName, String actionType, String beforeJson, String afterJson, Instant createdAt) {}
