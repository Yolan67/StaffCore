package de.yolan.staffcore.common.util;

import java.time.Duration;
import java.util.Locale;
import java.util.Optional;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class DurationParser {
    private static final Pattern TOKEN=Pattern.compile("(\\d+)(mo|s|m|h|d|w|y)", Pattern.CASE_INSENSITIVE);
    private DurationParser() {}
    public static Optional<Duration> parse(String input) {
        if (input == null || input.isBlank()) throw new IllegalArgumentException("duration is blank");
        String value=input.trim().toLowerCase(Locale.ROOT);
        if (value.equals("perm") || value.equals("permanent") || value.equals("forever")) return Optional.empty();
        Matcher m=TOKEN.matcher(value); long seconds=0; int end=0; boolean any=false;
        while (m.find()) {
            if (m.start()!=end) throw new IllegalArgumentException("invalid duration: "+input);
            long n=Long.parseLong(m.group(1)); String unit=m.group(2).toLowerCase(Locale.ROOT);
            long factor=switch(unit){case "s"->1;case "m"->60;case "h"->3600;case "d"->86400;case "w"->604800;case "mo"->2592000;case "y"->31536000;default->throw new IllegalArgumentException(unit);};
            seconds=Math.addExact(seconds, Math.multiplyExact(n,factor)); end=m.end(); any=true;
        }
        if(!any || end!=value.length() || seconds<=0) throw new IllegalArgumentException("invalid duration: "+input);
        return Optional.of(Duration.ofSeconds(seconds));
    }
    public static String format(Duration duration) {
        long s=Math.max(0,duration.toSeconds()); long d=s/86400;s%=86400;long h=s/3600;s%=3600;long m=s/60;s%=60;
        StringBuilder b=new StringBuilder(); if(d>0)b.append(d).append('d');if(h>0)b.append(h).append('h');if(m>0)b.append(m).append('m');if(s>0||b.isEmpty())b.append(s).append('s');return b.toString();
    }
}
