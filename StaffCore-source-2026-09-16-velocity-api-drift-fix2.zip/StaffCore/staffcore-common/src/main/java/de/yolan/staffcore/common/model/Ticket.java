package de.yolan.staffcore.common.model;
import de.yolan.staffcore.common.permission.StaffRank;import de.yolan.staffcore.common.ticket.*;import java.time.Instant;import java.util.UUID;
public record Ticket(long id, UUID creatorUuid, UUID targetUuid, TicketCategory category, String subcategory, String subject, String description, String serverName, TicketStatus status, TicketPriority priority, int priorityScore, String priorityExplanation, StaffRank minimumRank, UUID assigneeUuid, int revision, int reopenCount, Instant createdAt, Instant updatedAt) {}
