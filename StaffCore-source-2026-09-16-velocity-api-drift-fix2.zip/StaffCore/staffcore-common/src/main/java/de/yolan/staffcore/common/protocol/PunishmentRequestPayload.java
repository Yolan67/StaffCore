package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record PunishmentRequestPayload(UUID actorUuid,UUID targetUuid,String operation,String type,UUID punishmentId,String serverName,Long durationSeconds,String reason,String description,UUID requestId){}
