package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record NotificationPayload(UUID recipientUuid,String title,String body){}
