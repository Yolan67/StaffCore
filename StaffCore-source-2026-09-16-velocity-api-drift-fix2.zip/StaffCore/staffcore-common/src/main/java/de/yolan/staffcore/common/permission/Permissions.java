package de.yolan.staffcore.common.permission;

import java.util.List;

public final class Permissions {
    private Permissions() {}
    public static final String MENU="staffcore.menu", STAFFMODE="staffcore.staffmode", STAFFMODE_RECOVER="staffcore.staffmode.recover";
    public static final String VANISH="staffcore.vanish", VANISH_SEE="staffcore.vanish.see";
    public static final String FREEZE="staffcore.freeze", FREEZE_BYPASS="staffcore.freeze.bypass";
    public static final String SPECTATE="staffcore.spectate", SPECTATE_SUPER="staffcore.spectate.super", TELEPORT="staffcore.teleport";
    public static final String STAFFCHAT_USE="staffcore.staffchat.use", STAFFCHAT_SEE="staffcore.staffchat.see", STAFFLIST="staffcore.stafflist";
    public static final String INSPECT="staffcore.inspect", INSPECT_INVENTORY="staffcore.inspect.inventory", INSPECT_INVENTORY_EDIT="staffcore.inspect.inventory.edit", INSPECT_IP="staffcore.inspect.ip";
    public static final String TICKET_VIEW="staffcore.ticket.view", TICKET_CLAIM="staffcore.ticket.claim", TICKET_REPLY="staffcore.ticket.reply", TICKET_CLOSE="staffcore.ticket.close", TICKET_OVERRIDE="staffcore.ticket.override", TICKET_ESCALATE="staffcore.ticket.escalate", TICKET_REASSIGN="staffcore.ticket.reassign", TICKET_REOPEN="staffcore.ticket.reopen";
    public static final String PUNISH_WARN="staffcore.punishment.warn", PUNISH_KICK="staffcore.punishment.kick", PUNISH_MUTE="staffcore.punishment.mute", PUNISH_SERVERBAN="staffcore.punishment.serverban", PUNISH_GLOBALBAN="staffcore.punishment.globalban";
    public static final String NOTES_VIEW="staffcore.notes.view", NOTES_EDIT="staffcore.notes.edit", NOTES_ARCHIVE="staffcore.notes.archive";
    public static final String LOGS_VIEW="staffcore.logs.view", LOGS_SENSITIVE="staffcore.logs.sensitive", ACTIVITY_VIEW="staffcore.activity.view", ACTIVITY_DETAILS="staffcore.activity.view.details", ROUTING_ADMIN="staffcore.routing.admin", RECOVERY_ADMIN="staffcore.recovery.admin";
    public static final List<String> ALL=List.of(MENU,STAFFMODE,STAFFMODE_RECOVER,VANISH,VANISH_SEE,FREEZE,FREEZE_BYPASS,SPECTATE,SPECTATE_SUPER,TELEPORT,STAFFCHAT_USE,STAFFCHAT_SEE,STAFFLIST,INSPECT,INSPECT_INVENTORY,INSPECT_INVENTORY_EDIT,INSPECT_IP,TICKET_VIEW,TICKET_CLAIM,TICKET_REPLY,TICKET_CLOSE,TICKET_OVERRIDE,TICKET_ESCALATE,TICKET_REASSIGN,TICKET_REOPEN,PUNISH_WARN,PUNISH_KICK,PUNISH_MUTE,PUNISH_SERVERBAN,PUNISH_GLOBALBAN,NOTES_VIEW,NOTES_EDIT,NOTES_ARCHIVE,LOGS_VIEW,LOGS_SENSITIVE,ACTIVITY_VIEW,ACTIVITY_DETAILS,ROUTING_ADMIN,RECOVERY_ADMIN);
}
