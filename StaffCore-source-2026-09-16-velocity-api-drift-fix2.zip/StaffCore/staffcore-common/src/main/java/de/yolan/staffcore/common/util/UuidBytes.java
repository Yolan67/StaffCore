package de.yolan.staffcore.common.util;

import java.nio.ByteBuffer;
import java.util.UUID;
public final class UuidBytes {
    private UuidBytes() {}
    public static byte[] toBytes(UUID uuid){return ByteBuffer.allocate(16).putLong(uuid.getMostSignificantBits()).putLong(uuid.getLeastSignificantBits()).array();}
    public static UUID fromBytes(byte[] b){if(b==null||b.length!=16)throw new IllegalArgumentException("UUID binary must be 16 bytes");ByteBuffer x=ByteBuffer.wrap(b);return new UUID(x.getLong(),x.getLong());}
}
