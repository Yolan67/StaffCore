package de.yolan.staffcore.common.util;

import java.util.Objects;

public final class InputPolicy {
    private InputPolicy() {}
    public static String bounded(String value, int max, String field) {
        Objects.requireNonNull(value, field+" is null"); String v=value.strip();
        if(v.isEmpty()) throw new IllegalArgumentException(field+" is blank");
        if(v.codePointCount(0,v.length())>max) throw new IllegalArgumentException(field+" exceeds "+max+" chars");
        if(v.indexOf('\0')>=0) throw new IllegalArgumentException(field+" contains NUL");
        return v;
    }
    public static String plainForMiniMessage(String value) {
        return value.replace("\\", "\\\\").replace("<", "\\<");
    }
}
