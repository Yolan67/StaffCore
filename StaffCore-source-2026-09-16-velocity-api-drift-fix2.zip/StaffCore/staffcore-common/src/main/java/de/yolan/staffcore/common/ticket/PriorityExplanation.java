package de.yolan.staffcore.common.ticket;
import de.yolan.staffcore.common.permission.StaffRank;import java.util.List;
public record PriorityExplanation(int baseScore,int ageScore,int totalScore,TicketPriority priority,StaffRank minimumRank,List<String> appliedRules) {}
