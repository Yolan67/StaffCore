package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record StaffModeRoutePayload(UUID playerUuid,UUID sessionId,String originServer){}
