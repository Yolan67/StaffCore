package de.yolan.staffcore.common.ticket;
import de.yolan.staffcore.common.permission.StaffRank;import java.time.Instant;import java.util.UUID;
public record StaffCandidate(UUID uuid,String name,StaffRank rank,boolean online,boolean available,boolean permitted,int activeTickets,int capacity,Instant lastAssignedAt) { public double normalizedLoad(){return capacity<=0?Double.POSITIVE_INFINITY:(double)activeTickets/capacity;} }
