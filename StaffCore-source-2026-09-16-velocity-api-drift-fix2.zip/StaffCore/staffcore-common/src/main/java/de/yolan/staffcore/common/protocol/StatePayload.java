package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record StatePayload(UUID playerUuid,boolean vanished,boolean staffChat,boolean frozen,String freezeReason,boolean staffMode,String serverName){}
