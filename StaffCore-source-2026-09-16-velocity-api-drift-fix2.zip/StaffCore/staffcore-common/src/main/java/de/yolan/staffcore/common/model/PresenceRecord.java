package de.yolan.staffcore.common.model;
import java.time.Instant;import java.util.UUID;
public record PresenceRecord(UUID playerUuid,String playerName,String serverName,UUID sessionId,boolean staff,Instant connectedAt,Instant lastSeenAt){}
