package de.yolan.staffcore.common.permission;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Optional;
import java.util.function.Predicate;

public enum StaffRank {
    JR_MOD(10, "JrMod", "staffcore.rank.jrmod"),
    MOD(20, "Mod", "staffcore.rank.mod"),
    SR_MOD(30, "SrMod", "staffcore.rank.srmod"),
    ADMIN(40, "Admin", "staffcore.rank.admin"),
    OWNER(50, "Owner", "staffcore.rank.owner");

    private final int level;
    private final String displayName;
    private final String permission;

    StaffRank(int level, String displayName, String permission) {
        this.level = level; this.displayName = displayName; this.permission = permission;
    }
    public int level() { return level; }
    public String displayName() { return displayName; }
    public String permission() { return permission; }
    public boolean atLeast(StaffRank other) { return level >= other.level; }

    public static Optional<StaffRank> resolve(Predicate<String> permissionChecker) {
        return Arrays.stream(values()).filter(r -> permissionChecker.test(r.permission))
                .max(Comparator.comparingInt(StaffRank::level));
    }

    public static StaffRank parse(String value) {
        if (value == null) throw new IllegalArgumentException("rank is null");
        String n = value.trim().replace("-", "_").replace(" ", "_").toUpperCase();
        if (n.equals("JRMOD")) n = "JR_MOD";
        if (n.equals("SRMOD")) n = "SR_MOD";
        return StaffRank.valueOf(n);
    }
}
