package de.yolan.staffcore.common.punishment;
public enum PunishmentType {
    WARN, KICK, MUTE, SERVER_BAN, GLOBAL_BAN;
    public boolean isBan(){return this==SERVER_BAN||this==GLOBAL_BAN;}
    public boolean isMute(){return this==MUTE;}
}
