package de.yolan.staffcore.common.ticket;
import de.yolan.staffcore.common.permission.StaffRank;import java.util.List;import java.util.UUID;
public record RoutingDecision(UUID selectedStaff,StaffRank minimumRank,List<String> explanation,List<UUID> excluded) { public boolean assigned(){return selectedStaff!=null;} }
