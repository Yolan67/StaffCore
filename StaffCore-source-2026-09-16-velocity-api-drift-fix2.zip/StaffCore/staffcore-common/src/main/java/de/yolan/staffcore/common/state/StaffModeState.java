package de.yolan.staffcore.common.state;

import java.util.EnumSet;
import java.util.Set;

public enum StaffModeState {
    CAPTURING, CAPTURED, ACTIVE, RESTORE_REQUESTED, ROUTING_TO_ORIGIN, RESTORING, RESTORED, RECOVERY_REQUIRED;
    public boolean canTransitionTo(StaffModeState next){return allowed(this).contains(next);}
    public void requireTransitionTo(StaffModeState next){if(!canTransitionTo(next))throw new IllegalStateException(this+" -> "+next+" is not allowed");}
    private static Set<StaffModeState> allowed(StaffModeState s){return switch(s){
        case CAPTURING->EnumSet.of(CAPTURED,RECOVERY_REQUIRED); case CAPTURED->EnumSet.of(ACTIVE,RESTORE_REQUESTED,RECOVERY_REQUIRED);
        case ACTIVE->EnumSet.of(RESTORE_REQUESTED,RECOVERY_REQUIRED); case RESTORE_REQUESTED->EnumSet.of(ROUTING_TO_ORIGIN,RESTORING,RECOVERY_REQUIRED);
        case ROUTING_TO_ORIGIN->EnumSet.of(RESTORING,RECOVERY_REQUIRED); case RESTORING->EnumSet.of(RESTORED,RECOVERY_REQUIRED);
        case RECOVERY_REQUIRED->EnumSet.of(RESTORE_REQUESTED,RESTORING,RESTORED); case RESTORED->EnumSet.noneOf(StaffModeState.class);};}
}
