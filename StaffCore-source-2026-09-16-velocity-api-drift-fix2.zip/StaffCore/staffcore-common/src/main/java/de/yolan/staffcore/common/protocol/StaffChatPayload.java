package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record StaffChatPayload(UUID senderUuid,String senderName,String senderRank,String serverName,String message){}
