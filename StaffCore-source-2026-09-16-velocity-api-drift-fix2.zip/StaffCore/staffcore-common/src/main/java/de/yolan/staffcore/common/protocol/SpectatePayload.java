package de.yolan.staffcore.common.protocol;
import java.util.UUID;
public record SpectatePayload(UUID staffUuid,UUID targetUuid,UUID sessionId,String action,String destinationServer){}
