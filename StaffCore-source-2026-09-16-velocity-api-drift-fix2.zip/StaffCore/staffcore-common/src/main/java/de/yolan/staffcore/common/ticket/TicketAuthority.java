package de.yolan.staffcore.common.ticket;

import de.yolan.staffcore.common.permission.StaffRank;
import java.util.UUID;

/** Pure hierarchy rule for changing work owned by another staff member. */
public final class TicketAuthority {
    private TicketAuthority() {}

    public static boolean mayOverride(UUID actor, UUID assignee, StaffRank actorRank, StaffRank assigneeRank,
                                      boolean explicitOverridePermission) {
        if (actor == null || actorRank == null) return false;
        if (assignee == null || actor.equals(assignee)) return true;
        if (assigneeRank == null) return explicitOverridePermission || actorRank == StaffRank.OWNER;
        return actorRank.level() > assigneeRank.level() || explicitOverridePermission;
    }
}
