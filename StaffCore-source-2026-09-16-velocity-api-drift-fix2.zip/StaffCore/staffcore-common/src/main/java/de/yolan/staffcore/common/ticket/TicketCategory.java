package de.yolan.staffcore.common.ticket;
public enum TicketCategory { PLAYER_REPORT, BUG, SERVER_PROBLEM, HELP, STAFF_REPORT, OTHER }
