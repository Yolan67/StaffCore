package de.yolan.staffcore.common.ticket;
import de.yolan.staffcore.common.permission.StaffRank;import java.util.List;
public interface AssignmentEngine { RoutingDecision select(List<StaffCandidate> candidates, StaffRank minimumRank); }
