package de.yolan.staffcore.common.ticket;
public interface PriorityEngine { PriorityExplanation evaluate(PriorityContext context); }
