package de.yolan.staffcore.common.model;
import de.yolan.staffcore.common.state.StaffModeState;import java.time.Instant;import java.util.UUID;
public record StaffModeSnapshotRecord(UUID sessionId, UUID playerUuid, int formatVersion, StaffModeState state, String originServer, String originWorld, double x,double y,double z,float yaw,float pitch, byte[] payload, String checksum, long revision, Instant createdAt, Instant updatedAt) {}
