package de.yolan.staffcore.common.util;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

class InputPolicyTest {
    @Test
    void boundedRejectsOversizedInput() {
        assertThrows(IllegalArgumentException.class, () -> InputPolicy.bounded("abcdef", 5, "value"));
    }

    @Test
    void boundedKeepsUnicodeContent() {
        assertEquals("Grüße 世界", InputPolicy.bounded("Grüße 世界", 32, "value"));
    }
}
