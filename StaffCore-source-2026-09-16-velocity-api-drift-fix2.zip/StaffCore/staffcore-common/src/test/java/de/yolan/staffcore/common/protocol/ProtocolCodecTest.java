package de.yolan.staffcore.common.protocol;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class ProtocolCodecTest {
    private static final String SECRET = "0123456789abcdef0123456789abcdef";

    @Test
    void roundTripVerifiesSignature() {
        Instant now = Instant.parse("2026-09-16T00:00:00Z");
        ProtocolCodec codec = new ProtocolCodec(SECRET, Clock.fixed(now, ZoneOffset.UTC));
        UUID subject = UUID.randomUUID();
        byte[] data = codec.encode(MessageType.STATE_RESYNC_REQUEST, subject, 7, new StateRequestPayload(subject, "lobby"));
        ProtocolEnvelope envelope = codec.decodeAndVerify(data);
        assertEquals(subject, envelope.subjectUuid());
        assertEquals(7, envelope.revision());
        assertEquals(subject, codec.payload(envelope, StateRequestPayload.class).playerUuid());
    }

    @Test
    void wrongSecretRejectsPayload() {
        ProtocolCodec writer = new ProtocolCodec(SECRET);
        ProtocolCodec reader = new ProtocolCodec("fedcba9876543210fedcba9876543210");
        byte[] data = writer.encode(MessageType.STATE_RESYNC_REQUEST, UUID.randomUUID(), 1, new StateRequestPayload(UUID.randomUUID(), "lobby"));
        assertThrows(SecurityException.class, () -> reader.decodeAndVerify(data));
    }

    @Test
    void staleMessageIsRejected() {
        Instant sent = Instant.parse("2026-09-16T00:00:00Z");
        ProtocolCodec writer = new ProtocolCodec(SECRET, Clock.fixed(sent, ZoneOffset.UTC));
        byte[] data = writer.encode(MessageType.STATE_RESYNC_REQUEST, UUID.randomUUID(), 1, new StateRequestPayload(UUID.randomUUID(), "lobby"));
        ProtocolCodec reader = new ProtocolCodec(SECRET, Clock.fixed(sent.plusSeconds(121), ZoneOffset.UTC));
        assertThrows(IllegalArgumentException.class, () -> reader.decodeAndVerify(data));
    }
}
