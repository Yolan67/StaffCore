package de.yolan.staffcore.common.punishment;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import de.yolan.staffcore.common.model.Punishment;
import java.time.Instant;
import java.util.UUID;
import org.junit.jupiter.api.Test;

class PunishmentModelTest {
    @Test
    void serverScopeOnlyAppliesToConfiguredServer() {
        Punishment punishment = new Punishment(UUID.randomUUID(), UUID.randomUUID(), null, "SYSTEM",
                PunishmentType.SERVER_BAN, PunishmentScope.SERVER, "survival", "reason", null,
                Instant.parse("2026-09-16T00:00:00Z"), null, PunishmentStatus.ACTIVE, "key", false);
        assertTrue(punishment.appliesToServer("SURVIVAL"));
        assertFalse(punishment.appliesToServer("events"));
    }

    @Test
    void expiryIsEvaluatedAgainstUtcInstant() {
        Instant created = Instant.parse("2026-09-16T00:00:00Z");
        Punishment punishment = new Punishment(UUID.randomUUID(), UUID.randomUUID(), null, "SYSTEM",
                PunishmentType.MUTE, PunishmentScope.NETWORK, null, "reason", null,
                created, created.plusSeconds(60), PunishmentStatus.ACTIVE, "key2", false);
        assertTrue(punishment.isActiveAt(created.plusSeconds(59)));
        assertFalse(punishment.isActiveAt(created.plusSeconds(60)));
    }
}
