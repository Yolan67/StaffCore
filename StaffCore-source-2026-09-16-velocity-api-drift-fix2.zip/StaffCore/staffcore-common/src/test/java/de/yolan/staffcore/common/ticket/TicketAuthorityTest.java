package de.yolan.staffcore.common.ticket;

import de.yolan.staffcore.common.permission.StaffRank;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class TicketAuthorityTest {
    @Test
    void higherRankCanOverrideLowerWithoutSpecialPermission() {
        UUID actor = UUID.randomUUID(), assignee = UUID.randomUUID();
        assertTrue(TicketAuthority.mayOverride(actor, assignee, StaffRank.ADMIN, StaffRank.MOD, false));
    }

    @Test
    void equalOrLowerRankNeedsExplicitOverridePermission() {
        UUID actor = UUID.randomUUID(), assignee = UUID.randomUUID();
        assertFalse(TicketAuthority.mayOverride(actor, assignee, StaffRank.MOD, StaffRank.MOD, false));
        assertFalse(TicketAuthority.mayOverride(actor, assignee, StaffRank.MOD, StaffRank.ADMIN, false));
        assertTrue(TicketAuthority.mayOverride(actor, assignee, StaffRank.MOD, StaffRank.ADMIN, true));
    }

    @Test
    void ownAssignmentDoesNotNeedOverride() {
        UUID actor = UUID.randomUUID();
        assertTrue(TicketAuthority.mayOverride(actor, actor, StaffRank.JR_MOD, StaffRank.JR_MOD, false));
    }
}
