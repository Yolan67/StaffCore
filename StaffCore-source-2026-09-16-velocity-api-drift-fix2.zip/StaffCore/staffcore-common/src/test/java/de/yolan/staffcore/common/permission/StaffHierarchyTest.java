package de.yolan.staffcore.common.permission;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.Optional;
import java.util.Set;
import org.junit.jupiter.api.Test;

class StaffHierarchyTest {
    @Test
    void highestPermissionWins() {
        Set<String> permissions = Set.of(StaffRank.MOD.permission(), StaffRank.ADMIN.permission());
        assertEquals(StaffRank.ADMIN, StaffRank.resolve(permissions::contains).orElseThrow());
    }

    @Test
    void vanishVisibilityUsesLevel() {
        StaffHierarchy hierarchy = new StaffHierarchy();
        assertTrue(hierarchy.canSeeVanished(Optional.of(StaffRank.ADMIN), Optional.of(StaffRank.SR_MOD)));
        assertTrue(hierarchy.canSeeVanished(Optional.of(StaffRank.ADMIN), Optional.of(StaffRank.ADMIN)));
        assertFalse(hierarchy.canSeeVanished(Optional.of(StaffRank.JR_MOD), Optional.of(StaffRank.ADMIN)));
        assertFalse(hierarchy.canSeeVanished(Optional.empty(), Optional.of(StaffRank.JR_MOD)));
    }
}
