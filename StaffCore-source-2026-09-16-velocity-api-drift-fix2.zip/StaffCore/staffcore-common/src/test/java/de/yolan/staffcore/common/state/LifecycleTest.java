package de.yolan.staffcore.common.state;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class LifecycleTest {
    @Test
    void freezeLeavePathIsExplicit() {
        assertTrue(FreezeLifecycle.FROZEN.canTransitionTo(FreezeLifecycle.LEAVE_DETECTED));
        assertTrue(FreezeLifecycle.LEAVE_DETECTED.canTransitionTo(FreezeLifecycle.LEAVE_PUNISHMENT_COMMITTED));
        assertTrue(FreezeLifecycle.LEAVE_PUNISHMENT_COMMITTED.canTransitionTo(FreezeLifecycle.FROZEN_OFFLINE));
        assertFalse(FreezeLifecycle.FROZEN.canTransitionTo(FreezeLifecycle.UNFROZEN));
    }

    @Test
    void spectateSuperMustStopThroughStopping() {
        assertTrue(SpectateLifecycle.STARTING.canTransitionTo(SpectateLifecycle.ACTIVE_SUPER));
        assertTrue(SpectateLifecycle.ACTIVE_SUPER.canTransitionTo(SpectateLifecycle.STOPPING));
        assertFalse(SpectateLifecycle.ACTIVE_SUPER.canTransitionTo(SpectateLifecycle.INACTIVE));
    }

    @Test
    void vanishLifecycleDoesNotSkipTransitions() {
        assertTrue(VanishLifecycle.VISIBLE.canTransitionTo(VanishLifecycle.ENABLING));
        assertTrue(VanishLifecycle.ENABLING.canTransitionTo(VanishLifecycle.VANISHED));
        assertFalse(VanishLifecycle.VISIBLE.canTransitionTo(VanishLifecycle.VANISHED));
    }
}
