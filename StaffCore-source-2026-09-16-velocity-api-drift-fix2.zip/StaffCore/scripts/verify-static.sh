#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
python3 scripts/verify-static.py
JAVA_VERSION="$(java -version 2>&1 | head -n1 || true)"
printf 'INFO: runtime Java: %s\n' "$JAVA_VERSION"
if [[ "$JAVA_VERSION" != *'"25'* ]]; then
  printf 'WARN: echter Zielbuild benötigt JDK 25; statische Prüfung ersetzt keinen Maven-Build.\n' >&2
fi
