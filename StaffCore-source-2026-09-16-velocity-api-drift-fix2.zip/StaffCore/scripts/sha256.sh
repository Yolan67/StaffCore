#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mapfile -t jars < <(find staffcore-velocity/target staffcore-paper/target -maxdepth 1 -type f -name '*-all.jar' 2>/dev/null | sort)
if [[ ${#jars[@]} -eq 0 ]]; then
  echo "Keine gebauten *-all.jar Artefakte gefunden. Erst nach erfolgreichem ./mvnw clean verify ausführen." >&2
  exit 2
fi
sha256sum "${jars[@]}" | tee SHA256SUMS.txt
